﻿/********************************************************************************
	 -- Halo Dev Controls
    Copyright © 2011 Jesus7Freak

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*********************************************************************************
	File:    win_Chat_Commands.cs
	Project: Halo Dev Controls C#
	Author:  Jesus7Freak
	Date:    11/22/2011
	Game:    Halo and Halo Custom Edition
	Version: all
*********************************************************************************/
using System;
using System.Windows.Forms;
using WindowsInput;
using System.IO;
using System.Text;
using System.Runtime.InteropServices;
using ReadWriteMemoryTools;
using System.Runtime.Serialization.Formatters.Binary;

namespace RPG_Beta6_2Controls
{
   partial class win_Chat_Commands : Form
   {
      public static string FileName = "settings.rpg_txt";
      public static bool Key_Val_Changed = false;
      public static bool Enable_Shrtcts = true;

      [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode, Pack = 1)]
      public struct CMD_MODE
      {
         [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 20)]
         public string cmd_name;
         [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 50)]
         public string cmd_activate;
         [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 50)]
         public string cmd_on;
         [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 50)]
         public string cmd_off;

         public short toggle_key;
         public short on_key;
         public short off_key;

         public CMD_MODE(string name, string activate, string cmdon, string cmdoff, short togglekey, short onkey, short offkey)
         {
            this.cmd_name = name;
            this.cmd_activate = activate;
            this.cmd_on = cmdon;
            this.cmd_off = cmdoff;
            this.toggle_key = togglekey;
            this.on_key = onkey;
            this.off_key = offkey;
         }
      }

      [StructLayout(LayoutKind.Sequential, Pack = 1)]
      public struct CMDS
      {
         //public short size;
         [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
         public CMD_MODE[] halo;
         [MarshalAs(UnmanagedType.ByValArray, SizeConst = 6)]
         public CMD_MODE[] rpg_beta6_2;
      }

      public static CMDS commands;

      //default command keys//-1 is none
      [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
      public static CMD_MODE[] halo_commands =
      {
         new CMD_MODE("Dev Mode", "", "/dev 1", "/dev 0", -1, 33, 34),//size 346
         new CMD_MODE("Deathless", "", "/deathless 1", "/deathless 0", 97, -1, -1),//346
         new CMD_MODE("Infinite Ammo", "", "/infammo 1", "/infammo 0", 98, -1, -1),
         new CMD_MODE("Bottomless Clip", "", "/bottomless 1", "/bottomless 0", -1, -1, -1),
         new CMD_MODE("Show Hud", "", "/hud 1", "/hud 0", 99, -1, -1),
         new CMD_MODE("LetterBox", "", "/letterbox 1", "/letterbox 0", 100, -1, -1),
         new CMD_MODE("Movie Mode", "", "/movie 1", "/movie 0", -1, -1, -1),
         new CMD_MODE("Marines Hud", "", "/mhud 1", "/mhud 0", 101, -1, -1),
         new CMD_MODE("Rider Ejection", "", "/ejection 1", "/ejection 0", -1, -1, -1)
      };

      [MarshalAs(UnmanagedType.ByValArray, SizeConst = 6)]
      public static CMD_MODE[] rpg_beta6_2_commands =
      {
         new CMD_MODE("Setting", "/day", "/rain", "/night", 102, -1, -1),
         new CMD_MODE("Air Base Alarm", "", "/alarm 1", "/alarm 0", 103, -1, -1),
         new CMD_MODE("Air Base LockDown", "/start lockdown", "", "", 104, -1, -1),
         new CMD_MODE("Fire Halo", "/fire halo", "", "", 105, -1, -1),
         new CMD_MODE("LockDown Timer", "/lockdown timer", "", "", -1, -1, -1),
         new CMD_MODE("Fire Halo Timer", "/halo timer", "", "", -1, -1, -1)
      };

      public static short Deathless_key = 97;
      public static short IF_key = 98;
      public static short btmless_key = -1;
      public static short Hud_key = 99;
      public static short Letterbox_key = 100;
      public static short movie_key = -1;
      public static short MHud_key = 101;

      public static short Setting_key = 102;
      public static short Alarm_key = 103;
      public static short Lockdown_key = 104;
      public static short FHalo_key = 105;

      public static void GetSettingsFromFile()
      {
         //get settings from file first if file exists
         if (File.Exists(FileName))
         {
            FileStream settings_file = new FileStream(@FileName, FileMode.Open);
            //StreamReader SR = new StreamReader(FileName);
            /*BinaryReader br = new BinaryReader(settings_file);

            int i = 0;
            for (int index = 0; index < halo_commands.Length; index++)
            {
               byte[] buf = new byte[Marshal.SizeOf(halo_commands[index])];
               br.Read(buf, i++, Marshal.SizeOf(halo_commands[index]));
               halo_commands[index] = RWMemory.RawDeserialize<CMD_MODE>(buf, 0);
               
            }

            for (int index = 0; index < rpg_beta6_2_commands.Length; index++)
            {
               byte[] buf = new byte[Marshal.SizeOf(rpg_beta6_2_commands[index])];
               br.Read(buf, i++, Marshal.SizeOf(rpg_beta6_2_commands[index]));
               rpg_beta6_2_commands[index] = RWMemory.RawDeserialize<CMD_MODE>(buf, 0);
            }
            br.Close();*/
            //BinaryFormatter bf = new BinaryFormatter();
            //bf.Serialize(settings_file, 
            settings_file.Close();
            //halo_commands = 
            /*halo_commands[0].on_key = short.Parse(SR.ReadLine());
            halo_commands[0].off_key = short.Parse(SR.ReadLine());
            halo_commands[1].toggle_key = short.Parse(SR.ReadLine());
            IF_key = short.Parse(SR.ReadLine());
            btmless_key = short.Parse(SR.ReadLine());
            Hud_key = short.Parse(SR.ReadLine());
            Letterbox_key = short.Parse(SR.ReadLine());
            MHud_key = short.Parse(SR.ReadLine());
            Setting_key = short.Parse(SR.ReadLine());
            Alarm_key = short.Parse(SR.ReadLine());
            Lockdown_key = short.Parse(SR.ReadLine());
            FHalo_key = short.Parse(SR.ReadLine());
            Enable_Shrtcts = bool.Parse(SR.ReadLine());*/
            //SR.Close();
         }
      }

      public win_Chat_Commands()
      {
         InitializeComponent();
         this.deathless_key_btn.Text = WindowsInputDeviceStateAdaptor.Get_Key_Name(Deathless_key);
         this.DevOn_key_btn.Text = WindowsInputDeviceStateAdaptor.Get_Key_Name(halo_commands[0].on_key);
         this.DevOff_key_btn.Text = WindowsInputDeviceStateAdaptor.Get_Key_Name(halo_commands[0].off_key);
         this.IF_key_btn.Text = WindowsInputDeviceStateAdaptor.Get_Key_Name(IF_key);
         this.bottomless_key_btn.Text = WindowsInputDeviceStateAdaptor.Get_Key_Name(btmless_key);
         this.hud_key_btn.Text = WindowsInputDeviceStateAdaptor.Get_Key_Name(Hud_key);
         this.letterbox_key_btn.Text = WindowsInputDeviceStateAdaptor.Get_Key_Name(Letterbox_key);
         this.mhud_key_btn.Text = WindowsInputDeviceStateAdaptor.Get_Key_Name(MHud_key);
         this.setting_key_btn.Text = WindowsInputDeviceStateAdaptor.Get_Key_Name(Setting_key);
         this.alarm_key_btn.Text = WindowsInputDeviceStateAdaptor.Get_Key_Name(Alarm_key);
         this.lockdown_key_btn.Text = WindowsInputDeviceStateAdaptor.Get_Key_Name(Lockdown_key);
         this.fhalo_key_btn.Text = WindowsInputDeviceStateAdaptor.Get_Key_Name(FHalo_key);

         if (Enable_Shrtcts)
         {
            this.Enable_shrtcts_chkBx.Checked = true;
            this.Enable_shrtcts_chkBx.CheckState = System.Windows.Forms.CheckState.Checked;
         }

         this.HaloCE_items_btn.Select();
         this.commands_lstBx.SelectedIndex = 0;

         //commands.halo = halo_commands;
         //commands.rpg_beta6_2 = rpg_beta6_2_commands;
         //commands.size = 5492;
      }

      private void DevOn_key_btn_Click(object sender, EventArgs e)
      {
         short temp = halo_commands[0].on_key;
         ChangeKey f4 = new ChangeKey(ref halo_commands[0].on_key);
         f4.ShowDialog();

         while (f4.Visible) ;//pause
         DevOn_key_btn.Text = WindowsInputDeviceStateAdaptor.Get_Key_Name(halo_commands[0].on_key);

         if (temp != halo_commands[0].on_key)
            Key_Val_Changed = true;
      }

      private void DevOff_key_btn_Click(object sender, EventArgs e)
      {
         short temp = halo_commands[0].off_key;
         ChangeKey f4 = new ChangeKey(ref halo_commands[0].off_key);
         f4.ShowDialog();

         while (f4.Visible) ;//pause
         DevOff_key_btn.Text = WindowsInputDeviceStateAdaptor.Get_Key_Name(halo_commands[0].off_key);

         if (temp != halo_commands[0].off_key)
            Key_Val_Changed = true;
      }

      private void deathless_key_btn_Click(object sender, EventArgs e)
      {
         short temp = Deathless_key;
         ChangeKey f4 = new ChangeKey(ref Deathless_key);
         f4.ShowDialog();

         while (f4.Visible) ;//pause
         deathless_key_btn.Text = WindowsInputDeviceStateAdaptor.Get_Key_Name(Deathless_key);

         if (temp != Deathless_key)
            Key_Val_Changed = true;
      }

      private void IF_key_btn_Click(object sender, EventArgs e)
      {
         short temp = IF_key;
         ChangeKey f4 = new ChangeKey(ref IF_key);
         f4.ShowDialog();

         while (f4.Visible) ;//pause
         IF_key_btn.Text = WindowsInputDeviceStateAdaptor.Get_Key_Name(IF_key);

         if (temp != IF_key)
            Key_Val_Changed = true;
      }

      private void hud_key_btn_Click(object sender, EventArgs e)
      {
         short temp = Hud_key;
         ChangeKey f4 = new ChangeKey(ref Hud_key);
         f4.ShowDialog();

         while (f4.Visible) ;//pause
         hud_key_btn.Text = WindowsInputDeviceStateAdaptor.Get_Key_Name(Hud_key);

         if (temp != Hud_key)
            Key_Val_Changed = true;
      }

      private void letterbox_key_btn_Click(object sender, EventArgs e)
      {
         short temp = Letterbox_key;
         ChangeKey f4 = new ChangeKey(ref Letterbox_key);
         f4.ShowDialog();

         while (f4.Visible) ;//pause
         letterbox_key_btn.Text = WindowsInputDeviceStateAdaptor.Get_Key_Name(Letterbox_key);

         if (temp != Letterbox_key)
            Key_Val_Changed = true;
      }

      private void movie_key_btn_Click(object sender, EventArgs e)
      {
         short temp = movie_key;
         ChangeKey f4 = new ChangeKey(ref movie_key);
         f4.ShowDialog();

         while (f4.Visible) ;//pause
         movie_key_btn.Text = WindowsInputDeviceStateAdaptor.Get_Key_Name(movie_key);

         if (temp != movie_key)
            Key_Val_Changed = true;
      }

      private void mhud_key_btn_Click(object sender, EventArgs e)
      {
         short temp = MHud_key;
         ChangeKey f4 = new ChangeKey(ref MHud_key);
         f4.ShowDialog();

         while (f4.Visible) ;//pause
         mhud_key_btn.Text = WindowsInputDeviceStateAdaptor.Get_Key_Name(MHud_key);

         if (temp != MHud_key)
            Key_Val_Changed = true;
      }

      private void bottomless_key_btn_Click(object sender, EventArgs e)
      {
         short temp = btmless_key;
         ChangeKey f4 = new ChangeKey(ref btmless_key);
         f4.ShowDialog();

         while (f4.Visible) ;//pause
         bottomless_key_btn.Text = WindowsInputDeviceStateAdaptor.Get_Key_Name(btmless_key);

         if (temp != btmless_key)
            Key_Val_Changed = true;
      }

      private void setting_key_btn_Click(object sender, EventArgs e)
      {
         short temp = Setting_key;
         ChangeKey f4 = new ChangeKey(ref Setting_key);
         f4.ShowDialog();

         while (f4.Visible) ;//pause
         setting_key_btn.Text = WindowsInputDeviceStateAdaptor.Get_Key_Name(Setting_key);

         if (temp != Setting_key)
            Key_Val_Changed = true;
      }

      private void alarm_key_btn_Click(object sender, EventArgs e)
      {
         short temp = Alarm_key;
         ChangeKey f4 = new ChangeKey(ref Alarm_key);
         f4.ShowDialog();

         while (f4.Visible) ;//pause
         alarm_key_btn.Text = WindowsInputDeviceStateAdaptor.Get_Key_Name(Alarm_key);

         if (temp != Alarm_key)
            Key_Val_Changed = true;
      }

      private void lockdown_key_btn_Click(object sender, EventArgs e)
      {
         short temp = Lockdown_key;
         ChangeKey f4 = new ChangeKey(ref Lockdown_key);
         f4.ShowDialog();

         while (f4.Visible) ;//pause
         lockdown_key_btn.Text = WindowsInputDeviceStateAdaptor.Get_Key_Name(Lockdown_key);

         if (temp != Lockdown_key)
            Key_Val_Changed = true;
      }

      private void fhalo_key_btn_Click(object sender, EventArgs e)
      {
         short temp = FHalo_key;
         ChangeKey f4 = new ChangeKey(ref FHalo_key);
         f4.ShowDialog();

         while (f4.Visible) ;//pause
         fhalo_key_btn.Text = WindowsInputDeviceStateAdaptor.Get_Key_Name(FHalo_key);

         if (temp != FHalo_key)
            Key_Val_Changed = true;
      }

      public void AddText(FileStream fs, string value)
      {
         byte[] info = new ASCIIEncoding().GetBytes(value);
         fs.Write(info, 0, info.Length);
      }

      private void okButton_btn_Click(object sender, EventArgs e)
      {
         if (Key_Val_Changed)
         {
            Key_Val_Changed = false;

            //save key changes to file
            //unhide file to make changes
            if (File.Exists(FileName))
               File.SetAttributes(@FileName, File.GetAttributes(@FileName) & ~FileAttributes.Hidden);

            FileStream settings_file = new FileStream(@FileName, FileMode.Create);
            BinaryWriter bw = new BinaryWriter(settings_file);

            //byte[] buf = RWMemory.RawSerialize(commands, commands.size);
            byte[] buf = RWMemory.RawSerialize(commands);
            bw.Write(buf); 
            //buf = RWMemory.RawSerialize(rpg_beta6_2_commands);
            //bw.Write(buf);
            bw.Close();

            /*AddText(settings_file, halo_commands[0].on_key.ToString() + '\n' + halo_commands[0].off_key + '\n' + Deathless_key + '\n' + IF_key + '\n' +
                                   btmless_key + '\n' + Hud_key + '\n' + Letterbox_key + '\n' + MHud_key + '\n' + Setting_key + 
                                   '\n' + Alarm_key + '\n' + Lockdown_key + '\n' + FHalo_key + '\n' + Enable_shrtcts_chkBx.Checked);*/
            //hide file
            File.SetAttributes(@FileName, File.GetAttributes(@FileName) | FileAttributes.Hidden);
            settings_file.Close();
         }
      }

      private void Enable_shrtcts_chkBx_CheckedChanged(object sender, EventArgs e)
      {
         Key_Val_Changed = true;
         Enable_Shrtcts = Enable_shrtcts_chkBx.Checked;
      }

      private void commands_lstBx_SelectedIndexChanged(object sender, EventArgs e)
      {
         if (commands_lstBx.SelectedIndex != -1)
         {

         }
      }
   }
}
