﻿namespace RPG_Beta6_2Controls
{
    partial class win_Chat_Commands
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
           System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(win_Chat_Commands));
           this.okButton = new System.Windows.Forms.Button();
           this.label1 = new System.Windows.Forms.Label();
           this.label2 = new System.Windows.Forms.Label();
           this.label3 = new System.Windows.Forms.Label();
           this.label4 = new System.Windows.Forms.Label();
           this.deathless_key_btn = new System.Windows.Forms.Button();
           this.DevOn_key_btn = new System.Windows.Forms.Button();
           this.DevOff_key_btn = new System.Windows.Forms.Button();
           this.IF_key_btn = new System.Windows.Forms.Button();
           this.hud_key_btn = new System.Windows.Forms.Button();
           this.letterbox_key_btn = new System.Windows.Forms.Button();
           this.mhud_key_btn = new System.Windows.Forms.Button();
           this.setting_key_btn = new System.Windows.Forms.Button();
           this.alarm_key_btn = new System.Windows.Forms.Button();
           this.lockdown_key_btn = new System.Windows.Forms.Button();
           this.fhalo_key_btn = new System.Windows.Forms.Button();
           this.Enable_shrtcts_chkBx = new System.Windows.Forms.CheckBox();
           this.movie_key_btn = new System.Windows.Forms.Button();
           this.bottomless_key_btn = new System.Windows.Forms.Button();
           this.cmd_on_txtbx = new System.Windows.Forms.TextBox();
           this.cmd_off_txtbx = new System.Windows.Forms.TextBox();
           this.commands_lstBx = new System.Windows.Forms.ListBox();
           this.HaloCE_items_btn = new System.Windows.Forms.Button();
           this.RPG_Beta6_2_items_btn = new System.Windows.Forms.Button();
           this.label5 = new System.Windows.Forms.Label();
           this.cmd_off_btn = new System.Windows.Forms.Button();
           this.cmd_on_btn = new System.Windows.Forms.Button();
           this.on_lbl = new System.Windows.Forms.Label();
           this.off_lbl = new System.Windows.Forms.Label();
           this.toggle_onoff_btn = new System.Windows.Forms.Button();
           this.activate_lbl = new System.Windows.Forms.Label();
           this.activate_txtbx = new System.Windows.Forms.TextBox();
           this.SuspendLayout();
           // 
           // okButton
           // 
           this.okButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
           this.okButton.DialogResult = System.Windows.Forms.DialogResult.Cancel;
           this.okButton.Location = new System.Drawing.Point(683, 623);
           this.okButton.Name = "okButton";
           this.okButton.Size = new System.Drawing.Size(75, 22);
           this.okButton.TabIndex = 24;
           this.okButton.Text = "&OK";
           this.okButton.Click += new System.EventHandler(this.okButton_btn_Click);
           // 
           // label1
           // 
           this.label1.AutoSize = true;
           this.label1.BackColor = System.Drawing.Color.Transparent;
           this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
           this.label1.ForeColor = System.Drawing.Color.Black;
           this.label1.Location = new System.Drawing.Point(278, 9);
           this.label1.Name = "label1";
           this.label1.Size = new System.Drawing.Size(251, 17);
           this.label1.TabIndex = 25;
           this.label1.Text = "Chat Commands  |  keyboard shortcuts";
           // 
           // label2
           // 
           this.label2.AutoSize = true;
           this.label2.BackColor = System.Drawing.Color.Transparent;
           this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
           this.label2.ForeColor = System.Drawing.Color.Black;
           this.label2.Location = new System.Drawing.Point(334, 305);
           this.label2.Name = "label2";
           this.label2.Size = new System.Drawing.Size(185, 210);
           this.label2.TabIndex = 26;
           this.label2.Text = "RPG_Beta6_2:\r\n\r\n/day\r\n/rain\r\n/night\r\n\r\n/alarm 1\r\n\r\n/start lockdown\r\n\r\n/fire halo\r" +
               "\n\r\n/lockdown timer <num> <space>\r\n/halo timer <num> <space>";
           this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
           // 
           // label3
           // 
           this.label3.AutoSize = true;
           this.label3.BackColor = System.Drawing.Color.Transparent;
           this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
           this.label3.ForeColor = System.Drawing.Color.Black;
           this.label3.Location = new System.Drawing.Point(144, 318);
           this.label3.Name = "label3";
           this.label3.Size = new System.Drawing.Size(73, 225);
           this.label3.TabIndex = 27;
           this.label3.Text = "Halo CE:\r\n\r\n/dev 1\r\n\r\n/deathless 1\r\n\r\n/infammo 1\r\n\r\n/hud 1\r\n\r\n/letterbox 1\r\n\r\n/mo" +
               "vie 1\r\n\r\n/mhud 1";
           this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
           // 
           // label4
           // 
           this.label4.AutoSize = true;
           this.label4.BackColor = System.Drawing.Color.Transparent;
           this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
           this.label4.ForeColor = System.Drawing.Color.Black;
           this.label4.Location = new System.Drawing.Point(232, 287);
           this.label4.Name = "label4";
           this.label4.Size = new System.Drawing.Size(80, 15);
           this.label4.TabIndex = 28;
           this.label4.Text = "1 = on, 0 = off";
           this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
           // 
           // deathless_key_btn
           // 
           this.deathless_key_btn.BackColor = System.Drawing.SystemColors.Control;
           this.deathless_key_btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
           this.deathless_key_btn.Location = new System.Drawing.Point(235, 438);
           this.deathless_key_btn.Name = "deathless_key_btn";
           this.deathless_key_btn.Size = new System.Drawing.Size(78, 23);
           this.deathless_key_btn.TabIndex = 29;
           this.deathless_key_btn.Text = "NumPad 1";
           this.deathless_key_btn.UseVisualStyleBackColor = false;
           this.deathless_key_btn.Click += new System.EventHandler(this.deathless_key_btn_Click);
           // 
           // DevOn_key_btn
           // 
           this.DevOn_key_btn.BackColor = System.Drawing.SystemColors.Control;
           this.DevOn_key_btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
           this.DevOn_key_btn.Location = new System.Drawing.Point(235, 373);
           this.DevOn_key_btn.Name = "DevOn_key_btn";
           this.DevOn_key_btn.Size = new System.Drawing.Size(78, 23);
           this.DevOn_key_btn.TabIndex = 30;
           this.DevOn_key_btn.Text = "Pg Up";
           this.DevOn_key_btn.UseVisualStyleBackColor = false;
           this.DevOn_key_btn.Click += new System.EventHandler(this.DevOn_key_btn_Click);
           // 
           // DevOff_key_btn
           // 
           this.DevOff_key_btn.BackColor = System.Drawing.SystemColors.Control;
           this.DevOff_key_btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
           this.DevOff_key_btn.Location = new System.Drawing.Point(236, 399);
           this.DevOff_key_btn.Name = "DevOff_key_btn";
           this.DevOff_key_btn.Size = new System.Drawing.Size(78, 23);
           this.DevOff_key_btn.TabIndex = 31;
           this.DevOff_key_btn.Text = "Pg Dn";
           this.DevOff_key_btn.UseVisualStyleBackColor = false;
           this.DevOff_key_btn.Click += new System.EventHandler(this.DevOff_key_btn_Click);
           // 
           // IF_key_btn
           // 
           this.IF_key_btn.BackColor = System.Drawing.SystemColors.Control;
           this.IF_key_btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
           this.IF_key_btn.Location = new System.Drawing.Point(235, 467);
           this.IF_key_btn.Name = "IF_key_btn";
           this.IF_key_btn.Size = new System.Drawing.Size(78, 23);
           this.IF_key_btn.TabIndex = 32;
           this.IF_key_btn.Text = "NumPad 2";
           this.IF_key_btn.UseVisualStyleBackColor = false;
           this.IF_key_btn.Click += new System.EventHandler(this.IF_key_btn_Click);
           // 
           // hud_key_btn
           // 
           this.hud_key_btn.BackColor = System.Drawing.SystemColors.Control;
           this.hud_key_btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
           this.hud_key_btn.Location = new System.Drawing.Point(235, 496);
           this.hud_key_btn.Name = "hud_key_btn";
           this.hud_key_btn.Size = new System.Drawing.Size(78, 23);
           this.hud_key_btn.TabIndex = 33;
           this.hud_key_btn.Text = "NumPad 3";
           this.hud_key_btn.UseVisualStyleBackColor = false;
           this.hud_key_btn.Click += new System.EventHandler(this.hud_key_btn_Click);
           // 
           // letterbox_key_btn
           // 
           this.letterbox_key_btn.BackColor = System.Drawing.SystemColors.Control;
           this.letterbox_key_btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
           this.letterbox_key_btn.Location = new System.Drawing.Point(235, 525);
           this.letterbox_key_btn.Name = "letterbox_key_btn";
           this.letterbox_key_btn.Size = new System.Drawing.Size(78, 23);
           this.letterbox_key_btn.TabIndex = 34;
           this.letterbox_key_btn.Text = "NumPad 4";
           this.letterbox_key_btn.UseVisualStyleBackColor = false;
           this.letterbox_key_btn.Click += new System.EventHandler(this.letterbox_key_btn_Click);
           // 
           // mhud_key_btn
           // 
           this.mhud_key_btn.BackColor = System.Drawing.SystemColors.Control;
           this.mhud_key_btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
           this.mhud_key_btn.Location = new System.Drawing.Point(235, 583);
           this.mhud_key_btn.Name = "mhud_key_btn";
           this.mhud_key_btn.Size = new System.Drawing.Size(78, 23);
           this.mhud_key_btn.TabIndex = 35;
           this.mhud_key_btn.Text = "NumPad 5";
           this.mhud_key_btn.UseVisualStyleBackColor = false;
           this.mhud_key_btn.Click += new System.EventHandler(this.mhud_key_btn_Click);
           // 
           // setting_key_btn
           // 
           this.setting_key_btn.BackColor = System.Drawing.SystemColors.Control;
           this.setting_key_btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
           this.setting_key_btn.Location = new System.Drawing.Point(441, 350);
           this.setting_key_btn.Name = "setting_key_btn";
           this.setting_key_btn.Size = new System.Drawing.Size(78, 23);
           this.setting_key_btn.TabIndex = 36;
           this.setting_key_btn.Text = "NumPad 6";
           this.setting_key_btn.UseVisualStyleBackColor = false;
           this.setting_key_btn.Click += new System.EventHandler(this.setting_key_btn_Click);
           // 
           // alarm_key_btn
           // 
           this.alarm_key_btn.BackColor = System.Drawing.SystemColors.Control;
           this.alarm_key_btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
           this.alarm_key_btn.Location = new System.Drawing.Point(441, 391);
           this.alarm_key_btn.Name = "alarm_key_btn";
           this.alarm_key_btn.Size = new System.Drawing.Size(78, 23);
           this.alarm_key_btn.TabIndex = 37;
           this.alarm_key_btn.Text = "NumPad 7";
           this.alarm_key_btn.UseVisualStyleBackColor = false;
           this.alarm_key_btn.Click += new System.EventHandler(this.alarm_key_btn_Click);
           // 
           // lockdown_key_btn
           // 
           this.lockdown_key_btn.BackColor = System.Drawing.SystemColors.Control;
           this.lockdown_key_btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
           this.lockdown_key_btn.Location = new System.Drawing.Point(441, 420);
           this.lockdown_key_btn.Name = "lockdown_key_btn";
           this.lockdown_key_btn.Size = new System.Drawing.Size(78, 23);
           this.lockdown_key_btn.TabIndex = 38;
           this.lockdown_key_btn.Text = "NumPad 8";
           this.lockdown_key_btn.UseVisualStyleBackColor = false;
           this.lockdown_key_btn.Click += new System.EventHandler(this.lockdown_key_btn_Click);
           // 
           // fhalo_key_btn
           // 
           this.fhalo_key_btn.BackColor = System.Drawing.SystemColors.Control;
           this.fhalo_key_btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
           this.fhalo_key_btn.Location = new System.Drawing.Point(441, 450);
           this.fhalo_key_btn.Name = "fhalo_key_btn";
           this.fhalo_key_btn.Size = new System.Drawing.Size(78, 23);
           this.fhalo_key_btn.TabIndex = 39;
           this.fhalo_key_btn.Text = "NumPad 9";
           this.fhalo_key_btn.UseVisualStyleBackColor = false;
           this.fhalo_key_btn.Click += new System.EventHandler(this.fhalo_key_btn_Click);
           // 
           // Enable_shrtcts_chkBx
           // 
           this.Enable_shrtcts_chkBx.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
           this.Enable_shrtcts_chkBx.AutoSize = true;
           this.Enable_shrtcts_chkBx.Location = new System.Drawing.Point(569, 627);
           this.Enable_shrtcts_chkBx.Name = "Enable_shrtcts_chkBx";
           this.Enable_shrtcts_chkBx.Size = new System.Drawing.Size(107, 17);
           this.Enable_shrtcts_chkBx.TabIndex = 40;
           this.Enable_shrtcts_chkBx.Text = "Enable Shortcuts";
           this.Enable_shrtcts_chkBx.UseVisualStyleBackColor = true;
           this.Enable_shrtcts_chkBx.CheckedChanged += new System.EventHandler(this.Enable_shrtcts_chkBx_CheckedChanged);
           // 
           // movie_key_btn
           // 
           this.movie_key_btn.BackColor = System.Drawing.SystemColors.Control;
           this.movie_key_btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
           this.movie_key_btn.Location = new System.Drawing.Point(235, 554);
           this.movie_key_btn.Name = "movie_key_btn";
           this.movie_key_btn.Size = new System.Drawing.Size(78, 23);
           this.movie_key_btn.TabIndex = 41;
           this.movie_key_btn.Text = "none";
           this.movie_key_btn.UseVisualStyleBackColor = false;
           this.movie_key_btn.Click += new System.EventHandler(this.movie_key_btn_Click);
           // 
           // bottomless_key_btn
           // 
           this.bottomless_key_btn.BackColor = System.Drawing.SystemColors.Control;
           this.bottomless_key_btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
           this.bottomless_key_btn.Location = new System.Drawing.Point(235, 612);
           this.bottomless_key_btn.Name = "bottomless_key_btn";
           this.bottomless_key_btn.Size = new System.Drawing.Size(78, 23);
           this.bottomless_key_btn.TabIndex = 42;
           this.bottomless_key_btn.Text = "none";
           this.bottomless_key_btn.UseVisualStyleBackColor = false;
           this.bottomless_key_btn.Click += new System.EventHandler(this.bottomless_key_btn_Click);
           // 
           // cmd_on_txtbx
           // 
           this.cmd_on_txtbx.Location = new System.Drawing.Point(218, 106);
           this.cmd_on_txtbx.MaxLength = 50;
           this.cmd_on_txtbx.Name = "cmd_on_txtbx";
           this.cmd_on_txtbx.Size = new System.Drawing.Size(159, 20);
           this.cmd_on_txtbx.TabIndex = 43;
           this.cmd_on_txtbx.Text = "/dev 1";
           // 
           // cmd_off_txtbx
           // 
           this.cmd_off_txtbx.Location = new System.Drawing.Point(218, 132);
           this.cmd_off_txtbx.MaxLength = 50;
           this.cmd_off_txtbx.Name = "cmd_off_txtbx";
           this.cmd_off_txtbx.Size = new System.Drawing.Size(159, 20);
           this.cmd_off_txtbx.TabIndex = 44;
           this.cmd_off_txtbx.Text = "/dev 0";
           // 
           // commands_lstBx
           // 
           this.commands_lstBx.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
           this.commands_lstBx.FormattingEnabled = true;
           this.commands_lstBx.ItemHeight = 15;
           this.commands_lstBx.Items.AddRange(new object[] {
            "Dev Mode",
            "Deathless",
            "Infinite Ammo",
            "Bottomless Clip",
            "Show Hud",
            "LetterBox",
            "Movie Mode",
            "Marines Hud",
            "Rider Ejection",
            ""});
           this.commands_lstBx.Location = new System.Drawing.Point(5, 38);
           this.commands_lstBx.Name = "commands_lstBx";
           this.commands_lstBx.Size = new System.Drawing.Size(153, 154);
           this.commands_lstBx.TabIndex = 45;
           this.commands_lstBx.SelectedIndexChanged += new System.EventHandler(this.commands_lstBx_SelectedIndexChanged);
           // 
           // HaloCE_items_btn
           // 
           this.HaloCE_items_btn.Location = new System.Drawing.Point(5, 9);
           this.HaloCE_items_btn.Name = "HaloCE_items_btn";
           this.HaloCE_items_btn.Size = new System.Drawing.Size(56, 23);
           this.HaloCE_items_btn.TabIndex = 46;
           this.HaloCE_items_btn.Text = "Halo CE";
           this.HaloCE_items_btn.UseVisualStyleBackColor = true;
           // 
           // RPG_Beta6_2_items_btn
           // 
           this.RPG_Beta6_2_items_btn.Location = new System.Drawing.Point(67, 9);
           this.RPG_Beta6_2_items_btn.Name = "RPG_Beta6_2_items_btn";
           this.RPG_Beta6_2_items_btn.Size = new System.Drawing.Size(91, 23);
           this.RPG_Beta6_2_items_btn.TabIndex = 47;
           this.RPG_Beta6_2_items_btn.Text = "RPG_Beta6_2";
           this.RPG_Beta6_2_items_btn.UseVisualStyleBackColor = true;
           // 
           // label5
           // 
           this.label5.AutoSize = true;
           this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
           this.label5.Location = new System.Drawing.Point(373, 46);
           this.label5.Name = "label5";
           this.label5.Size = new System.Drawing.Size(132, 15);
           this.label5.TabIndex = 48;
           this.label5.Text = "Toggle On/Off | Activate";
           // 
           // cmd_off_btn
           // 
           this.cmd_off_btn.BackColor = System.Drawing.SystemColors.Control;
           this.cmd_off_btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
           this.cmd_off_btn.Location = new System.Drawing.Point(397, 130);
           this.cmd_off_btn.Name = "cmd_off_btn";
           this.cmd_off_btn.Size = new System.Drawing.Size(78, 23);
           this.cmd_off_btn.TabIndex = 50;
           this.cmd_off_btn.Text = "Pg Dn";
           this.cmd_off_btn.UseVisualStyleBackColor = false;
           // 
           // cmd_on_btn
           // 
           this.cmd_on_btn.BackColor = System.Drawing.SystemColors.Control;
           this.cmd_on_btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
           this.cmd_on_btn.Location = new System.Drawing.Point(397, 103);
           this.cmd_on_btn.Name = "cmd_on_btn";
           this.cmd_on_btn.Size = new System.Drawing.Size(78, 23);
           this.cmd_on_btn.TabIndex = 49;
           this.cmd_on_btn.Text = "Pg Up";
           this.cmd_on_btn.UseVisualStyleBackColor = false;
           // 
           // on_lbl
           // 
           this.on_lbl.AutoSize = true;
           this.on_lbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
           this.on_lbl.Location = new System.Drawing.Point(175, 107);
           this.on_lbl.Name = "on_lbl";
           this.on_lbl.Size = new System.Drawing.Size(21, 15);
           this.on_lbl.TabIndex = 51;
           this.on_lbl.Text = "on";
           // 
           // off_lbl
           // 
           this.off_lbl.AutoSize = true;
           this.off_lbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
           this.off_lbl.Location = new System.Drawing.Point(176, 133);
           this.off_lbl.Name = "off_lbl";
           this.off_lbl.Size = new System.Drawing.Size(20, 15);
           this.off_lbl.TabIndex = 52;
           this.off_lbl.Text = "off";
           // 
           // toggle_onoff_btn
           // 
           this.toggle_onoff_btn.BackColor = System.Drawing.SystemColors.Control;
           this.toggle_onoff_btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
           this.toggle_onoff_btn.Location = new System.Drawing.Point(397, 64);
           this.toggle_onoff_btn.Name = "toggle_onoff_btn";
           this.toggle_onoff_btn.Size = new System.Drawing.Size(78, 23);
           this.toggle_onoff_btn.TabIndex = 53;
           this.toggle_onoff_btn.Text = "none";
           this.toggle_onoff_btn.UseVisualStyleBackColor = false;
           // 
           // activate_lbl
           // 
           this.activate_lbl.AutoSize = true;
           this.activate_lbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
           this.activate_lbl.Location = new System.Drawing.Point(164, 68);
           this.activate_lbl.Name = "activate_lbl";
           this.activate_lbl.Size = new System.Drawing.Size(48, 15);
           this.activate_lbl.TabIndex = 54;
           this.activate_lbl.Text = "activate";
           // 
           // activate_txtbx
           // 
           this.activate_txtbx.Location = new System.Drawing.Point(218, 67);
           this.activate_txtbx.MaxLength = 50;
           this.activate_txtbx.Name = "activate_txtbx";
           this.activate_txtbx.Size = new System.Drawing.Size(159, 20);
           this.activate_txtbx.TabIndex = 55;
           // 
           // win_Chat_Commands
           // 
           this.AcceptButton = this.okButton;
           this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
           this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
           this.BackColor = System.Drawing.Color.White;
           this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
           this.ClientSize = new System.Drawing.Size(770, 650);
           this.Controls.Add(this.activate_txtbx);
           this.Controls.Add(this.activate_lbl);
           this.Controls.Add(this.toggle_onoff_btn);
           this.Controls.Add(this.off_lbl);
           this.Controls.Add(this.on_lbl);
           this.Controls.Add(this.cmd_off_btn);
           this.Controls.Add(this.cmd_on_btn);
           this.Controls.Add(this.label5);
           this.Controls.Add(this.RPG_Beta6_2_items_btn);
           this.Controls.Add(this.HaloCE_items_btn);
           this.Controls.Add(this.commands_lstBx);
           this.Controls.Add(this.cmd_off_txtbx);
           this.Controls.Add(this.cmd_on_txtbx);
           this.Controls.Add(this.bottomless_key_btn);
           this.Controls.Add(this.movie_key_btn);
           this.Controls.Add(this.Enable_shrtcts_chkBx);
           this.Controls.Add(this.fhalo_key_btn);
           this.Controls.Add(this.lockdown_key_btn);
           this.Controls.Add(this.alarm_key_btn);
           this.Controls.Add(this.setting_key_btn);
           this.Controls.Add(this.mhud_key_btn);
           this.Controls.Add(this.letterbox_key_btn);
           this.Controls.Add(this.hud_key_btn);
           this.Controls.Add(this.IF_key_btn);
           this.Controls.Add(this.DevOff_key_btn);
           this.Controls.Add(this.DevOn_key_btn);
           this.Controls.Add(this.deathless_key_btn);
           this.Controls.Add(this.label4);
           this.Controls.Add(this.label2);
           this.Controls.Add(this.label1);
           this.Controls.Add(this.okButton);
           this.Controls.Add(this.label3);
           this.DoubleBuffered = true;
           this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
           this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
           this.MaximizeBox = false;
           this.MinimizeBox = false;
           this.Name = "win_Chat_Commands";
           this.Padding = new System.Windows.Forms.Padding(9);
           this.ShowIcon = false;
           this.ShowInTaskbar = false;
           this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
           this.Text = "Commands";
           this.ResumeLayout(false);
           this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button okButton;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        public System.Windows.Forms.Button deathless_key_btn;
        public System.Windows.Forms.Button DevOn_key_btn;
        public System.Windows.Forms.Button DevOff_key_btn;
        public System.Windows.Forms.Button IF_key_btn;
        public System.Windows.Forms.Button hud_key_btn;
        public System.Windows.Forms.Button letterbox_key_btn;
        public System.Windows.Forms.Button mhud_key_btn;
        public System.Windows.Forms.Button setting_key_btn;
        public System.Windows.Forms.Button alarm_key_btn;
        public System.Windows.Forms.Button lockdown_key_btn;
        public System.Windows.Forms.Button fhalo_key_btn;
        public System.Windows.Forms.CheckBox Enable_shrtcts_chkBx;
        public System.Windows.Forms.Button movie_key_btn;
        public System.Windows.Forms.Button bottomless_key_btn;
        public System.Windows.Forms.TextBox cmd_on_txtbx;
        public System.Windows.Forms.TextBox cmd_off_txtbx;
        public System.Windows.Forms.ListBox commands_lstBx;
        public System.Windows.Forms.Button HaloCE_items_btn;
        public System.Windows.Forms.Button RPG_Beta6_2_items_btn;
        private System.Windows.Forms.Label label5;
        public System.Windows.Forms.Button cmd_off_btn;
        public System.Windows.Forms.Button cmd_on_btn;
        public System.Windows.Forms.Label on_lbl;
        public System.Windows.Forms.Label off_lbl;
        public System.Windows.Forms.Button toggle_onoff_btn;
        public System.Windows.Forms.Label activate_lbl;
        public System.Windows.Forms.TextBox activate_txtbx;
    }
}
