﻿/********************************************************************************
	 -- Halo Dev Controls
    Copyright © 2011 Jesus7Freak

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*********************************************************************************
	File:    ChangeKey.cs
	Project: Halo Dev Controls C#
	Author:  Jesus7Freak
	Date:    11/22/2011
	Game:    Halo and Halo Custom Edition
	Version: all
*********************************************************************************/
using System;
//dec 5th 61
using System.Windows.Forms;
using WindowsInput;

namespace RPG_Beta6_2Controls
{
   public partial class ChangeKey : Form
   {
      public unsafe static short *Orig_Key = null;

      public ChangeKey()
      {
         InitializeComponent();
      }

      public unsafe ChangeKey(ref short key)
      {
         InitializeComponent();
         fixed (short *key_addr = &key)
         {
            Orig_Key = key_addr;//C# is not pointer friendly...
            this.keycode_txtbx.Text = Orig_Key->ToString();
            this.keycode_lbl.Text = WindowsInputDeviceStateAdaptor.Get_Key_Name(*Orig_Key);
            this.keycode_hex_txtbx.Text = "0x" + Orig_Key->ToString("X");
         }
      }

      private void keycode_txtbx_KeyDown(object sender, KeyEventArgs e)
      {
         e.SuppressKeyPress = true;
         keycode_txtbx.Text = e.KeyValue.ToString();
         keycode_hex_txtbx.Text = "0x" + e.KeyValue.ToString("X");
         keycode_lbl.Text = WindowsInputDeviceStateAdaptor.Get_Key_Name(short.Parse(keycode_txtbx.Text));
      }

      private void ok_btn_Click(object sender, EventArgs e)
      {
         short key = short.Parse(keycode_txtbx.Text);
         unsafe { *Orig_Key = key; }
         this.Close();
      }

      private void none_btn_Click(object sender, EventArgs e)
      {
         keycode_txtbx.Text = (-1).ToString();
         keycode_hex_txtbx.Text = "0x" + ((short)-1).ToString("X");
         keycode_lbl.Text = "none";
      }
   }
}
