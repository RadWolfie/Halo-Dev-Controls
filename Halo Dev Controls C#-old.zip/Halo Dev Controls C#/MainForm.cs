﻿/********************************************************************************
	 -- Halo Dev Controls
    Copyright © 2011 Jesus7Freak

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*********************************************************************************
	File:    MainForm.cs
	Project: Halo Dev Controls C#
	Author:  Jesus7Freak
	Date:    11/22/2011
	Game:    Halo and Halo Custom Edition
	Version: all
*********************************************************************************/
using System;
using System.Windows.Forms;
using System.Threading;
using System.Drawing;
using System.Text;
using WindowsInput;
using ReadWriteMemoryTools;

namespace RPG_Beta6_2Controls
{
   public partial class MainForm : Form
   {
      public RWMemory RWM;
      public InputSimulator sim;
      public HaloCE_lib HaloCE;
      public Halo_Lib Halo;
      public HCE_Lib HCE;

      public enum game_types : byte
      {
         not_running = 0,
         Halo = 1,
         HCE = 2
      }

      game_types running_gt;

      public string chat;
      public int Chat_address, itemp = 0;
      public byte C_Setting = 0;
      public short Lock_sec = 0, Halo_sec = 0;
      public bool rpgb6_2_running = false, erase_chat = false, temp,
          ishost = true, exception = false; 
      
      //modes on/off
      public bool bottomless_on = false, movie_mode_on = false;

      //patterns found
      public bool dev_pat_found = false, cma_pat_found = false, deathl_pat_found = false,
          bpa_pat_found = false, cap_pat_found = false, cons_pat_found = false,
          sha_pat_found = false, lb_ptr_pat_found = false;

      public uint scan_size = 0;

      public ADDRESS_SIG Dev_sig;
      public IntPtr Dev_address = IntPtr.Zero;

      public ADDRESS_SIG cma_sig;
      public IntPtr Current_Map_address = IntPtr.Zero;

      public IntPtr Deathless_address = IntPtr.Zero;
      public IntPtr Infinite_Ammo_address = IntPtr.Zero;
      public IntPtr Bottomless_Ammo_address = IntPtr.Zero;
      public IntPtr Base_ptr_address = IntPtr.Zero;
      public IntPtr chat_address_ptr = IntPtr.Zero;
      public IntPtr Console_address = IntPtr.Zero;
      public IntPtr Show_Hud_address = IntPtr.Zero;
      public IntPtr Letterbox_address = IntPtr.Zero;

      public MainForm()
      {
         sim = new InputSimulator();
         win_Chat_Commands.GetSettingsFromFile();
         InitializeComponent();
      }

      private void update_info_timer_Tick(object sender, EventArgs e)
      {
         if (RWMemory.IsProcessOpen("halo"/*, "Halo"*/) == 1)
         {
            running_gt = game_types.Halo;

            scan_size = Halo_Lib.scan_size;

            cma_sig = Halo_Lib.Current_map_addr_sig;

            status_lbl.Text = "Halo";
            RWM = new RWMemory("halo");
         }
         else if (RWMemory.IsProcessOpen("haloce"/*, "Halo"*/) == 1)
         {
            running_gt = game_types.HCE;

            scan_size = HCE_Lib.scan_size;

            cma_sig = HCE_Lib.Current_map_addr_sig;

            status_lbl.Text = "Halo CE";
            RWM = new RWMemory("haloce");
         }
         else
         {
            running_gt = game_types.not_running;
            rpgb6_2_running = false;

            status_lbl.Text = "Halo CE";
            status_lbl2.Text = "Off";
            status_lbl2.ForeColor = Color.Red;

            status_lbl4.Text = status_lbl3.Text = "";

            dev_pat_found = false;
            cma_pat_found = false;
            deathl_pat_found = false;
            bpa_pat_found = false;
            cap_pat_found = false;
            cons_pat_found = false;
            sha_pat_found = false;
            lb_ptr_pat_found = false;

            Current_Map_address = IntPtr.Zero;
            Dev_address = IntPtr.Zero;
            Deathless_address = IntPtr.Zero;
            Infinite_Ammo_address = IntPtr.Zero;
            Bottomless_Ammo_address = IntPtr.Zero;
            Base_ptr_address = IntPtr.Zero;
            Console_address = IntPtr.Zero;
            Show_Hud_address = IntPtr.Zero;
            Letterbox_address = IntPtr.Zero;
         }

         dev_btn.Enabled = running_gt != game_types.not_running;
         showhud_chkBx.Enabled = running_gt != game_types.not_running;
         letterbox_chkBx.Enabled = running_gt != game_types.not_running;
         rcon_lbl.Enabled = running_gt != game_types.not_running;
         MV_chkBx.Enabled = running_gt != game_types.not_running;

         Deathless_chkBx.Enabled = ishost && running_gt != game_types.not_running;
         IF_chkBx.Enabled = ishost && running_gt != game_types.not_running;

         //rpg_beta6_2 functions
         ToD_cb.Enabled = ishost && rpgb6_2_running;
         alarm_btn.Enabled = ishost && rpgb6_2_running;
         BLD_lbl.Enabled = ishost && rpgb6_2_running;
         BLD_timer_txt.Enabled = ishost && rpgb6_2_running;
         BLD_activate.Enabled = ishost && rpgb6_2_running;
         halo_lbl.Enabled = ishost && rpgb6_2_running;
         halo_timer_txt.Enabled = ishost && rpgb6_2_running;
         halo_activate.Enabled = ishost && rpgb6_2_running;

         //enable set btns if text is a number
         if (BLD_timer_txt.Text != "seconds")
            BLD_set_t.Enabled = ishost && rpgb6_2_running;
         if (halo_timer_txt.Text != "seconds")
            halo_set_t.Enabled = ishost && rpgb6_2_running;

         if (running_gt != game_types.not_running)
         {
            status_lbl2.Text = "On";
            status_lbl2.ForeColor = Color.Green;
            status_lbl3.Text = "Map:";
            status_lbl4.Text = RWM.ReadMemString(Current_Map_address, new ASCIIEncoding());

            //find patterns
            if (!cma_pat_found)
            {
               uint CMA_ptr = RWM.FindMemPattern(
                               HaloCE_lib.base_address,
                               scan_size,
                               cma_sig);
               Current_Map_address = (IntPtr)RWM.ReadMemInt((IntPtr)CMA_ptr);

               if (Current_Map_address != IntPtr.Zero)
                  cma_pat_found = true;
            }

            if (!cons_pat_found)
            {
               uint console_ptr = RWM.FindMemPattern(
                                   HaloCE_lib.base_address,
                                   scan_size,
                                   HaloCE_lib.Console_addr_sig);
               Console_address = (IntPtr)RWM.ReadMemInt((IntPtr)console_ptr);

               if (Console_address != IntPtr.Zero)
                  cons_pat_found = true;
            }

            if (!dev_pat_found)
            {
               uint Dev_ptr = RWM.FindMemPattern(
                               HaloCE_lib.base_address,
                               scan_size,
                               HCE_Lib.Dev_addr_sig);
               Dev_address = (IntPtr)RWM.ReadMemInt((IntPtr)Dev_ptr);

               if (Dev_address != IntPtr.Zero)
                  dev_pat_found = true;
            }

            if (!deathl_pat_found)
            {
               uint mem_region_ptr = RWM.FindMemPattern(
                                       HaloCE_lib.base_address,
                                       scan_size,
                                       HaloCE_lib.Deathless_addr_sig);
               int mem_region = RWM.ReadMemInt((IntPtr)mem_region_ptr);
               Deathless_address = (IntPtr)mem_region;
               Infinite_Ammo_address = (IntPtr)(mem_region + 2);
               Bottomless_Ammo_address = (IntPtr)(mem_region + 9);

               if (mem_region != 0)
                  deathl_pat_found = true;
            }

            if (!bpa_pat_found)
            {
               uint BPA_ptr = RWM.FindMemPattern(
                               HaloCE_lib.base_address,
                               scan_size,
                               HaloCE_lib.Base_ptr_addr_sig);
               Base_ptr_address = (IntPtr)RWM.ReadMemInt((IntPtr)BPA_ptr);

               if (Base_ptr_address != IntPtr.Zero)
                  bpa_pat_found = true;
            }

            if (!sha_pat_found)
            {
               uint SHp_ptr = RWM.FindMemPattern(
                               HaloCE_lib.base_address,
                               scan_size,
                               HaloCE_lib.Show_Hud_ptr_addr_sig);
               Show_Hud_address = (IntPtr)RWM.ReadMemInt((IntPtr)RWM.ReadMemInt((IntPtr)SHp_ptr));

               if (Show_Hud_address != IntPtr.Zero)
                  sha_pat_found = true;
            }

            if (!lb_ptr_pat_found)
            {
               uint lb_ptr = RWM.FindMemPattern(
                   HaloCE_lib.base_address,
                   scan_size,
                   HaloCE_lib.letterbox_ptr_addr_sig);
               Letterbox_address = (IntPtr)(RWM.ReadMemInt((IntPtr)RWM.ReadMemInt((IntPtr)lb_ptr)) + 8);

               if (Letterbox_address != (IntPtr)8)
                  lb_ptr_pat_found = true;
            }

            //enable console if not already
            if (RWM.ReadMemByte((IntPtr)Console_address) != 1)
               RWM.WriteMemByte((IntPtr)Console_address, 1);

            if (RWM.ReadMemByte((IntPtr)HCE_Lib.Dev_address) == 1)
            {
               dev_btn.Text = "Turn Dev off";
               dev_btn.ForeColor = Color.Green;//Chartreuse;
            }
            else
            {
               dev_btn.Text = "Turn Dev on";
               dev_btn.ForeColor = Color.Red;
            }

            //update deathless value
            if (Deathless_chkBx.Checked != (temp = RWM.ReadMemBool(Deathless_address)))
               Deathless_chkBx.Checked = temp;

            //update infinite ammo value
            if (IF_chkBx.Checked != (temp = RWM.ReadMemBool(Infinite_Ammo_address)))
               IF_chkBx.Checked = temp;

            //update show hud value
            if (showhud_chkBx.Checked != (temp = RWM.ReadMemBool(Show_Hud_address)))
               showhud_chkBx.Checked = temp;

            //update letter box value
            if (letterbox_chkBx.Checked != (temp = RWM.ReadMemBool(Letterbox_address)))
               letterbox_chkBx.Checked = temp;

            //update marine view value
            if (MV_chkBx.Checked != (temp = RWM.ReadMemBool((IntPtr)HCE_Lib.Cinematic_address)))
               MV_chkBx.Checked = temp;

            //update host/client lbl
            /*if (RWM.ReadMemBool((IntPtr)HCE_Lib.Server_Check))
            {
                rcon_lbl.ForeColor = Color.Green;
                rcon_lbl.Text = "Hosting";
                ishost = true;
            }
            else
            {
                rcon_lbl.ForeColor = Color.Red;
                rcon_lbl.Text = "Client";
                ishost = false;
            }*/


            //keyboard shortcuts
            if (win_Chat_Commands.Enable_Shrtcts)
            {
               //dev on
               if (sim.InputDeviceState.IsKeyDown((Keys)win_Chat_Commands.halo_commands[0].on_key))
               {
                  if (dev_btn.Text == "Turn Dev on")
                     dev_btn.PerformClick();
               }
               //dev off
               if (sim.InputDeviceState.IsKeyDown((Keys)win_Chat_Commands.halo_commands[0].off_key))
               {
                  if (dev_btn.Text == "Turn Dev off")
                     dev_btn.PerformClick();
               }

               if (ishost)
               {
                  //deathless on/off
                  if (sim.InputDeviceState.IsHardwareKeyDown((Keys)win_Chat_Commands.Deathless_key))
                     Deathless_chkBx.Checked = !Deathless_chkBx.Checked;

                  //infinite ammo on/off
                  if (sim.InputDeviceState.IsHardwareKeyDown((Keys)win_Chat_Commands.IF_key))
                     IF_chkBx.Checked = !IF_chkBx.Checked;

                  //bottomless ammo on/off
                  if (sim.InputDeviceState.IsHardwareKeyDown((Keys)win_Chat_Commands.btmless_key))
                     toggle_bottomless_on(!bottomless_on);
               }

               //hud on/off
               if (sim.InputDeviceState.IsHardwareKeyDown((Keys)win_Chat_Commands.Hud_key))
                  showhud_chkBx.Checked = !showhud_chkBx.Checked;

               //letterbox on/off
               if (sim.InputDeviceState.IsHardwareKeyDown((Keys)win_Chat_Commands.Letterbox_key))
                  letterbox_chkBx.Checked = !letterbox_chkBx.Checked;

               //movie mode on/off
               if (sim.InputDeviceState.IsHardwareKeyDown((Keys)win_Chat_Commands.movie_key))
                  toggle_movie_mode_on(!movie_mode_on);

               //marnies hud on/off
               if (sim.InputDeviceState.IsHardwareKeyDown((Keys)win_Chat_Commands.MHud_key))
                  MV_chkBx.Checked = !MV_chkBx.Checked;
            }


            //check for in game chat commands///
            //Chat_address = HCE_Lib.Console_Buffer_address;
            chat_address_ptr = (IntPtr)(RWM.ReadMemInt(
                    (IntPtr)(RWM.ReadMemInt(
                    (IntPtr)(RWM.ReadMemInt(
                    (IntPtr)(RWM.ReadMemInt(
                    Base_ptr_address) + 0xA0)) + 0x34)) + 0x80)) + 0x94);

            Chat_address = RWM.ReadMemInt(chat_address_ptr);
            chat = RWM.ReadMemString((IntPtr)Chat_address, new UnicodeEncoding());

            if (chat.Length > 5)
            {
               temp = false;
               if (chat == "/dev 1")
               {
                  exception = true;
                  erase_chat = true;
                  if (dev_btn.Text == "Turn Dev on")
                     dev_btn.PerformClick();
               }
               else if (chat == "/dev 0")
               {
                  exception = true;
                  erase_chat = true;
                  if (dev_btn.Text == "Turn Dev off")
                     dev_btn.PerformClick();
               }

               else if (chat == "/deathless 1")
               {
                  erase_chat = true;
                  if (ishost)
                     Deathless_chkBx.Checked = true;
               }
               else if (chat == "/deathless 0")
               {
                  erase_chat = true;
                  if (ishost)
                     Deathless_chkBx.Checked = false;
               }
               else if (chat == "/infammo 1")
               {
                  erase_chat = true;
                  if (ishost)
                     IF_chkBx.Checked = true;
               }
               else if (chat == "/infammo 0")
               {
                  erase_chat = true;
                  if (ishost)
                     IF_chkBx.Checked = false;
               }
               else if (chat == "/bottomless 1")
               {
                  erase_chat = true;
                  if (ishost)
                     toggle_bottomless_on(true);
               }
               else if (chat == "/bottomless 0")
               {
                  erase_chat = true;
                  if (ishost)
                     toggle_bottomless_on(false);
               }
               else if (chat == "/hud 1")
               {
                  exception = true;
                  erase_chat = true;
                  showhud_chkBx.Checked = true;
                  temp = true;
               }
               else if (chat == "/hud 0")
               {
                  exception = true;
                  erase_chat = true;
                  showhud_chkBx.Checked = false;
                  temp = true;
               }
               else if (chat == "/letterbox 1")
               {
                  exception = true;
                  erase_chat = true;
                  letterbox_chkBx.Checked = true;
                  temp = true;
               }
               else if (chat == "/letterbox 0")
               {
                  exception = true;
                  erase_chat = true;
                  letterbox_chkBx.Checked = false;
                  temp = true;
               }
               else if (chat == "/movie 1")
               {
                  exception = true;
                  erase_chat = true;
                  letterbox_chkBx.Checked = true;
                  showhud_chkBx.Checked = false;
                  temp = true;
               }
               else if (chat == "/movie 0")
               {
                  exception = true;
                  erase_chat = true;
                  letterbox_chkBx.Checked = false;
                  showhud_chkBx.Checked = true;
                  temp = true;
               }
               else if (chat == "/mhud 1")
               {
                  exception = true;
                  erase_chat = true;
                  MV_chkBx.Checked = true;
                  temp = true;
               }
               else if (chat == "/mhud 0")
               {
                  exception = true;
                  erase_chat = true;
                  MV_chkBx.Checked = false;
                  temp = true;
               }
            }


            //test for rpg_beta6_2 map///////////////////////////////////////
            if (RWM.ReadMemString(Current_Map_address, new ASCIIEncoding()) != "rpg_beta6_2")
            {
               rpgb6_2_running = false;
               status_lbl4.ForeColor = Color.Red;
            }
            else
            {
               rpgb6_2_running = true;
               status_lbl4.ForeColor = Color.Green;

               if (halo_timer_txt.Mask != "000")
               {
                  BLD_timer_txt.Mask = "000";
                  halo_timer_txt.Mask = "000";
               }

               //update alarm button
               if (RWM.ReadMemBool((IntPtr)HCE_Lib.Alarm_Check_address))
                  alarm_btn.Text = "Alarm Off";
               else
                  alarm_btn.Text = "Alarm On";

               //update setting
               if (C_Setting != RWM.ReadMemByte((IntPtr)HCE_Lib.Setting_address))
               {
                  C_Setting = RWM.ReadMemByte((IntPtr)HCE_Lib.Setting_address);
                  if (C_Setting >= 0 && C_Setting <= 2)
                     ToD_cb.SelectedIndex = C_Setting;
               }

               //update lockdown timer
               if (Lock_sec != RWM.ReadMemShort((IntPtr)HCE_Lib.Lock_Timer_address))
               {
                  Lock_sec = RWM.ReadMemShort((IntPtr)HCE_Lib.Lock_Timer_address);
                  BLD_timer_txt.Text = (Lock_sec / 30).ToString();
               }

               //update lockdown button
               if (!RWM.ReadMemBool((IntPtr)HCE_Lib.Locked_address))
               {
                  BLD_activate.ForeColor = SystemColors.Highlight;
                  BLD_activate.Text = "Activate";
               }
               else
               {
                  BLD_activate.ForeColor = Color.Red;
                  BLD_activate.Text = "Locked";
               }

               //update fire halo button
               if (!RWM.ReadMemBool((IntPtr)HCE_Lib.Nuked_address))
               {
                  halo_activate.ForeColor = SystemColors.Highlight;
                  halo_activate.Text = "Activate";
               }
               else
               {
                  halo_activate.ForeColor = Color.Red;
                  halo_activate.Text = "Cool Down";
               }

               //update halo timer
               if (Halo_sec != RWM.ReadMemShort((IntPtr)HCE_Lib.Boom_Timer_address))
               {
                  Halo_sec = RWM.ReadMemShort((IntPtr)HCE_Lib.Boom_Timer_address);
                  halo_timer_txt.Text = (Halo_sec / 30).ToString();
               }


               //keyboard shortcuts
               if (win_Chat_Commands.Enable_Shrtcts && ishost)
               {
                  //setting
                  if (sim.InputDeviceState.IsHardwareKeyDown((Keys)win_Chat_Commands.Setting_key))
                     if (ToD_cb.SelectedIndex != 2)
                        ToD_cb.SelectedIndex = ToD_cb.SelectedIndex + 1;
                     else
                        ToD_cb.SelectedIndex = ToD_cb.SelectedIndex - 2;

                  //alarm on/off
                  if (sim.InputDeviceState.IsHardwareKeyDown((Keys)win_Chat_Commands.Alarm_key))
                     alarm_btn.PerformClick();

                  //lockdown
                  if (sim.InputDeviceState.IsHardwareKeyDown((Keys)win_Chat_Commands.Lockdown_key))
                     BLD_activate.PerformClick();

                  //fire halo
                  if (sim.InputDeviceState.IsHardwareKeyDown((Keys)win_Chat_Commands.FHalo_key))
                     halo_activate.PerformClick();

               }

               //check for rpg_beta chat commands//
               if (chat.Length >= 4)
               {
                  if (chat == "/day")//for chat add \0
                  {
                     erase_chat = true;
                     if (ishost)
                        ToD_cb.SelectedIndex = 0;
                  }
                  else if (chat == "/rain")
                  {
                     erase_chat = true;
                     if (ishost)
                        ToD_cb.SelectedIndex = 1;
                  }
                  else if (chat == "/night")
                  {
                     erase_chat = true;
                     if (ishost)
                        ToD_cb.SelectedIndex = 2;
                  }
                  else if (chat == "/alarm 1")
                  {
                     erase_chat = true;
                     if (ishost && alarm_btn.Text == "Alarm On")
                        alarm_btn.PerformClick();
                  }
                  else if (chat == "/alarm 0")
                  {
                     erase_chat = true;
                     if (ishost && alarm_btn.Text == "Alarm Off")
                        alarm_btn.PerformClick();
                  }
                  else if (chat == "/start lockdown")
                  {
                     erase_chat = true;
                     if (ishost)
                        BLD_activate.PerformClick();
                  }
                  else if (chat == "/fire halo")
                  {
                     erase_chat = true;
                     if (ishost)
                        halo_activate.PerformClick();
                  }
                  else if (chat.Length > 16)///lockdown timer <num> 
                  {
                     if (chat[0] == '/' && chat.Contains("/lockdown timer "))
                     {
                        if (chat[chat.Length - 1] == ' ' && chat.Length != 16)
                        {
                           //remove /lockdown timer from string
                           chat = chat.Remove(0, 16);
                           //remove the last space at the end
                           chat = chat.Remove(chat.Length - 1);

                           erase_chat = true;
                           //make sure its a within the range and a valid number
                           if (chat.Length <= 5 && int.TryParse(chat, out itemp))
                           {
                              if (ishost)
                              {
                                 BLD_timer_txt.Text = chat;
                                 BLD_set_t.PerformClick();
                              }
                           }
                           else
                           {
                              OpenConsole();
                              RWM.WriteMemString((IntPtr)HCE_Lib.Console_Buffer_address, "sv_say \"Error: is not a valid number\"\0", new ASCIIEncoding());
                              PressEnterKey(2);
                           }
                        }
                     }

                  }
                  else if (chat.Length > 12)///halo timer <num> 
                  {
                     if (chat[0] == '/' && chat.Contains("/halo timer "))
                     {
                        if (chat[chat.Length - 1] == ' ' && chat.Length != 12)
                        {
                           //remove /lockdown timer from string
                           chat = chat.Remove(0, 12);
                           //remove the last space at the end
                           chat = chat.Remove(chat.Length - 1);

                           //make sure its a valid number
                           if (chat.Length <= 5 && int.TryParse(chat, out itemp))
                           {
                              erase_chat = true;
                              if (ishost)
                              {
                                 halo_timer_txt.Text = chat;
                                 halo_set_t.PerformClick();
                              }
                           }
                           else
                           {
                              OpenConsole();
                              RWM.WriteMemString((IntPtr)HCE_Lib.Console_Buffer_address, "sv_say \"Error: is not a valid number\"\0", new ASCIIEncoding());
                              PressEnterKey(2);
                           }
                        }
                     }
                  }

               }
            }////////////////////////////////////////////////////////////////
            if (erase_chat && !ishost && !temp && !exception)
            {
               RWM.WriteMemString((IntPtr)Chat_address, "You need to be hosting to use this command\0", new UnicodeEncoding());
               erase_chat = false;
            }
            if (erase_chat)
            {
               exception = false;
               PressEnterKey(1);
               erase_chat = false;
               RWM.WriteMemString((IntPtr)Chat_address, "\0", new UnicodeEncoding());
            }
         }
      }

      public void PressEnterKey(byte times)
      {
         for (byte i = 0; i < times; i++)
         {
            Thread.Sleep(200);
            NativeMethods.keybd_event(Keys.Return, 0x1C, 0, UIntPtr.Zero);
            Thread.Sleep(200);
            NativeMethods.keybd_event(Keys.Return, 0x1C, KeyboardFlag.KeyUp, UIntPtr.Zero);
         }
      }

      public void OpenConsole()
      {

         if (!RWM.ReadMemBool((IntPtr)HCE_Lib.Console_Check_address))
         {
            NativeMethods.keybd_event(Keys.Return, 0x29, 0, UIntPtr.Zero);
            Thread.Sleep(200);
            NativeMethods.keybd_event(Keys.Return, 0x29, KeyboardFlag.KeyUp, UIntPtr.Zero);
         }
      }

      private void dev_btn_Click(object sender, EventArgs e)
      {
         RWM.WriteMemBool((IntPtr)HCE_Lib.Dev_address, !RWM.ReadMemBool((IntPtr)HCE_Lib.Dev_address));
      }

      private void Deathless_chkBx_CheckedChanged(object sender, EventArgs e)
      {
         RWM.WriteMemBool(Deathless_address, Deathless_chkBx.Checked);
      }

      private void IF_chkBx_CheckedChanged(object sender, EventArgs e)
      {
         RWM.WriteMemBool(Infinite_Ammo_address, IF_chkBx.Checked);
      }

      private void showhud_chkBx_CheckedChanged(object sender, EventArgs e)
      {
         RWM.WriteMemBool(Show_Hud_address, showhud_chkBx.Checked);
      }

      private void letterbox_chkBx_CheckedChanged(object sender, EventArgs e)
      {
         RWM.WriteMemBool(Letterbox_address, letterbox_chkBx.Checked);
      }

      private void MV_chkBx_CheckedChanged(object sender, EventArgs e)
      {
         if (RWM.ReadMemByte((IntPtr)HCE_Lib.Marine_View_f_address) == 0)// && NativeMethods.GetForegroundWindow() == RWMemory.OpenProcess((uint)RWMemory.PAccessFlags.VMRead, 1, RWM.ProcessId))
         {
            //turn dev on for function
            if (dev_btn.Text == "Turn Dev on")
               dev_btn.PerformClick();

            OpenConsole();
            RWM.WriteMemString((IntPtr)HCE_Lib.Console_Buffer_address, "cinematic_screen_effect_set_video 0 1\0", new ASCIIEncoding());
            PressEnterKey(2);
         }

         RWM.WriteMemBool((IntPtr)HCE_Lib.Cinematic_address, MV_chkBx.Checked);
      }


      private void BLD_set_t_Click(object sender, EventArgs e)
      {
         short seconds = 30;
         seconds *= short.Parse(BLD_timer_txt.Text);

         RWM.WriteMemShort((IntPtr)HCE_Lib.Lock_Timer_address, seconds);

      }

      private void BLD_activate_Click(object sender, EventArgs e)
      {
         if (!RWM.ReadMemBool((IntPtr)HCE_Lib.Locked_address))
            RWM.WriteMemInt((IntPtr)HCE_Lib.Lock_Control_address, 1);
         else
         {

            //RWM.WriteMemBool(HCE_Lib.Locked, false);
         }
      }

      private void e_cb_SelectedIndexChanged(object sender, EventArgs e)
      {
         RWM.WriteMemByte((IntPtr)HCE_Lib.Setting_address, (byte)ToD_cb.SelectedIndex);
      }

      private void alarm_btn_Click(object sender, EventArgs e)
      {
         RWM.WriteMemInt((IntPtr)HCE_Lib.Alarm_Control_2_address, 1);
         //RWM.WriteMemInt(HCE_Lib.Alarm_Control_3_address, 1);
         //RWM.WriteMemInt(HCE_Lib.Alarm_Control_4_address, 1);
         //RWM.WriteMemInt(HCE_Lib.Alarm_Control_1_address, 1);
      }

      private void halo_set_t_Click(object sender, EventArgs e)
      {
         short seconds = 30;
         seconds *= short.Parse(halo_timer_txt.Text);

         RWM.WriteMemShort((IntPtr)HCE_Lib.Boom_Timer_address, seconds);
      }

      private void halo_activate_Click(object sender, EventArgs e)
      {
         if (!RWM.ReadMemBool((IntPtr)HCE_Lib.Nuked_address))
            RWM.WriteMemInt((IntPtr)HCE_Lib.Boom_Control_address, 1);
         else
         {

         }
      }

      private void Help_about_Click(object sender, EventArgs e)
      {
         win_About f2 = new win_About();
         f2.ShowDialog();
      }

      private void Help_commands_Click(object sender, EventArgs e)
      {
         win_Chat_Commands f3 = new win_Chat_Commands();
         f3.ShowDialog();
      }

      private void toggle_movie_mode_on(bool _on)
      {
         letterbox_chkBx.Checked = _on;
         showhud_chkBx.Checked = !_on;

         movie_mode_on = _on;
      }

      private void toggle_bottomless_on(bool _on)
      {
         RWM.WriteMemBool(Bottomless_Ammo_address, _on);
         bottomless_on = _on;
      }
   }
}


/*halo ce 1.09 memory addresses offset by +0xE8 from v1.08
    
 *  402AB038 is for halo red team speed <float>
 * 
 * 402AAFC0 short, at main menu? 1 is true
 * 
 * 402AAFB4 short, max number of slots/players in server
 * 402AAFC2 short, # of players in server
 * 

*/