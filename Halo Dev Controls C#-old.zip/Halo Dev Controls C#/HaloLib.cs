﻿/********************************************************************************
	 -- Halo Dev Controls
    Copyright © 2011 Jesus7Freak

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*********************************************************************************
	File:    HaloLib.cs
	Project: Halo Dev Controls C#
	Author:  Steve(Del) and Jesus7Freak
	Date:    11/22/2011
	Game:    Halo and Halo Custom Edition
	Version: all
 
  
  credit to Steve(Del)... for the player info structures 
*********************************************************************************/
using System;
using System.Text;
using ReadWriteMemoryTools;
using System.Runtime.InteropServices;

/// <summary>
/// contains info that are the same in both games, v1.09
/// </summary>
public class HaloCE_lib
{
   public const uint base_address = 0x00401000;

   public static ADDRESS_SIG Console_addr_sig = new ADDRESS_SIG(
       new byte[] { 0xD6, 0x5E, 0x88, 0x1D, 0x00, 0x00, 0x00, 0x00, 0x5B, 0xC3 },
       "xxxx????xx", 4);

   public static ADDRESS_SIG Base_ptr_addr_sig = new ADDRESS_SIG(
       new byte[] { 0x8B, 0x0D, 0x00, 0x00, 0x00, 0x00, 0x50, 0x51, 0xC7, 0x05, 0x00, 0x00, 0x00, 0x00 },
       "xx????xxxx????", 2);

   public static ADDRESS_SIG Deathless_addr_sig = new ADDRESS_SIG(
       new byte[] { 0x74, 0x09, 0x80, 0x3D, 0x00, 0x00, 0x00, 0x00, 0x00 },
       "xxxx????x", 4);

   public static ADDRESS_SIG Show_Hud_ptr_addr_sig = new ADDRESS_SIG(
       new byte[] { 0x8B, 0x0D, 0x00, 0x00, 0x00, 0x00, 0x85, 0xC9, 0x0F, 0x84, 0x00, 0x00, 0x00, 0x00, 0x80 },
       "xx????xxxx????x", 2);

   //offset ptr by 8
   public static ADDRESS_SIG letterbox_ptr_addr_sig = new ADDRESS_SIG(
       new byte[] { 0x0F, 0x84, 0x00, 0x00, 0x00, 0x00, 0xA1, 0x00, 0x00, 0x00, 0x00, 0x8A, 0x48 },
       "xx????x????xx", 7);
};

/// <summary>
/// Halo Combat Evolved specific info, v1.09
/// </summary>
public class Halo_Lib
{
   public const uint scan_size = 0x239000;

   public static ADDRESS_SIG Current_map_addr_sig = new ADDRESS_SIG(
       new byte[] { 0x7F, 0x1F, 0xB8, 0x00, 0x00, 0x00, 0x00 },
       "xxx????", 3);

   public static int Deathless_address = 0x87A840;//byte
   public static int Infinite_Ammo_address = 0x87A842;//byte
   public static int Bottomless_address = 0x87A849;//byte
};

/// <summary>
/// Halo Custom Edition specific info, v1.09
/// </summary>
public class HCE_Lib
{
   public const uint scan_size = 0x1DE000;

   public static int Rider_Eject_address = 0x006249AC;//byte

   public static int Dev_address = 0x006BD17E;//byte
   public static ADDRESS_SIG Dev_addr_sig = new ADDRESS_SIG(
       new byte[] { 0x8A, 0x0D, 0x00, 0x00, 0x00, 0x00, 0x80, 0xE2, 0x07, 0x84, 0xC9 },
       "xx????xxxxx", 2);

   //halo ce 1.09, 0xE8 offset fro, 1.08
   public static int Console_address = 0x00651F71;//byte

   public static int Console_Buffer_address = 0x00652028;//string, size = 61
   public static int Console_Check_address = 0x00651F70;//byte

   public static int Current_Map_address = 0x00643084;//string
   public static ADDRESS_SIG Current_map_addr_sig = new ADDRESS_SIG(
       new byte[] { 0x7F, 0x22, 0xB8, 0x00, 0x00, 0x00, 0x00 },
       "xxx????", 3);

   public static int Deathless_address = 0x00815D80;//byte  64AC0
   public static int Infinite_Ammo_address = 0x00815D82;//byte
   public static int Bottomless_Ammo_address = 0x00815D89;//byte
   //0049753F
   //006B44C8
   public static int Show_Hud_address = 0x400003BC;//byte


   public static int LetterBox_address = 0x403FD678;//byte

   //is server or client?
   public static int Server_Check = 0x0068CDB8;

   //console can remember your last 8 commands
   public static int C_Buffer_address1 = 0x0065272E;//strings, size = 61
   public static int C_Buffer_address2 = 0x0065282D;
   public static int C_Buffer_address3 = 0x00652134;
   public static int C_Buffer_address4 = 0x00652233;
   public static int C_Buffer_address5 = 0x00652332;
   public static int C_Buffer_address6 = 0x00652431;
   public static int C_Buffer_address7 = 0x00652530;
   public static int C_Buffer_address8 = 0x0065262F;


   //00714E7C //00712542
   public static int Rcon_Pass_address = 0x006B74C0;//string
   public static int Edit_Name_Buffer = 0x006AFF2A;//11 character unicode string

   public static int StaticPlayerHeader_address = 0x402AAF94;//Static_Player_Header
   public static int Server_chat_address = 0x404D2239;


   //marine view
   public static int Marine_View_f_address = 0x4000017F;//byte
   public static int MV_fparameter2_address = 0x40000188;//float
   public static int Cinematic_address = 0x40000194;//byte

   //rpg_beta6_2
   public static int Alarm_Control_1_address = 0x40027164;//float
   public static int Boom_Control_address = 0x40027174;//float
   public static int Alarm_Control_2_address = 0x40027184;//float
   public static int Alarm_Control_3_address = 0x40027194;//float
   public static int Alarm_Control_4_address = 0x400271A4;//float
   public static int Lock_Control_address = 0x400271B4;//float

   public static int Alarm_Check_address = 0x403D8EC3;//int

   public static int Lock_Timer_address = 0x403FACE4;//short
   public static int Boom_Timer_address = 0x403FACEC;//short
   public static int Setting_address = 0x403FACD4;//byte

   //stop lockdown prematurely
   public static int Locked_address = 0x403FACBC;//byte
   //lockdown positions
   public static int LD1_pos_address = 0x400967B0;//float
   public static int LD2_pos_address = 0x40091A10;//float
   public static int LD3_pos_address = 0x40096AF4;//float
   public static int LD4_pos_address = 0x40090880;//float
   public static int LD5_pos_address = 0x4008F6BC;//float
   public static int LD6_pos_address = 0x4008F998;//float
   public static int LD7_pos_address = 0x4008FC74;//float
   public static int LD8_pos_address = 0x4008FF50;//float
   public static int LD9_pos_address = 0x40090260;//float
   public static int LD10_pos_address = 0x40090570;//float
   //lockdown power
   public static int LD1_pow_address = 0x4002712C;//float
   public static int LD2_pow_address = 0x40026F6C;//float
   public static int LD3_pow_address = 0x4002713C;//float
   public static int LD4_pow_address = 0x40026F0C;//float
   public static int LD5_pow_address = 0x40026EAC;//float
   public static int LD6_pow_address = 0x40026EBC;//float
   public static int LD7_pow_address = 0x4008FC68;//float
   public static int LD8_pow_address = 0x4008FF44;//float
   public static int LD9_pow_address = 0x40090254;//float

   //stop halo cooldown prematurely
   public static int Nuked_address = 0x403FACCC;//byte

   //credit to Steve(Del)... for the player info structures
   [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi)]
   public struct Static_Player_Header
   {
      [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 32)]
      public string TName;       // 'players'
      public ushort MaxSlots;//+0x20        // Max number of slots/players possible
      public ushort SlotSize;//+0x22        // Size of each Static_Player struct
      public uint Unknown;//+0x24          // always 1?
      [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 4)]
      public string Data;//+0x28  // '@t@d' - translated as 'data'?
      public ushort InMainMenu;//+0x2C    // 0 = in game 1 = in main menu / not in game
      public ushort SlotsTaken;//+0x2E      // or # of players
      public ushort NextPlayerIndex;//+0x30 // Index # of the next player to join
      public ushort NextPlayerID;//+0x32    // ID # of the next player to join
      public uint Static_Player_Ptr;//+0x34      // Pointer to the first static player
   };

   [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
   public struct Static_Player//512bytes 0x402AAFCC
   {
      public ushort PlayerID;           // Stats at 0x70EC
      public short IsLocalPlayer;//+0x2               // 0 = local -1 = not
      [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 0xC)]
      public string PlayerName0;//+0x4           // Unicode / Max - 11 Chars + EOS (12 total)
      public int Unknown0;//+0x1C                     // Always -1 / 0xFFFFFFFF
      public uint Team;//+0x20               // 0 = Red / 1 = Blue
      public int SwapID;//+0x24              // ObjectID
      public ushort SwapType;//+0x28           // 8 = Vehicle / 6 = Weapon
      public short SwapSeat;//+0x2A                    // Warthog - Driver = 0 / Passenger = 1 / Gunner = 2 / Weapon = -1
      public uint RespawnTimer;//+0x2C        // ?????? Counts down when dead, Alive = 0
      public uint Unknown1;//+0x30           // Always 0
      public ushort ObjectIndexNum;//+0x34
      public ushort ObjectID;//+0x36           // Matches against object table
      public uint Unknown3;//+0x38            // Some sort of ID
      public uint LocationID;//+0x3C          // This is very, very interesting. BG is split into 25 location ID's. 1 -19
      public int Unknown4;//+0x40                     // Always -1 / 0xFFFFFFFF
      public uint BulletCount;//+0x44         // Something to do with bullets increases - weird.
      [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 0xC)]
      public string PlayerName1;//+0x48           // Unicode / Max - 11 Chars + EOS (12 total)
      public uint Unknown5;//+0x60           // 02 00 FF FF
      public ushort PlayerIndex;//+0x64
      public ushort Uknown55;//+0x66
      public uint Unknown6;//+0x68            // Zero's?
      public float SpeedModifier;//+0x6C               // Normal = 1
      [MarshalAs(UnmanagedType.ByValArray, SizeConst = 0x6C)]
      public byte[] Unknown7;//+0x70
      public ushort Ping;//+0xDC   
      [MarshalAs(UnmanagedType.ByValArray, SizeConst = 0x122)]
      public byte[] Unknown8;//+0xDE
   };

   //public unsafe Static_Player_Header* StaticPlayerHeader;
   //public unsafe Static_Player** StaticPlayer;

   /*public haloce_lib()
   {
       unsafe
       {
           sysdiag Rmemory = new sysdiag();
           IntPtr handle = PMRApi.OpenProcess(0x0010, 1, Rmemory.ProcessId), read;

           PMRApi.ReadProcessMemoryhl(handle, (IntPtr)StaticPlayerHeader_address, StaticPlayerHeader, (uint)sizeof(Static_Player_Header), out read);

           //StaticPlayerHeader = (Static_Player_Header*)StaticPlayerHeader_address;

           for (uint i = 0; i < StaticPlayerHeader->SlotsTaken; i++)
               StaticPlayer[i] = (Static_Player*)(StaticPlayerHeader->FirstPlayer + (i * 512));
       }
   }*/

   /*public bool IsHost()
   {
       byte player_index = 0; bool host = false;

       unsafe
       {
           while (StaticPlayer[player_index]->IsLocalPlayer != 0)
               player_index++;

           if (StaticPlayer[player_index]->Ping == 0)
               host = true;
       }

       return host;
   }*/

   //use check if player is local
   public static bool IsHost()
   {
      byte player_index = 0; bool host = false;
      RWMemory RWM = new RWMemory("haloce");

      while (RWM.ReadMemShort((IntPtr)(0x402AAFCE + (player_index * 200))) != 0)
         player_index++;

      if (RWM.ReadMemShort((IntPtr)(0x402AB0A8 + (player_index * 200))) == 0)
         host = true;

      return host;
   }
}
/*
xx????xxxxxx
xx????xx????xxx
xxxxxxx????
xx????xx????xxxxxx
 */
