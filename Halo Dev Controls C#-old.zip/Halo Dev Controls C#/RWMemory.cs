﻿/********************************************************************************
	 -- Read Write Memory Tools
    Copyright © 2011 Jesus7Freak

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*********************************************************************************
	File:    RWMemory.cs
	Project: Halo Dev Controls C#
	Author:  Jesus7Freak
	Date:    11/22/2011
	Version: 2.01
*********************************************************************************/
//made in .NET 3.5 (would be 4.0, but thats really expensive)
using System;
using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Text;
using System.Windows.Forms;
using System.Security.Principal;
using System.Reflection.Emit;

namespace ReadWriteMemoryTools
{
   public class ADDRESS_SIG
   {
      public byte[] pattern;
      public string mask;
      public byte offset;

      public ADDRESS_SIG(byte[] pat, string msk, byte offst)
      {
         this.pattern = pat;
         this.mask = msk;
         this.offset = offst;
      }
   }

   public class RWMemory
   {
      public const int version = 201;

      private Process P;
      public int LastWin32Error;

      #region Constructors
      public RWMemory() { P = null; }

      public RWMemory(string process_name)
      {
         Process[] process = Process.GetProcessesByName(process_name);

         //to prevent array out of bounds error when the process is killed
         if (process.Length > 0)
            P = process[0];
      }

      public RWMemory(string process_name, byte process_to_use)
      {
         Process[] process = Process.GetProcessesByName(process_name);

         //to prevent array out of bounds error when the process is killed
         if (process.Length > 0)
            P = process[process_to_use];
      }

      public RWMemory(Process process)
      {
         if (process != null)
            P = process;

         //Process.EnterDebugMode();
         //Enable_SeDebugPrivilege();
      }
      #endregion

      public Process CurrentProcess
      {
         get { return this.P; }
      }

      #region Static Functions
      public static byte IsProcessOpen(string Process_name)
      {
         byte processes_found = 0;
         Process[] clsProcess = Process.GetProcesses();

         for (int i = 0; i < clsProcess.Length; i++)
         {
            try
            {
               if (clsProcess[i].ProcessName == Process_name)
                  processes_found++;
            }
            catch { }
         }
         return processes_found;
      }

      public static byte IsProcessOpen(string Process_name, string window_name)
      {
         byte processes_found = 0;
         Process[] clsProcess = Process.GetProcesses();

         for (int i = 0; i < clsProcess.Length; i++)
         {
            try
            {
               if (clsProcess[i].ProcessName == Process_name)
                  if (clsProcess[i].MainWindowTitle == window_name)
                     processes_found++;
            }
            catch { }
         }
         return processes_found;
      }

      public static byte IsWindowOpen(string window_name)
      {
         byte processes_found = 0;

         Process[] clsProcess = Process.GetProcesses();

         for (int i = 0; i < clsProcess.Length; i++)
         {
            try
            {
               if (clsProcess[i].MainWindowTitle == window_name)
                  processes_found++;
            }
            catch { }
         }
         return processes_found;
      }

      /// <summary>
      /// converts a byte array into any type
      /// http://bytes.com/topic/c-sharp/answers/249770-byte-structure
      /// </summary>
      /// <param name="rawData"></param>
      /// <param name="position">the position into the byte array to start deserializing</param>
      /// <param name="anyType"></param>
      /// <returns></returns>
      public static T RawDeserialize<T>(byte[] rawData, int position)
      {
         int rawsize = Marshal.SizeOf(typeof(T));
         if (rawsize > rawData.Length)
            return default(T);
         IntPtr buffer = Marshal.AllocHGlobal(rawsize);
         Marshal.Copy(rawData, position, buffer, rawsize);

         object retobj = Marshal.PtrToStructure(buffer, typeof(T));
         Marshal.FreeHGlobal(buffer);
         return (T)retobj;
      }

      /// <summary>
      /// converts any type into a byte array
      /// http://bytes.com/topic/c-sharp/answers/249770-byte-structure
      /// </summary>
      /// <param name="anything">what to convert</param>
      /// <returns>byte array of that type</returns>
      public static byte[] RawSerialize(object anything)
      {
         int rawSize = Marshal.SizeOf(anything);
         IntPtr buffer = Marshal.AllocHGlobal(rawSize);
         Marshal.StructureToPtr(anything, buffer, false);
         byte[] rawDatas = new byte[rawSize];
         Marshal.Copy(buffer, rawDatas, 0, rawSize);
         Marshal.FreeHGlobal(buffer);
         return rawDatas;
      }

      public static byte[] RawSerialize(object anything, int rawSize)
      {
         IntPtr buffer = Marshal.AllocHGlobal(rawSize);
         Marshal.StructureToPtr(anything, buffer, false);
         byte[] rawDatas = new byte[rawSize];
         Marshal.Copy(buffer, rawDatas, 0, rawSize);
         Marshal.FreeHGlobal(buffer);
         return rawDatas;
      }

      #endregion
      #region WindowsAPIs
      [Flags]
      public enum PAccessFlags : uint
      {
         All = 0x001F0FFF,
         Terminate = 0x00000001,
         CreateThread = 0x00000002,
         Set_SessionID = 0x0004,
         VMOperation = 0x00000008,
         VMRead = 0x00000010,
         VMWrite = 0x00000020,
         DupHandle = 0x00000040,
         SetInformation = 0x00000200,
         QueryInformation = 0x00000400,
         Synchronize = 0x00100000
      }

      [Flags]
      public enum SnapshotFlags : uint
      {
         HeapList = 0x00000001,
         Process = 0x00000002,
         Thread = 0x00000004,
         Module = 0x00000008,
         Module32 = 0x00000010,
         Inherit = 0x80000000,
         All = 0x0000001F
      }

      [StructLayoutAttribute(LayoutKind.Sequential)]
      public struct MODULEENTRY32
      {
         public uint dwSize;
         public uint th32ModuleID;
         public uint th32ProcessID;
         public uint GlblcntUsage;
         public uint ProccntUsage;
         public IntPtr modBaseAddr;
         public uint modBaseSize;
         public IntPtr hModule;
         [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 256)]
         public string szModule;
         [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 260)]
         public string szExePath;
      };

      [Flags]
      public enum AllocationType
      {
         Commit = 0x1000,
         Reserve = 0x2000,
         Decommit = 0x4000,
         Release = 0x8000,
         Reset = 0x80000,
         Physical = 0x400000,
         TopDown = 0x100000,
         WriteWatch = 0x200000,
         LargePages = 0x20000000
      }

      [Flags]
      public enum MemoryProtection
      {
         Execute = 0x10,
         ExecuteRead = 0x20,
         ExecuteReadWrite = 0x40,
         ExecuteWriteCopy = 0x80,
         NoAccess = 0x01,
         ReadOnly = 0x02,
         ReadWrite = 0x04,
         WriteCopy = 0x08,
         GuardModifierflag = 0x100,
         NoCacheModifierflag = 0x200,
         WriteCombineModifierflag = 0x400
      }

      const UInt32 INFINITE = 0xFFFFFFFF;

      //http://msdn.microsoft.com/en-us/library/ms684320(v=vs.85).aspx
      [DllImport("kernel32.dll", SetLastError = true)]
      public static extern IntPtr OpenProcess(
          PAccessFlags dwDesiredAccess,
          bool bInheritHandle,
          int dwProcessId);

      //http://msdn.microsoft.com/en-us/library/ms724211(v=vs.85).aspx
      [DllImport("kernel32.dll", SetLastError = true)]
      public static extern bool CloseHandle(IntPtr hObject);

      //http://msdn.microsoft.com/en-us/library/ms680553(v=vs.85).aspx
      [DllImport("kernel32.dll", SetLastError = true)]
      public static extern bool ReadProcessMemory(
          IntPtr hProcess,
          IntPtr lpBaseAddress,
          [Out] byte[] buffer,
          UInt32 size,
          out int lpNumberOfBytesRead);

      //http://msdn.microsoft.com/en-us/library/ms681674(v=vs.85).aspx
      [DllImport("kernel32.dll", SetLastError = true)]
      public static extern bool WriteProcessMemory(
          IntPtr hProcess,
          IntPtr lpBaseAddress,
          byte[] buffer,
          UInt32 size,
          out int lpNumberOfBytesRead);

      //http://msdn.microsoft.com/en-us/library/ms683212(v=vs.85).aspx
      [DllImport("kernel32.dll", SetLastError = true)]
      public static extern IntPtr GetProcAddress(IntPtr hModule, string lpProcName);

      //http://msdn.microsoft.com/en-us/library/ms683199(v=vs.85).aspx
      [DllImport("kernel32.dll", SetLastError = true)]
      public static extern IntPtr GetModuleHandle(string lpModuleName);

      //http://msdn.microsoft.com/en-us/library/ms682489(v=vs.85).aspx
      [DllImport("kernel32.dll", SetLastError = true)]
      public static extern IntPtr CreateToolhelp32Snapshot(SnapshotFlags dwFlags, int th32ProcessID);

      //http://msdn.microsoft.com/en-us/library/ms684218(v=vs.85).aspx
      [DllImport("kernel32.dll", SetLastError = true)]
      static public extern bool Module32First(IntPtr hSnapshot, ref MODULEENTRY32 lpme);

      //http://msdn.microsoft.com/en-us/library/ms684221(VS.85).aspx
      [DllImport("kernel32.dll", SetLastError = true)]
      static public extern bool Module32Next(IntPtr hSnapshot, ref MODULEENTRY32 lpme);

      //http://msdn.microsoft.com/en-us/library/aa366890(v=vs.85).aspx
      [DllImport("kernel32.dll", SetLastError = true, ExactSpelling = true)]
      public static extern IntPtr VirtualAllocEx(
          IntPtr hProcess,
          IntPtr lpAddress,
          uint dwSize,
          AllocationType flAllocationType,
          MemoryProtection flProtect);

      //http://msdn.microsoft.com/en-us/library/aa366894(v=vs.85).aspx
      [DllImport("kernel32.dll", SetLastError = true)]
      public static extern bool VirtualFreeEx(
          IntPtr hProcess,
          IntPtr lpAddress,
          uint dwsize,
          AllocationType dwFreeType);

      //http://msdn.microsoft.com/en-us/library/aa366899(v=vs.85).aspx
      [DllImport("kernel32.dll", SetLastError = true)]
      public static extern bool VirtualProtectEx(
          IntPtr hProcess,
          IntPtr lpAddress,
          uint dwSize,
          MemoryProtection flNewProtect,
          out MemoryProtection lpflOldProtect);

      //http://msdn.microsoft.com/en-us/library/ms682437(v=vs.85).aspx
      [DllImport("kernel32.dll", SetLastError = true)]
      public static extern IntPtr CreateRemoteThread(
          IntPtr hProcess,
          IntPtr lpThreadAttributes,
          uint dwStackSize,
          IntPtr lpStartAddress,
          IntPtr lpParameter,
          uint dwCreationFlags,
          out uint lpThreadId);

      //http://msdn.microsoft.com/en-us/library/ms687032(v=vs.85).aspx
      [DllImport("kernel32.dll", SetLastError = true)]
      public static extern uint WaitForSingleObject(IntPtr hHandle, uint dwMilliseconds);

      //http://msdn.microsoft.com/en-us/library/ms683190(v=vs.85).aspx
      [DllImport("kernel32.dll")]
      public static extern bool GetExitCodeThread(IntPtr hThread, out uint lpExitCode);

      [StructLayout(LayoutKind.Sequential)]
      public struct LUID
      {
         public uint LowPart;
         public int HighPart;
      }

      [StructLayout(LayoutKind.Sequential)]
      public struct TOKEN_PRIVILEGES
      {
         public UInt32 PrivilegeCount;
         public LUID Luid;
         public UInt32 Attributes;
      }

      //http://msdn.microsoft.com/en-us/library/aa379295(v=vs.85).aspx
      [DllImport("advapi32.dll", ExactSpelling = true)]
      public static extern bool OpenProcessToken(
          IntPtr ProcessHandle,
          TokenAccessLevels DesiredAccess,
          ref IntPtr TokenHandle);

      //http://msdn.microsoft.com/en-us/library/aa379180(v=vs.85).aspx
      [DllImport("advapi32.dll", SetLastError = true)]
      public static extern bool LookupPrivilegeValue(
          string lpSystemName,
          string lpName,
          ref LUID lpLuid);

      //http://msdn.microsoft.com/en-us/library/aa375202(v=vs.85).aspx
      [DllImport("Advapi32.dll", SetLastError = true)]
      public static extern bool AdjustTokenPrivileges(
          IntPtr TokenHandle,
          bool DisableAllPrivileges,
          ref TOKEN_PRIVILEGES NewState,
          uint BufferLength,
          ref TOKEN_PRIVILEGES PreviousState,
          out uint ReturnLength);

      #endregion

      #region Read Memory functions
      /// <summary>
      /// generic read mem function for objects
      /// </summary>
      /// <typeparam name="T">any type</typeparam>
      /// <param name="MemoryAddress">memory address to read</param>
      /// <returns>returns the type used</returns>
      public T ReadMem<T>(IntPtr MemoryAddress)
      {
         int type_size = Marshal.SizeOf(typeof(T));
         byte[] buffer = new byte[type_size], num = { 0 };
         T obj = default(T);

         if (!P.HasExited)
         {
            int BytesRead;
            if (!ReadProcessMemory(P.Handle, MemoryAddress, buffer, (uint)type_size, out BytesRead))
               LastWin32Error = Marshal.GetLastWin32Error();

            if (BytesRead == type_size)
            {
               IntPtr buffer2 = Marshal.AllocHGlobal(type_size);
               Marshal.Copy(buffer, 0, buffer2, type_size);
               obj = (T)Marshal.PtrToStructure(buffer2, typeof(T));
               Marshal.FreeHGlobal(buffer2);
            }
         }

         return obj;
      }

      public byte ReadMemByte(IntPtr MemoryAddress)
      {
         byte[] buffer = new byte[sizeof(byte)]; byte num = 0;

         if (!P.HasExited)
         {
            int BytesRead;
            if (!ReadProcessMemory(P.Handle, MemoryAddress, buffer, sizeof(byte), out BytesRead))
               LastWin32Error = Marshal.GetLastWin32Error();

            if (BytesRead == sizeof(byte))
               num = buffer[0];
         }

         return num;
      }

      public short ReadMemShort(IntPtr MemoryAddress)
      {
         byte[] buffer = new byte[sizeof(short)]; short num = 0;

         if (!P.HasExited)
         {
            int BytesRead;
            if (!ReadProcessMemory(P.Handle, MemoryAddress, buffer, sizeof(short), out BytesRead))
               LastWin32Error = Marshal.GetLastWin32Error();

            if (BytesRead == sizeof(short))
               num = BitConverter.ToInt16(buffer, 0);
         }

         return num;
      }

      public int ReadMemInt(IntPtr MemoryAddress)
      {
         byte[] buffer = new byte[sizeof(int)]; int num = 0;

         if (!P.HasExited)
         {
            int BytesRead;
            if (!ReadProcessMemory(P.Handle, MemoryAddress, buffer, sizeof(int), out BytesRead))
               LastWin32Error = Marshal.GetLastWin32Error();

            if (BytesRead == sizeof(int))
               num = BitConverter.ToInt32(buffer, 0);
         }

         return num;
      }

      public bool ReadMemBool(IntPtr MemoryAddress)
      {
         byte[] buffer = new byte[sizeof(bool)]; bool num = false;

         if (!P.HasExited)
         {
            int BytesRead;
            if (!ReadProcessMemory(P.Handle, MemoryAddress, buffer, sizeof(bool), out BytesRead))
               LastWin32Error = Marshal.GetLastWin32Error();

            if (BytesRead == sizeof(bool))
               num = BitConverter.ToBoolean(buffer, 0);
         }

         return num;
      }

      public float ReadMemFloat(IntPtr MemoryAddress)
      {
         byte[] buffer = new byte[sizeof(float)]; float num = 0;

         if (!P.HasExited)
         {
            int BytesRead;
            if (!ReadProcessMemory(P.Handle, MemoryAddress, buffer, sizeof(float), out BytesRead))
               LastWin32Error = Marshal.GetLastWin32Error();

            if (BytesRead == sizeof(float))
               num = BitConverter.ToSingle(buffer, 0);
         }

         return num;
      }

      public bool ReadMemBytes(IntPtr MemoryAddress, ref byte[] buffer)
      {
         bool succeded = false;

         if (!P.HasExited)
         {
            int BytesRead;
            if (!ReadProcessMemory(P.Handle, MemoryAddress, buffer, (uint)buffer.Length, out BytesRead))
               LastWin32Error = Marshal.GetLastWin32Error();

            if (BytesRead == buffer.Length)
               succeded = true;
         }

         return succeded;
      }

      public string ReadMemString(IntPtr MemoryAddress, uint string_size, Encoding encoding)
      {
         string str = "\0";
         byte[] buffer = new byte[encoding.GetByteCount(str) * string_size];

         if (!P.HasExited)
         {
            int BytesRead;
            if (!ReadProcessMemory(P.Handle, MemoryAddress, buffer, Convert.ToUInt16(encoding.GetByteCount(str) * string_size), out BytesRead))
               LastWin32Error = Marshal.GetLastWin32Error();

            if (BytesRead == (encoding.GetByteCount(str) * string_size))
               str = encoding.GetString(buffer);
         }

         return str;
      }
      //Read memory until the null terminator
      public string ReadMemString(IntPtr MemoryAddress, Encoding encoding)
      {
         string str; uint size = 0;

         do
            str = ReadMemString(MemoryAddress, ++size, encoding);
         while (str[Convert.ToInt32(size - 1)] != '\0');
         //get rid of extra '\0'
         return str.Remove(Convert.ToInt32(size - 1));
      }
      #endregion

      #region Write to memory functions
      /// <summary>
      /// Generic write memory function for objects
      /// </summary>
      /// <typeparam name="T">any type</typeparam>
      /// <param name="MemoryAddress">were in memory to write</param>
      /// <param name="obj">what to write</param>
      /// <returns>true if succeeded</returns>
      public bool WriteMem<T>(IntPtr MemoryAddress, T obj)
      {
         bool succeeded = false;
         int rawSize = Marshal.SizeOf(obj);
         byte[] buffer = new byte[rawSize];
         //convert to byte array
         IntPtr buffer2 = Marshal.AllocHGlobal(rawSize);
         Marshal.StructureToPtr(obj, buffer2, false);
         Marshal.Copy(buffer2, buffer, 0, rawSize);
         Marshal.FreeHGlobal(buffer2);

         if (!P.HasExited)
         {
            int bytesWritten;
            if (!WriteProcessMemory(P.Handle, MemoryAddress, buffer, (uint)rawSize, out bytesWritten))
               LastWin32Error = Marshal.GetLastWin32Error();

            if (bytesWritten == buffer.Length)
               succeeded = true;
         }
         return succeeded;
      }

      public bool WriteMemByte(IntPtr MemoryAddress, byte num)
      {
         bool succeeded = false;
         if (!P.HasExited)
         {
            int bytesWritten;
            if (!WriteProcessMemory(P.Handle, MemoryAddress, new byte[] { num }, sizeof(byte), out bytesWritten))
               LastWin32Error = Marshal.GetLastWin32Error();

            if (bytesWritten == sizeof(byte))
               succeeded = true;
         }
         return succeeded;
      }

      public bool WriteMemShort(IntPtr MemoryAddress, short num)
      {
         bool succeeded = false;
         if (!P.HasExited)
         {
            int bytesWritten;
            if (!WriteProcessMemory(P.Handle, MemoryAddress, BitConverter.GetBytes(num), sizeof(short), out bytesWritten))
               LastWin32Error = Marshal.GetLastWin32Error();

            if (bytesWritten == sizeof(short))
               succeeded = true;
         }
         return succeeded;
      }

      public bool WriteMemInt(IntPtr MemoryAddress, int num)
      {
         bool succeeded = false;
         if (!P.HasExited)
         {
            int bytesWritten;
            if (!WriteProcessMemory(P.Handle, MemoryAddress, BitConverter.GetBytes(num), sizeof(int), out bytesWritten))
               LastWin32Error = Marshal.GetLastWin32Error();

            if (bytesWritten == sizeof(int))
               succeeded = true;
         }
         return succeeded;
      }

      public bool WriteMemFloat(IntPtr MemoryAddress, float num)
      {
         bool succeeded = false;
         if (!P.HasExited)
         {
            int bytesWritten;
            if (!WriteProcessMemory(P.Handle, MemoryAddress, BitConverter.GetBytes(num), sizeof(float), out bytesWritten))
               LastWin32Error = Marshal.GetLastWin32Error();

            if (bytesWritten == sizeof(float))
               succeeded = true;
         }
         return succeeded;
      }

      public bool WriteMemBool(IntPtr MemoryAddress, bool bool_to_num)
      {
         bool succeeded = false;
         if (!P.HasExited)
         {
            int bytesWritten;
            if (!WriteProcessMemory(P.Handle, MemoryAddress, BitConverter.GetBytes(bool_to_num), sizeof(bool), out bytesWritten))
               LastWin32Error = Marshal.GetLastWin32Error();

            if (bytesWritten == sizeof(bool))
               succeeded = true;
         }
         return succeeded;
      }

      public bool WriteMemBytes(IntPtr MemoryAddress, ref byte[] bytes)
      {
         bool succeeded = false;
         if (!P.HasExited)
         {
            int bytesWritten;
            if (!WriteProcessMemory(P.Handle, MemoryAddress, bytes, (uint)bytes.Length, out bytesWritten))
               LastWin32Error = Marshal.GetLastWin32Error();

            if (bytesWritten == bytes.Length)
               succeeded = true;
         }
         return succeeded;
      }

      public bool WriteMemJMP(int JMPLocMemAddress, int JMPToMemAddress, uint size)
      {
         bool succeeded = false; byte[] bytes = new byte[size];
         bytes[0] = 0xE9;//JMP
         byte[] JMP_to_code = BitConverter.GetBytes(JMPToMemAddress - (JMPLocMemAddress + 5));
         bytes[1] = JMP_to_code[0];
         bytes[2] = JMP_to_code[1];
         bytes[3] = JMP_to_code[2];
         bytes[4] = JMP_to_code[3];

         for (int i = 5; i < size; i++)
            bytes[i] = 0x90;//NOP

         if (!P.HasExited)
         {
            int bytesWritten;
            if (!WriteProcessMemory(P.Handle, (IntPtr)JMPLocMemAddress, bytes, size, out bytesWritten))
               LastWin32Error = Marshal.GetLastWin32Error();

            if (bytesWritten == size)
               succeeded = true;
         }
         return succeeded;
      }

      public bool WriteMemString(IntPtr MemoryAddress, string str, Encoding encoding)
      {
         bool succeeded = false;
         if (!P.HasExited)
         {
            int bytesWritten;
            if (!WriteProcessMemory(P.Handle, MemoryAddress, encoding.GetBytes(str), (uint)encoding.GetByteCount(str), out bytesWritten))
               LastWin32Error = Marshal.GetLastWin32Error();

            if (bytesWritten == encoding.GetByteCount(str))
               succeeded = true;
         }
         return succeeded;
      }
      #endregion

      public MODULEENTRY32[] GetProcessModules()
      {
         MODULEENTRY32[] proc_mods = new MODULEENTRY32[1];
         IntPtr hSnapShot = CreateToolhelp32Snapshot(SnapshotFlags.All, P.Id);

         if (hSnapShot == null)
            LastWin32Error = Marshal.GetLastWin32Error();
         else
         {
            MODULEENTRY32 me32 = new MODULEENTRY32();
            me32.dwSize = (uint)Marshal.SizeOf(me32);

            if (!Module32First(hSnapShot, ref me32))
               LastWin32Error = Marshal.GetLastWin32Error();
            else
            {
               proc_mods[0] = me32;

               for (int i = 1; Module32Next(hSnapShot, ref me32); i++)
               {
                  Array.Resize<MODULEENTRY32>(ref proc_mods, i + 1);
                  proc_mods[i] = me32;
               }
            }
         }

         CloseHandle(hSnapShot);
         return proc_mods;
      }

      //get module info within the process
      public MODULEENTRY32[] GetProcessModulesByName(string module_name)
      {
         MODULEENTRY32[] me32_list = GetProcessModules();
         System.Collections.Generic.List<MODULEENTRY32> process_modules = new System.Collections.Generic.List<MODULEENTRY32>();

         for (uint i = 0; i < me32_list.Length; i++)
         {
            if (module_name == me32_list[i].szModule)
               process_modules.Add(me32_list[i]);
         }

         return process_modules.ToArray();
      }

      public IntPtr AllocateMemory(uint size)
      {
         IntPtr address_of_alloc = VirtualAllocEx(P.Handle, (IntPtr)0, size,
                     AllocationType.Commit | AllocationType.Reserve, MemoryProtection.ExecuteReadWrite);

         if (address_of_alloc == null)
            LastWin32Error = Marshal.GetLastWin32Error();

         return address_of_alloc;
      }

      public bool FreeMemory(IntPtr address, uint size)
      {
         bool succeded = false;
         if (!VirtualFreeEx(P.Handle, address, size, AllocationType.Release))
            LastWin32Error = Marshal.GetLastWin32Error();
         else
            succeded = true;

         return succeded;
      }

      public uint CallRemoteFunction(IntPtr lpStartAddress, IntPtr lpParameter)
      {
         uint return_val;
         uint creationflag;

         IntPtr NewThreadhnd = CreateRemoteThread(P.Handle, IntPtr.Zero, 0, lpStartAddress, lpParameter, 0, out creationflag);

         WaitForSingleObject(NewThreadhnd, INFINITE);
         GetExitCodeThread(NewThreadhnd, out return_val);

         return return_val;
      }

      /// <summary>
      /// set project properties->build->platform to x86 for injecting into 32 bit apps
      /// otherwise set to x64 for injecting into 32 bit apps
      /// </summary>
      /// <param name="DLLPath">Path to the dll</param>
      /// <returns>a handle to the module</returns>
      public IntPtr InjectDLL(string DLLPath)
      {
         IntPtr hLibModule = IntPtr.Zero;

         if (!P.HasExited)
         {
            IntPtr pLibRemote;
            IntPtr hKernel32 = GetModuleHandle("kernel32.dll");
            IntPtr LoadLibrary_address = GetProcAddress(hKernel32, "LoadLibraryW");

            pLibRemote = AllocateMemory((uint)(sizeof(char) * DLLPath.Length));
            WriteMemString(pLibRemote, DLLPath, new UnicodeEncoding());

            uint creationflag;
            IntPtr NewThreadhnd = CreateRemoteThread(P.Handle, IntPtr.Zero, 0, LoadLibrary_address, pLibRemote, 0, out creationflag);
            WaitForSingleObject(NewThreadhnd, INFINITE);

            MODULEENTRY32[] me32_list = GetProcessModules();
            for (uint me32_i = 0; me32_i < me32_list.Length; me32_i++)
               if (DLLPath == me32_list[me32_i].szExePath)
                  hLibModule = me32_list[me32_i].hModule;

            FreeMemory(pLibRemote, (uint)(sizeof(char) * DLLPath.Length));
         }

         return hLibModule;
      }

      public bool UnloadDLL(IntPtr hLibModule)
      {
         bool succeded = false;
         IntPtr hKernel32 = GetModuleHandle("Kernel32");
         IntPtr FreeLibrary_address = GetProcAddress(hKernel32, "FreeLibrary");

         //Unload DLL from remote process
         if (CallRemoteFunction(FreeLibrary_address, hLibModule) != 0)
            succeded = true;

         return succeded;
      }

      public bool Enable_SeDebugPrivilege()
      {
         IntPtr hToken = (IntPtr)0;
         LUID luidSEDebugNameValue = new LUID();
         TOKEN_PRIVILEGES tkpPrivileges, prev_state = new TOKEN_PRIVILEGES();
         const string SE_DEBUG_NAME = "SeDebugPrivilege";
         const UInt32 SE_PRIVILEGE_ENABLED = 0x00000002;
         uint rlength;

         if (!OpenProcessToken(P.Handle, TokenAccessLevels.AdjustDefault | TokenAccessLevels.Query, ref hToken))
         {
            LastWin32Error = Marshal.GetLastWin32Error();
         }

         if (!LookupPrivilegeValue(null, SE_DEBUG_NAME, ref luidSEDebugNameValue))
         {
            LastWin32Error = Marshal.GetLastWin32Error();
         }

         tkpPrivileges.PrivilegeCount = 1;
         tkpPrivileges.Luid = luidSEDebugNameValue;
         tkpPrivileges.Attributes = SE_PRIVILEGE_ENABLED;

         if (!AdjustTokenPrivileges(hToken, false, ref tkpPrivileges, 0, ref prev_state, out rlength))
         {
            LastWin32Error = Marshal.GetLastWin32Error();
         }

         return true;//temp
      }

      public void ModuleBaseCodeSize(string module_name, ref IntPtr BaseCode_Address, ref UInt32 Code_Size)
      {
         MODULEENTRY32[] me32_list = GetProcessModulesByName(module_name);
         if (me32_list.Length > 0)
         {
            //Offset to PE sig
            Int32 PE_sig = ReadMemInt((IntPtr)((UInt32)me32_list[0].modBaseAddr + 0x3C));

            //BaseOfCode in PE header
            BaseCode_Address = (IntPtr)((UInt32)me32_list[0].modBaseAddr + ReadMemInt(
            (IntPtr)((UInt32)me32_list[0].modBaseAddr + PE_sig +
               //offset to BaseOfCode
            0x2C)));

            //SizeOfCode in PE Header
            Code_Size = (UInt32)ReadMemInt((IntPtr)((UInt32)me32_list[0].modBaseAddr + PE_sig +
               //offset to SizeOfCode
            0x1C));
         }
      }

      public uint FindMemPattern(uint MemoryAddress, uint size, byte[] Pattern, string Mask)
      {
         uint PatterAddress = 0;
         byte[] buffer = new byte[size];
         ReadMemBytes((IntPtr)MemoryAddress, ref buffer);

         for (uint i = 0; i < size && PatterAddress == 0; i++)
         {
            //while Mask[i2] isnt the null terminator
            for (int i2 = 0; i2 < Mask.Length; i2++)
            {
               //make sure its not at the end of the mask before continuing
               if (Mask[i2] == '?' && i2 + 1 < Mask.Length)
                  continue;
               //if the bytes don't match exit loop
               if (Mask[i2] == 'x' && buffer[i + i2] != Pattern[i2])
                  break;
               //when it reaches the end, it must be the address we're looking for
               if (i2 + 1 == Mask.Length)
                  PatterAddress = MemoryAddress + i;
            }
         }

         return PatterAddress;
      }

      public uint FindMemPattern(uint addr, uint size, string strPattern, string strMask)
      {
         byte[] btPattern = Encoding.Unicode.GetBytes(strPattern);
         //btPattern = Encoding.Convert(new UnicodeEncoding(), new UTF8Encoding(), btPattern);

         for (int i = 0, d = 0; i < btPattern.Length; i++)
            if (i % 2 == 0)
               btPattern[d++] = btPattern[i];
         Array.Resize<byte>(ref btPattern, btPattern.Length / 2);
         return FindMemPattern(addr, size, btPattern, strMask);
      }

      public uint FindMemPattern(uint addr, uint size, ADDRESS_SIG addr_sig)
      {
         return FindMemPattern(addr, size, addr_sig.pattern, addr_sig.mask) + addr_sig.offset;
      }
   }
}