﻿namespace RPG_Beta6_2Controls
{
    partial class win_About
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
           System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(win_About));
           this.labelCompanyName = new System.Windows.Forms.Label();
           this.labelVersion = new System.Windows.Forms.Label();
           this.labelProductName = new System.Windows.Forms.Label();
           this.okButton = new System.Windows.Forms.Button();
           this.label1 = new System.Windows.Forms.Label();
           this.label2 = new System.Windows.Forms.Label();
           this.SuspendLayout();
           // 
           // labelCompanyName
           // 
           this.labelCompanyName.BackColor = System.Drawing.Color.Transparent;
           this.labelCompanyName.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
           this.labelCompanyName.ForeColor = System.Drawing.Color.Lime;
           this.labelCompanyName.Location = new System.Drawing.Point(198, 125);
           this.labelCompanyName.Margin = new System.Windows.Forms.Padding(6, 0, 3, 0);
           this.labelCompanyName.MaximumSize = new System.Drawing.Size(200, 75);
           this.labelCompanyName.MinimumSize = new System.Drawing.Size(117, 17);
           this.labelCompanyName.Name = "labelCompanyName";
           this.labelCompanyName.Size = new System.Drawing.Size(117, 75);
           this.labelCompanyName.TabIndex = 22;
           this.labelCompanyName.Text = "Created By:\r\nJesus7Freak";
           this.labelCompanyName.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
           // 
           // labelVersion
           // 
           this.labelVersion.Anchor = System.Windows.Forms.AnchorStyles.Top;
           this.labelVersion.BackColor = System.Drawing.Color.Transparent;
           this.labelVersion.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
           this.labelVersion.ForeColor = System.Drawing.Color.White;
           this.labelVersion.Location = new System.Drawing.Point(198, 37);
           this.labelVersion.Margin = new System.Windows.Forms.Padding(6, 0, 3, 0);
           this.labelVersion.MaximumSize = new System.Drawing.Size(117, 17);
           this.labelVersion.MinimumSize = new System.Drawing.Size(117, 17);
           this.labelVersion.Name = "labelVersion";
           this.labelVersion.Size = new System.Drawing.Size(117, 17);
           this.labelVersion.TabIndex = 0;
           this.labelVersion.Text = "Version: 0.89";
           this.labelVersion.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
           // 
           // labelProductName
           // 
           this.labelProductName.Anchor = System.Windows.Forms.AnchorStyles.Top;
           this.labelProductName.BackColor = System.Drawing.Color.Transparent;
           this.labelProductName.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
           this.labelProductName.ForeColor = System.Drawing.Color.White;
           this.labelProductName.Location = new System.Drawing.Point(161, 8);
           this.labelProductName.Margin = new System.Windows.Forms.Padding(6, 0, 3, 0);
           this.labelProductName.MaximumSize = new System.Drawing.Size(200, 17);
           this.labelProductName.MinimumSize = new System.Drawing.Size(117, 17);
           this.labelProductName.Name = "labelProductName";
           this.labelProductName.Size = new System.Drawing.Size(182, 17);
           this.labelProductName.TabIndex = 19;
           this.labelProductName.Text = "RPG_Beta6_2 Controls";
           this.labelProductName.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
           // 
           // okButton
           // 
           this.okButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
           this.okButton.BackColor = System.Drawing.Color.Transparent;
           this.okButton.DialogResult = System.Windows.Forms.DialogResult.Cancel;
           this.okButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
           this.okButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
           this.okButton.Location = new System.Drawing.Point(216, 304);
           this.okButton.Name = "okButton";
           this.okButton.Size = new System.Drawing.Size(72, 34);
           this.okButton.TabIndex = 24;
           this.okButton.Text = "&OK";
           this.okButton.UseVisualStyleBackColor = false;
           this.okButton.MouseHover += new System.EventHandler(this.okButton_MouseHover);
           // 
           // label1
           // 
           this.label1.BackColor = System.Drawing.Color.Transparent;
           this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
           this.label1.ForeColor = System.Drawing.Color.White;
           this.label1.Location = new System.Drawing.Point(15, 100);
           this.label1.Margin = new System.Windows.Forms.Padding(6, 0, 3, 0);
           this.label1.MaximumSize = new System.Drawing.Size(150, 150);
           this.label1.MinimumSize = new System.Drawing.Size(117, 17);
           this.label1.Name = "label1";
           this.label1.Size = new System.Drawing.Size(150, 147);
           this.label1.TabIndex = 25;
           this.label1.Text = "Beta Testers:\r\nShadow\r\nAoO Aurora\r\n۞ŘρĂŞ۞Jedi\r\nÇAG»Dark_Špyrø\r\nMarko Ramius\r\n{CB]" +
               "Becca";
           this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
           // 
           // label2
           // 
           this.label2.BackColor = System.Drawing.Color.Transparent;
           this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
           this.label2.ForeColor = System.Drawing.Color.White;
           this.label2.Location = new System.Drawing.Point(351, 62);
           this.label2.Margin = new System.Windows.Forms.Padding(6, 0, 3, 0);
           this.label2.MaximumSize = new System.Drawing.Size(150, 280);
           this.label2.MinimumSize = new System.Drawing.Size(117, 17);
           this.label2.Name = "label2";
           this.label2.Size = new System.Drawing.Size(137, 215);
           this.label2.TabIndex = 26;
           this.label2.Text = "Thanks to:\r\nJesus for\r\nsalvation, \r\nBelieve in\r\nHim and have \r\neternal Life!,\r\nBu" +
               "ngie for \r\nHalo CE,\r\nand OpsY\r\nfor rpg_beta6_2";
           this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
           // 
           // win_About
           // 
           this.AcceptButton = this.okButton;
           this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
           this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
           this.BackColor = System.Drawing.Color.White;
           this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
           this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
           this.ClientSize = new System.Drawing.Size(500, 350);
           this.Controls.Add(this.label2);
           this.Controls.Add(this.label1);
           this.Controls.Add(this.labelProductName);
           this.Controls.Add(this.labelVersion);
           this.Controls.Add(this.okButton);
           this.Controls.Add(this.labelCompanyName);
           this.DoubleBuffered = true;
           this.ForeColor = System.Drawing.Color.Black;
           this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
           this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
           this.MaximizeBox = false;
           this.MinimizeBox = false;
           this.Name = "win_About";
           this.Padding = new System.Windows.Forms.Padding(9);
           this.ShowIcon = false;
           this.ShowInTaskbar = false;
           this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
           this.Text = "About RPG_Beta6_2 Controls";
           this.TransparencyKey = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
           this.Load += new System.EventHandler(this.okButton_MouseHover);
           this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label labelCompanyName;
        private System.Windows.Forms.Label labelVersion;
        private System.Windows.Forms.Label labelProductName;
        private System.Windows.Forms.Button okButton;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;


    }
}
