﻿namespace RPG_Beta6_2Controls
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
           this.components = new System.ComponentModel.Container();
           System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
           this.dev_btn = new System.Windows.Forms.Button();
           this.BLD_set_t = new System.Windows.Forms.Button();
           this.BLD_lbl = new System.Windows.Forms.Label();
           this.BLD_activate = new System.Windows.Forms.Button();
           this.ToD_cb = new System.Windows.Forms.ComboBox();
           this.alarm_btn = new System.Windows.Forms.Button();
           this.halo_activate = new System.Windows.Forms.Button();
           this.halo_lbl = new System.Windows.Forms.Label();
           this.halo_set_t = new System.Windows.Forms.Button();
           this.status_lbl = new System.Windows.Forms.Label();
           this.status_lbl2 = new System.Windows.Forms.Label();
           this.status_lbl3 = new System.Windows.Forms.Label();
           this.status_lbl4 = new System.Windows.Forms.Label();
           this.Deathless_chkBx = new System.Windows.Forms.CheckBox();
           this.IF_chkBx = new System.Windows.Forms.CheckBox();
           this.showhud_chkBx = new System.Windows.Forms.CheckBox();
           this.letterbox_chkBx = new System.Windows.Forms.CheckBox();
           this.rcon_lbl = new System.Windows.Forms.Label();
           this.Menu = new System.Windows.Forms.MenuStrip();
           this.helpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
           this.Help_commands = new System.Windows.Forms.ToolStripMenuItem();
           this.Help_about = new System.Windows.Forms.ToolStripMenuItem();
           this.MV_chkBx = new System.Windows.Forms.CheckBox();
           this.BLD_timer_txt = new System.Windows.Forms.MaskedTextBox();
           this.halo_timer_txt = new System.Windows.Forms.MaskedTextBox();
           this.update_info_timer = new System.Windows.Forms.Timer(this.components);
           this.Menu.SuspendLayout();
           this.SuspendLayout();
           // 
           // dev_btn
           // 
           this.dev_btn.BackColor = System.Drawing.Color.Transparent;
           this.dev_btn.Enabled = false;
           this.dev_btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
           this.dev_btn.ForeColor = System.Drawing.Color.Red;
           this.dev_btn.Location = new System.Drawing.Point(0, 23);
           this.dev_btn.Name = "dev_btn";
           this.dev_btn.Size = new System.Drawing.Size(89, 25);
           this.dev_btn.TabIndex = 0;
           this.dev_btn.Text = "Enable Dev";
           this.dev_btn.UseVisualStyleBackColor = false;
           this.dev_btn.Click += new System.EventHandler(this.dev_btn_Click);
           // 
           // BLD_set_t
           // 
           this.BLD_set_t.BackColor = System.Drawing.Color.Transparent;
           this.BLD_set_t.Enabled = false;
           this.BLD_set_t.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
           this.BLD_set_t.ForeColor = System.Drawing.SystemColors.Highlight;
           this.BLD_set_t.Location = new System.Drawing.Point(151, 67);
           this.BLD_set_t.Name = "BLD_set_t";
           this.BLD_set_t.Size = new System.Drawing.Size(62, 22);
           this.BLD_set_t.TabIndex = 2;
           this.BLD_set_t.Text = "Set Timer";
           this.BLD_set_t.UseVisualStyleBackColor = false;
           this.BLD_set_t.Click += new System.EventHandler(this.BLD_set_t_Click);
           // 
           // BLD_lbl
           // 
           this.BLD_lbl.AutoSize = true;
           this.BLD_lbl.BackColor = System.Drawing.Color.Transparent;
           this.BLD_lbl.Enabled = false;
           this.BLD_lbl.ForeColor = System.Drawing.SystemColors.Menu;
           this.BLD_lbl.Location = new System.Drawing.Point(136, 52);
           this.BLD_lbl.Name = "BLD_lbl";
           this.BLD_lbl.Size = new System.Drawing.Size(89, 13);
           this.BLD_lbl.TabIndex = 5;
           this.BLD_lbl.Text = "Base Lock Down";
           // 
           // BLD_activate
           // 
           this.BLD_activate.BackColor = System.Drawing.Color.Transparent;
           this.BLD_activate.Enabled = false;
           this.BLD_activate.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
           this.BLD_activate.ForeColor = System.Drawing.SystemColors.Highlight;
           this.BLD_activate.Location = new System.Drawing.Point(219, 67);
           this.BLD_activate.Name = "BLD_activate";
           this.BLD_activate.Size = new System.Drawing.Size(75, 22);
           this.BLD_activate.TabIndex = 6;
           this.BLD_activate.Text = "Activate";
           this.BLD_activate.UseVisualStyleBackColor = false;
           this.BLD_activate.Click += new System.EventHandler(this.BLD_activate_Click);
           // 
           // ToD_cb
           // 
           this.ToD_cb.DisplayMember = "Day";
           this.ToD_cb.Enabled = false;
           this.ToD_cb.ForeColor = System.Drawing.SystemColors.WindowText;
           this.ToD_cb.FormattingEnabled = true;
           this.ToD_cb.Items.AddRange(new object[] {
            "Day",
            "Rain",
            "Night"});
           this.ToD_cb.Location = new System.Drawing.Point(155, 23);
           this.ToD_cb.MaxLength = 3;
           this.ToD_cb.Name = "ToD_cb";
           this.ToD_cb.Size = new System.Drawing.Size(54, 21);
           this.ToD_cb.TabIndex = 7;
           this.ToD_cb.Text = "Day";
           this.ToD_cb.SelectedIndexChanged += new System.EventHandler(this.e_cb_SelectedIndexChanged);
           // 
           // alarm_btn
           // 
           this.alarm_btn.BackColor = System.Drawing.Color.Transparent;
           this.alarm_btn.Enabled = false;
           this.alarm_btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
           this.alarm_btn.ForeColor = System.Drawing.SystemColors.Highlight;
           this.alarm_btn.Location = new System.Drawing.Point(219, 23);
           this.alarm_btn.Name = "alarm_btn";
           this.alarm_btn.Size = new System.Drawing.Size(75, 23);
           this.alarm_btn.TabIndex = 9;
           this.alarm_btn.Text = "Alarm On";
           this.alarm_btn.UseVisualStyleBackColor = false;
           this.alarm_btn.Click += new System.EventHandler(this.alarm_btn_Click);
           // 
           // halo_activate
           // 
           this.halo_activate.BackColor = System.Drawing.Color.Transparent;
           this.halo_activate.Enabled = false;
           this.halo_activate.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
           this.halo_activate.ForeColor = System.Drawing.SystemColors.Highlight;
           this.halo_activate.Location = new System.Drawing.Point(219, 105);
           this.halo_activate.Name = "halo_activate";
           this.halo_activate.Size = new System.Drawing.Size(75, 22);
           this.halo_activate.TabIndex = 15;
           this.halo_activate.Text = "Activate";
           this.halo_activate.UseVisualStyleBackColor = false;
           this.halo_activate.Click += new System.EventHandler(this.halo_activate_Click);
           // 
           // halo_lbl
           // 
           this.halo_lbl.AutoSize = true;
           this.halo_lbl.BackColor = System.Drawing.Color.Transparent;
           this.halo_lbl.Enabled = false;
           this.halo_lbl.ForeColor = System.Drawing.SystemColors.Menu;
           this.halo_lbl.Location = new System.Drawing.Point(170, 91);
           this.halo_lbl.Name = "halo_lbl";
           this.halo_lbl.Size = new System.Drawing.Size(29, 13);
           this.halo_lbl.TabIndex = 14;
           this.halo_lbl.Text = "Halo";
           // 
           // halo_set_t
           // 
           this.halo_set_t.BackColor = System.Drawing.Color.Transparent;
           this.halo_set_t.Enabled = false;
           this.halo_set_t.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
           this.halo_set_t.ForeColor = System.Drawing.SystemColors.Highlight;
           this.halo_set_t.Location = new System.Drawing.Point(151, 105);
           this.halo_set_t.Name = "halo_set_t";
           this.halo_set_t.Size = new System.Drawing.Size(62, 22);
           this.halo_set_t.TabIndex = 12;
           this.halo_set_t.Text = "Set Timer";
           this.halo_set_t.UseVisualStyleBackColor = false;
           this.halo_set_t.Click += new System.EventHandler(this.halo_set_t_Click);
           // 
           // status_lbl
           // 
           this.status_lbl.AutoSize = true;
           this.status_lbl.BackColor = System.Drawing.Color.Transparent;
           this.status_lbl.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
           this.status_lbl.ForeColor = System.Drawing.SystemColors.Menu;
           this.status_lbl.Location = new System.Drawing.Point(0, 0);
           this.status_lbl.Name = "status_lbl";
           this.status_lbl.Size = new System.Drawing.Size(57, 16);
           this.status_lbl.TabIndex = 16;
           this.status_lbl.Text = "Halo CE:";
           // 
           // status_lbl2
           // 
           this.status_lbl2.AutoSize = true;
           this.status_lbl2.BackColor = System.Drawing.Color.Transparent;
           this.status_lbl2.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
           this.status_lbl2.ForeColor = System.Drawing.Color.Red;
           this.status_lbl2.Location = new System.Drawing.Point(55, 0);
           this.status_lbl2.Name = "status_lbl2";
           this.status_lbl2.Size = new System.Drawing.Size(25, 16);
           this.status_lbl2.TabIndex = 17;
           this.status_lbl2.Text = "Off";
           // 
           // status_lbl3
           // 
           this.status_lbl3.AutoSize = true;
           this.status_lbl3.BackColor = System.Drawing.Color.Transparent;
           this.status_lbl3.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
           this.status_lbl3.ForeColor = System.Drawing.SystemColors.Menu;
           this.status_lbl3.Location = new System.Drawing.Point(79, 0);
           this.status_lbl3.Name = "status_lbl3";
           this.status_lbl3.Size = new System.Drawing.Size(20, 16);
           this.status_lbl3.TabIndex = 18;
           this.status_lbl3.Text = "   ";
           // 
           // status_lbl4
           // 
           this.status_lbl4.AutoSize = true;
           this.status_lbl4.BackColor = System.Drawing.Color.Transparent;
           this.status_lbl4.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
           this.status_lbl4.ForeColor = System.Drawing.SystemColors.Menu;
           this.status_lbl4.Location = new System.Drawing.Point(119, 0);
           this.status_lbl4.Name = "status_lbl4";
           this.status_lbl4.Size = new System.Drawing.Size(16, 16);
           this.status_lbl4.TabIndex = 19;
           this.status_lbl4.Text = "  ";
           // 
           // Deathless_chkBx
           // 
           this.Deathless_chkBx.AutoSize = true;
           this.Deathless_chkBx.BackColor = System.Drawing.Color.Transparent;
           this.Deathless_chkBx.Enabled = false;
           this.Deathless_chkBx.ForeColor = System.Drawing.SystemColors.Highlight;
           this.Deathless_chkBx.Location = new System.Drawing.Point(3, 54);
           this.Deathless_chkBx.Name = "Deathless_chkBx";
           this.Deathless_chkBx.Size = new System.Drawing.Size(73, 17);
           this.Deathless_chkBx.TabIndex = 20;
           this.Deathless_chkBx.Text = "Deathless";
           this.Deathless_chkBx.UseVisualStyleBackColor = false;
           this.Deathless_chkBx.CheckedChanged += new System.EventHandler(this.Deathless_chkBx_CheckedChanged);
           // 
           // IF_chkBx
           // 
           this.IF_chkBx.AutoSize = true;
           this.IF_chkBx.BackColor = System.Drawing.Color.Transparent;
           this.IF_chkBx.Enabled = false;
           this.IF_chkBx.ForeColor = System.Drawing.SystemColors.Highlight;
           this.IF_chkBx.Location = new System.Drawing.Point(3, 73);
           this.IF_chkBx.Name = "IF_chkBx";
           this.IF_chkBx.Size = new System.Drawing.Size(89, 17);
           this.IF_chkBx.TabIndex = 21;
           this.IF_chkBx.Text = "Infinite Ammo";
           this.IF_chkBx.UseVisualStyleBackColor = false;
           this.IF_chkBx.CheckedChanged += new System.EventHandler(this.IF_chkBx_CheckedChanged);
           // 
           // showhud_chkBx
           // 
           this.showhud_chkBx.AutoSize = true;
           this.showhud_chkBx.BackColor = System.Drawing.Color.Transparent;
           this.showhud_chkBx.Enabled = false;
           this.showhud_chkBx.ForeColor = System.Drawing.SystemColors.Highlight;
           this.showhud_chkBx.Location = new System.Drawing.Point(3, 93);
           this.showhud_chkBx.Name = "showhud_chkBx";
           this.showhud_chkBx.Size = new System.Drawing.Size(80, 17);
           this.showhud_chkBx.TabIndex = 22;
           this.showhud_chkBx.Text = "Show HUD";
           this.showhud_chkBx.UseVisualStyleBackColor = false;
           this.showhud_chkBx.CheckedChanged += new System.EventHandler(this.showhud_chkBx_CheckedChanged);
           // 
           // letterbox_chkBx
           // 
           this.letterbox_chkBx.AutoSize = true;
           this.letterbox_chkBx.BackColor = System.Drawing.Color.Transparent;
           this.letterbox_chkBx.Enabled = false;
           this.letterbox_chkBx.ForeColor = System.Drawing.SystemColors.Highlight;
           this.letterbox_chkBx.Location = new System.Drawing.Point(3, 111);
           this.letterbox_chkBx.Name = "letterbox_chkBx";
           this.letterbox_chkBx.Size = new System.Drawing.Size(74, 17);
           this.letterbox_chkBx.TabIndex = 23;
           this.letterbox_chkBx.Text = "Letter Box";
           this.letterbox_chkBx.UseVisualStyleBackColor = false;
           this.letterbox_chkBx.CheckedChanged += new System.EventHandler(this.letterbox_chkBx_CheckedChanged);
           // 
           // rcon_lbl
           // 
           this.rcon_lbl.AutoSize = true;
           this.rcon_lbl.BackColor = System.Drawing.Color.Transparent;
           this.rcon_lbl.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
           this.rcon_lbl.Cursor = System.Windows.Forms.Cursors.Hand;
           this.rcon_lbl.Enabled = false;
           this.rcon_lbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
           this.rcon_lbl.ForeColor = System.Drawing.Color.Green;
           this.rcon_lbl.Location = new System.Drawing.Point(94, 26);
           this.rcon_lbl.Name = "rcon_lbl";
           this.rcon_lbl.Size = new System.Drawing.Size(51, 17);
           this.rcon_lbl.TabIndex = 25;
           this.rcon_lbl.Text = "Hosting";
           // 
           // Menu
           // 
           this.Menu.AutoSize = false;
           this.Menu.BackColor = System.Drawing.Color.Transparent;
           this.Menu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.helpToolStripMenuItem});
           this.Menu.Location = new System.Drawing.Point(0, 0);
           this.Menu.Name = "Menu";
           this.Menu.RenderMode = System.Windows.Forms.ToolStripRenderMode.System;
           this.Menu.Size = new System.Drawing.Size(297, 20);
           this.Menu.TabIndex = 29;
           this.Menu.Text = "menuStrip1";
           // 
           // helpToolStripMenuItem
           // 
           this.helpToolStripMenuItem.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
           this.helpToolStripMenuItem.AutoSize = false;
           this.helpToolStripMenuItem.BackColor = System.Drawing.Color.Transparent;
           this.helpToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.Help_commands,
            this.Help_about});
           this.helpToolStripMenuItem.ForeColor = System.Drawing.SystemColors.Menu;
           this.helpToolStripMenuItem.Name = "helpToolStripMenuItem";
           this.helpToolStripMenuItem.Padding = new System.Windows.Forms.Padding(0);
           this.helpToolStripMenuItem.Size = new System.Drawing.Size(36, 20);
           this.helpToolStripMenuItem.Text = "Help";
           // 
           // Help_commands
           // 
           this.Help_commands.BackColor = System.Drawing.Color.White;
           this.Help_commands.Name = "Help_commands";
           this.Help_commands.Size = new System.Drawing.Size(225, 22);
           this.Help_commands.Text = "Commands";
           this.Help_commands.Click += new System.EventHandler(this.Help_commands_Click);
           // 
           // Help_about
           // 
           this.Help_about.Name = "Help_about";
           this.Help_about.Size = new System.Drawing.Size(225, 22);
           this.Help_about.Text = "About RPG_Beta6_2 Controls";
           this.Help_about.Click += new System.EventHandler(this.Help_about_Click);
           // 
           // MV_chkBx
           // 
           this.MV_chkBx.AutoSize = true;
           this.MV_chkBx.BackColor = System.Drawing.Color.Transparent;
           this.MV_chkBx.Enabled = false;
           this.MV_chkBx.ForeColor = System.Drawing.SystemColors.Highlight;
           this.MV_chkBx.Location = new System.Drawing.Point(3, 131);
           this.MV_chkBx.Name = "MV_chkBx";
           this.MV_chkBx.Size = new System.Drawing.Size(90, 17);
           this.MV_chkBx.TabIndex = 30;
           this.MV_chkBx.Text = "Marines HUD";
           this.MV_chkBx.UseVisualStyleBackColor = false;
           this.MV_chkBx.CheckedChanged += new System.EventHandler(this.MV_chkBx_CheckedChanged);
           // 
           // BLD_timer_txt
           // 
           this.BLD_timer_txt.Location = new System.Drawing.Point(97, 67);
           this.BLD_timer_txt.Name = "BLD_timer_txt";
           this.BLD_timer_txt.Size = new System.Drawing.Size(48, 20);
           this.BLD_timer_txt.TabIndex = 31;
           this.BLD_timer_txt.Text = "seconds";
           this.BLD_timer_txt.ValidatingType = typeof(int);
           // 
           // halo_timer_txt
           // 
           this.halo_timer_txt.Location = new System.Drawing.Point(97, 105);
           this.halo_timer_txt.Name = "halo_timer_txt";
           this.halo_timer_txt.Size = new System.Drawing.Size(48, 20);
           this.halo_timer_txt.TabIndex = 32;
           this.halo_timer_txt.Text = "seconds";
           this.halo_timer_txt.ValidatingType = typeof(int);
           // 
           // update_info_timer
           // 
           this.update_info_timer.Enabled = true;
           this.update_info_timer.Tick += new System.EventHandler(this.update_info_timer_Tick);
           // 
           // MainForm
           // 
           this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
           this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
           this.BackColor = System.Drawing.Color.White;
           this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
           this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
           this.ClientSize = new System.Drawing.Size(297, 150);
           this.Controls.Add(this.halo_timer_txt);
           this.Controls.Add(this.BLD_timer_txt);
           this.Controls.Add(this.MV_chkBx);
           this.Controls.Add(this.alarm_btn);
           this.Controls.Add(this.letterbox_chkBx);
           this.Controls.Add(this.showhud_chkBx);
           this.Controls.Add(this.IF_chkBx);
           this.Controls.Add(this.Deathless_chkBx);
           this.Controls.Add(this.status_lbl4);
           this.Controls.Add(this.status_lbl3);
           this.Controls.Add(this.status_lbl2);
           this.Controls.Add(this.status_lbl);
           this.Controls.Add(this.halo_activate);
           this.Controls.Add(this.halo_lbl);
           this.Controls.Add(this.halo_set_t);
           this.Controls.Add(this.dev_btn);
           this.Controls.Add(this.ToD_cb);
           this.Controls.Add(this.BLD_activate);
           this.Controls.Add(this.BLD_lbl);
           this.Controls.Add(this.BLD_set_t);
           this.Controls.Add(this.Menu);
           this.Controls.Add(this.rcon_lbl);
           this.DoubleBuffered = true;
           this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
           this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
           this.MaximizeBox = false;
           this.MinimizeBox = false;
           this.Name = "MainForm";
           this.Text = "RPG_Beta6_2 Host Controls - Jesus7Freak";
           this.TransparencyKey = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
           this.Menu.ResumeLayout(false);
           this.Menu.PerformLayout();
           this.ResumeLayout(false);
           this.PerformLayout();

        }

        #endregion

        public System.Windows.Forms.Button dev_btn;
        public System.Windows.Forms.Button BLD_set_t;
        public System.Windows.Forms.Label BLD_lbl;
        public System.Windows.Forms.Button BLD_activate;
        public System.Windows.Forms.ComboBox ToD_cb;
        public System.Windows.Forms.Button alarm_btn;
        public System.Windows.Forms.Button halo_activate;
        public System.Windows.Forms.Label halo_lbl;
        public System.Windows.Forms.Button halo_set_t;
        public System.Windows.Forms.Label status_lbl;
        public System.Windows.Forms.Label status_lbl2;
        public System.Windows.Forms.Label status_lbl3;
        public System.Windows.Forms.Label status_lbl4;
        public System.Windows.Forms.CheckBox Deathless_chkBx;
        public System.Windows.Forms.CheckBox IF_chkBx;
        public System.Windows.Forms.CheckBox showhud_chkBx;
        public System.Windows.Forms.CheckBox letterbox_chkBx;
        public System.Windows.Forms.Label rcon_lbl;
        private new System.Windows.Forms.MenuStrip Menu;
        private System.Windows.Forms.ToolStripMenuItem helpToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem Help_commands;
        private System.Windows.Forms.ToolStripMenuItem Help_about;
        public System.Windows.Forms.CheckBox MV_chkBx;
        public System.Windows.Forms.MaskedTextBox BLD_timer_txt;
        public System.Windows.Forms.MaskedTextBox halo_timer_txt;
        public System.Windows.Forms.Timer update_info_timer;
    }
}

