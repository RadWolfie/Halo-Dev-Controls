﻿namespace RPG_Beta6_2Controls
{
    partial class ChangeKey
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
           System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ChangeKey));
           this.ok_btn = new System.Windows.Forms.Button();
           this.keycode_txtbx = new System.Windows.Forms.TextBox();
           this.label1 = new System.Windows.Forms.Label();
           this.label2 = new System.Windows.Forms.Label();
           this.keycode_lbl = new System.Windows.Forms.Label();
           this.none_btn = new System.Windows.Forms.Button();
           this.keycode_hex_txtbx = new System.Windows.Forms.TextBox();
           this.SuspendLayout();
           // 
           // ok_btn
           // 
           this.ok_btn.Location = new System.Drawing.Point(12, 25);
           this.ok_btn.Name = "ok_btn";
           this.ok_btn.Size = new System.Drawing.Size(54, 23);
           this.ok_btn.TabIndex = 1;
           this.ok_btn.Text = "OK";
           this.ok_btn.UseVisualStyleBackColor = true;
           this.ok_btn.Click += new System.EventHandler(this.ok_btn_Click);
           // 
           // keycode_txtbx
           // 
           this.keycode_txtbx.Location = new System.Drawing.Point(150, 28);
           this.keycode_txtbx.MaxLength = 4;
           this.keycode_txtbx.Name = "keycode_txtbx";
           this.keycode_txtbx.Size = new System.Drawing.Size(32, 20);
           this.keycode_txtbx.TabIndex = 0;
           this.keycode_txtbx.Text = "key";
           this.keycode_txtbx.KeyDown += new System.Windows.Forms.KeyEventHandler(this.keycode_txtbx_KeyDown);
           // 
           // label1
           // 
           this.label1.AutoSize = true;
           this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
           this.label1.Location = new System.Drawing.Point(80, 28);
           this.label1.Name = "label1";
           this.label1.Size = new System.Drawing.Size(64, 16);
           this.label1.TabIndex = 2;
           this.label1.Text = "KeyCode";
           // 
           // label2
           // 
           this.label2.AutoSize = true;
           this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
           this.label2.Location = new System.Drawing.Point(3, 6);
           this.label2.Name = "label2";
           this.label2.Size = new System.Drawing.Size(79, 16);
           this.label2.TabIndex = 3;
           this.label2.Text = "Press a key";
           // 
           // keycode_lbl
           // 
           this.keycode_lbl.AutoSize = true;
           this.keycode_lbl.Location = new System.Drawing.Point(88, 6);
           this.keycode_lbl.Name = "keycode_lbl";
           this.keycode_lbl.Size = new System.Drawing.Size(33, 13);
           this.keycode_lbl.TabIndex = 4;
           this.keycode_lbl.Text = "name";
           // 
           // none_btn
           // 
           this.none_btn.Location = new System.Drawing.Point(196, 3);
           this.none_btn.Name = "none_btn";
           this.none_btn.Size = new System.Drawing.Size(40, 23);
           this.none_btn.TabIndex = 5;
           this.none_btn.Text = "none";
           this.none_btn.UseVisualStyleBackColor = true;
           this.none_btn.Click += new System.EventHandler(this.none_btn_Click);
           // 
           // keycode_hex_txtbx
           // 
           this.keycode_hex_txtbx.Location = new System.Drawing.Point(188, 28);
           this.keycode_hex_txtbx.MaxLength = 4;
           this.keycode_hex_txtbx.Name = "keycode_hex_txtbx";
           this.keycode_hex_txtbx.Size = new System.Drawing.Size(48, 20);
           this.keycode_hex_txtbx.TabIndex = 6;
           this.keycode_hex_txtbx.Text = "0xkey";
           this.keycode_hex_txtbx.KeyDown += new System.Windows.Forms.KeyEventHandler(this.keycode_txtbx_KeyDown);
           // 
           // ChangeKey
           // 
           this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
           this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
           this.ClientSize = new System.Drawing.Size(241, 53);
           this.Controls.Add(this.keycode_hex_txtbx);
           this.Controls.Add(this.none_btn);
           this.Controls.Add(this.keycode_lbl);
           this.Controls.Add(this.label2);
           this.Controls.Add(this.label1);
           this.Controls.Add(this.keycode_txtbx);
           this.Controls.Add(this.ok_btn);
           this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
           this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
           this.MaximizeBox = false;
           this.MinimizeBox = false;
           this.Name = "ChangeKey";
           this.ShowInTaskbar = false;
           this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
           this.Text = "Change Key";
           this.ResumeLayout(false);
           this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        public System.Windows.Forms.Button ok_btn;
        public System.Windows.Forms.TextBox keycode_txtbx;
        public System.Windows.Forms.Label keycode_lbl;
        private System.Windows.Forms.Button none_btn;
        public System.Windows.Forms.TextBox keycode_hex_txtbx;
    }
}