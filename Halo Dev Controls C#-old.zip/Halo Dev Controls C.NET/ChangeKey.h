/********************************************************************************
	 -- Halo Dev Controls
    Copyright � 2011 Jesus7Freak

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*********************************************************************************
	File:    ChangeKey.h
	Project: Halo Dev Controls C.NET
	Author:  Jesus7Freak
	Date:    11/22/2011
	Game:    Halo and Halo Custom Edition
	Version: all
*********************************************************************************/
#pragma once
#include "WindowsInput.h"

using namespace WindowsInput;

namespace RPG_Beta6_2DevControls {

	/// <summary>
	/// Summary for ChangeKey
	///
	/// WARNING: If you change the name of this class, you will need to change the
	///          'Resource File Name' property for the managed resource compiler tool
	///          associated with all .resx files this class depends on.  Otherwise,
	///          the designers will not be able to interact properly with localized
	///          resources associated with this form.
	/// </summary>
	public ref class ChangeKey : public System::Windows::Forms::Form
	{
   public: static short *Orig_Key = nullptr;

	public:
		ChangeKey(short *key);

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~ChangeKey()
		{
			if (components)
			{
				delete components;
			}
		}
   public: System::Windows::Forms::TextBox^  keycode_hex_txtbx;
   protected: 
   private: System::Windows::Forms::Button^  none_btn;
   public: 
   public: System::Windows::Forms::Label^  keycode_lbl;
   private: 
   private: System::Windows::Forms::Label^  label2;
   public: 
   private: System::Windows::Forms::Label^  label1;
   public: System::Windows::Forms::TextBox^  keycode_txtbx;
   private: 
   public: System::Windows::Forms::Button^  ok_btn;

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
      System::ComponentModel::ComponentResourceManager^  resources = (gcnew System::ComponentModel::ComponentResourceManager(ChangeKey::typeid));
      this->keycode_hex_txtbx = (gcnew System::Windows::Forms::TextBox());
      this->none_btn = (gcnew System::Windows::Forms::Button());
      this->keycode_lbl = (gcnew System::Windows::Forms::Label());
      this->label2 = (gcnew System::Windows::Forms::Label());
      this->label1 = (gcnew System::Windows::Forms::Label());
      this->keycode_txtbx = (gcnew System::Windows::Forms::TextBox());
      this->ok_btn = (gcnew System::Windows::Forms::Button());
      this->SuspendLayout();
      // 
      // keycode_hex_txtbx
      // 
      this->keycode_hex_txtbx->Location = System::Drawing::Point(188, 28);
      this->keycode_hex_txtbx->MaxLength = 4;
      this->keycode_hex_txtbx->Name = L"keycode_hex_txtbx";
      this->keycode_hex_txtbx->Size = System::Drawing::Size(48, 20);
      this->keycode_hex_txtbx->TabIndex = 13;
      this->keycode_hex_txtbx->Text = L"0xkey";
      this->keycode_hex_txtbx->KeyDown += gcnew System::Windows::Forms::KeyEventHandler(this, &ChangeKey::keycode_txtbx_KeyDown);
      // 
      // none_btn
      // 
      this->none_btn->Location = System::Drawing::Point(196, 3);
      this->none_btn->Name = L"none_btn";
      this->none_btn->Size = System::Drawing::Size(40, 23);
      this->none_btn->TabIndex = 12;
      this->none_btn->Text = L"none";
      this->none_btn->UseVisualStyleBackColor = true;
      this->none_btn->Click += gcnew System::EventHandler(this, &ChangeKey::none_btn_Click);
      // 
      // keycode_lbl
      // 
      this->keycode_lbl->AutoSize = true;
      this->keycode_lbl->Location = System::Drawing::Point(88, 6);
      this->keycode_lbl->Name = L"keycode_lbl";
      this->keycode_lbl->Size = System::Drawing::Size(33, 13);
      this->keycode_lbl->TabIndex = 11;
      this->keycode_lbl->Text = L"name";
      // 
      // label2
      // 
      this->label2->AutoSize = true;
      this->label2->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 9.2F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
         static_cast<System::Byte>(0)));
      this->label2->Location = System::Drawing::Point(3, 6);
      this->label2->Name = L"label2";
      this->label2->Size = System::Drawing::Size(79, 16);
      this->label2->TabIndex = 10;
      this->label2->Text = L"Press a key";
      // 
      // label1
      // 
      this->label1->AutoSize = true;
      this->label1->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 9.2F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
         static_cast<System::Byte>(0)));
      this->label1->Location = System::Drawing::Point(80, 28);
      this->label1->Name = L"label1";
      this->label1->Size = System::Drawing::Size(64, 16);
      this->label1->TabIndex = 9;
      this->label1->Text = L"KeyCode";
      // 
      // keycode_txtbx
      // 
      this->keycode_txtbx->Location = System::Drawing::Point(150, 28);
      this->keycode_txtbx->MaxLength = 4;
      this->keycode_txtbx->Name = L"keycode_txtbx";
      this->keycode_txtbx->Size = System::Drawing::Size(32, 20);
      this->keycode_txtbx->TabIndex = 7;
      this->keycode_txtbx->Text = L"key";
      this->keycode_txtbx->KeyDown += gcnew System::Windows::Forms::KeyEventHandler(this, &ChangeKey::keycode_txtbx_KeyDown);
      // 
      // ok_btn
      // 
      this->ok_btn->Location = System::Drawing::Point(12, 25);
      this->ok_btn->Name = L"ok_btn";
      this->ok_btn->Size = System::Drawing::Size(54, 23);
      this->ok_btn->TabIndex = 8;
      this->ok_btn->Text = L"OK";
      this->ok_btn->UseVisualStyleBackColor = true;
      this->ok_btn->Click += gcnew System::EventHandler(this, &ChangeKey::ok_btn_Click);
      // 
      // ChangeKey
      // 
      this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
      this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
      this->ClientSize = System::Drawing::Size(241, 53);
      this->Controls->Add(this->keycode_hex_txtbx);
      this->Controls->Add(this->none_btn);
      this->Controls->Add(this->keycode_lbl);
      this->Controls->Add(this->label2);
      this->Controls->Add(this->label1);
      this->Controls->Add(this->keycode_txtbx);
      this->Controls->Add(this->ok_btn);
      this->FormBorderStyle = System::Windows::Forms::FormBorderStyle::FixedToolWindow;
      this->Icon = (cli::safe_cast<System::Drawing::Icon^  >(resources->GetObject(L"$this.Icon")));
      this->MaximizeBox = false;
      this->MinimizeBox = false;
      this->Name = L"ChangeKey";
      this->ShowInTaskbar = false;
      this->StartPosition = System::Windows::Forms::FormStartPosition::CenterParent;
      this->Text = L"Change Key";
      this->ResumeLayout(false);
      this->PerformLayout();

         }
#pragma endregion
   private: void keycode_txtbx_KeyDown(System::Object^  sender, System::Windows::Forms::KeyEventArgs^  e);
   private: void none_btn_Click(System::Object^  sender, System::EventArgs^  e); 
   private: void ok_btn_Click(System::Object^  sender, System::EventArgs^  e);
};
}
