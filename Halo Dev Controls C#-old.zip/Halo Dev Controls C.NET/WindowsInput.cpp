﻿#include "WindowsInput.h"
#define WIN32_LEAN_AND_MEAN// Exclude rarely-used stuff from Windows headers
#include <windows.h>

namespace WindowsInput
{ 
   void MarshalString(System::String^ _str, char* char_array, int size)
   {
      bool end_of_str = false;
      char* temp_c_str = (char*)(System::Runtime::InteropServices::Marshal::StringToHGlobalAnsi(_str)).ToPointer();
      
      //convert char* to char[size]
      for (int i = 0; i < size; i++)
      {
         //prevent array out of bounds
         if (temp_c_str[i] != 0 && !end_of_str)
            char_array[i] = temp_c_str[i];
         else
         {
            end_of_str = true;
            char_array[i] = '\0';
         }
      }
      
      System::Runtime::InteropServices::Marshal::FreeHGlobal(System::IntPtr((void*)temp_c_str));
   }
   
   void MarshalString(System::String^ _str, wchar_t* char_array, int size)
   {
      bool end_of_str = false;
      wchar_t* temp_c_str = (wchar_t*)(System::Runtime::InteropServices::Marshal::StringToHGlobalUni(_str)).ToPointer();
      
      //convert char* to char[size]
      for (int i = 0; i < size; i++)
      {
         //prevent array out of bounds
         if (temp_c_str[i] != 0 && !end_of_str)
            char_array[i] = temp_c_str[i];
         else
         {
            end_of_str = true;
            char_array[i] = '\0';
         }
      }
      
      System::Runtime::InteropServices::Marshal::FreeHGlobal(System::IntPtr((void*)temp_c_str));
   }
   
   bool IsKeyDown(int keyCode)
   {
      short result = ::GetAsyncKeyState(keyCode);
      return (result < 0);
   }
   
   System::String^ Get_Key_Name(short keycode)
   {
      System::String^ name = "Unknown";
      for (int i = 0; i < 119; i++)
      {
         if (key_info_list[i].key_code == keycode)
         {
            name = gcnew System::String(key_info_list[i].key_name);
            break;
         }
      }
      return name;
   }

   short Get_Key_Code(System::String^ keyname)
   {
      short code = 0;
      char* _keyname = "";
      MarshalString(keyname, _keyname, keyname->Length);

      for (int i = 0; i < 119; i++)
      {
         if (key_info_list[i].key_name == _keyname)
         {
            code = key_info_list[i].key_code;
            break;
         }
      }
      
      return code;
   }
}