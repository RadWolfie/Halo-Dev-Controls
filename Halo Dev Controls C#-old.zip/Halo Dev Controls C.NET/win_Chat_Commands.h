/********************************************************************************
	 -- Halo Dev Controls
    Copyright � 2011 Jesus7Freak

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*********************************************************************************
	File:    win_Chat_Commands.h
	Project: Halo Dev Controls C.NET
	Author:  Jesus7Freak
	Date:    11/22/2011
	Game:    Halo and Halo Custom Edition
	Version: all
*********************************************************************************/
#pragma once

#include "cmds.h"

namespace RPG_Beta6_2DevControls 
{
	/// <summary>
	/// Summary for win_Chat_Commands
	///
	/// WARNING: If you change the name of this class, you will need to change the
	///          'Resource File Name' property for the managed resource compiler tool
	///          associated with all .resx files this class depends on.  Otherwise,
	///          the designers will not be able to interact properly with localized
	///          resources associated with this form.
	/// </summary>
	public ref class win_Chat_Commands : public System::Windows::Forms::Form
	{
   public: System::Windows::Forms::TextBox^  activate_txtbx;

   public: System::Windows::Forms::Button^  toggle_onoff_btn;


   public: System::Windows::Forms::Button^  cmd_off_btn;
   public: System::Windows::Forms::Button^  cmd_on_btn;
   private: System::Windows::Forms::Label^  label5;


   private: System::Windows::Forms::Label^  label1;
   public: System::Windows::Forms::ListBox^  commands_lstBx;
   public: System::Windows::Forms::Label^  descript_lbl;
   public: System::Windows::Forms::CheckBox^  Enable_shrtcts_chkBx;
   private: System::Windows::Forms::Button^  okButton;
   public: System::Windows::Forms::Button^  activate_set_btn;


   public: System::Windows::Forms::Label^  lbl_2nd_descript;
   public: 

   public: 
   private: 
      bool *cmd_val_changed, constructing;
      CMDsLib::COMMANDS* Commands;
   
   public: 
		win_Chat_Commands(CMDsLib::COMMANDS *commands, bool *cmd_changed);

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~win_Chat_Commands()
		{
			if (components)
			{
				delete components;
			}
		}
		
	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
      System::ComponentModel::ComponentResourceManager^  resources = (gcnew System::ComponentModel::ComponentResourceManager(win_Chat_Commands::typeid));
      this->Enable_shrtcts_chkBx = (gcnew System::Windows::Forms::CheckBox());
      this->okButton = (gcnew System::Windows::Forms::Button());
      this->activate_txtbx = (gcnew System::Windows::Forms::TextBox());
      this->toggle_onoff_btn = (gcnew System::Windows::Forms::Button());
      this->cmd_off_btn = (gcnew System::Windows::Forms::Button());
      this->cmd_on_btn = (gcnew System::Windows::Forms::Button());
      this->label5 = (gcnew System::Windows::Forms::Label());
      this->label1 = (gcnew System::Windows::Forms::Label());
      this->commands_lstBx = (gcnew System::Windows::Forms::ListBox());
      this->descript_lbl = (gcnew System::Windows::Forms::Label());
      this->activate_set_btn = (gcnew System::Windows::Forms::Button());
      this->lbl_2nd_descript = (gcnew System::Windows::Forms::Label());
      this->SuspendLayout();
      // 
      // Enable_shrtcts_chkBx
      // 
      this->Enable_shrtcts_chkBx->Anchor = static_cast<System::Windows::Forms::AnchorStyles>((System::Windows::Forms::AnchorStyles::Bottom | System::Windows::Forms::AnchorStyles::Right));
      this->Enable_shrtcts_chkBx->AutoSize = true;
      this->Enable_shrtcts_chkBx->Checked = true;
      this->Enable_shrtcts_chkBx->CheckState = System::Windows::Forms::CheckState::Checked;
      this->Enable_shrtcts_chkBx->Location = System::Drawing::Point(326, 138);
      this->Enable_shrtcts_chkBx->Name = L"Enable_shrtcts_chkBx";
      this->Enable_shrtcts_chkBx->Size = System::Drawing::Size(107, 17);
      this->Enable_shrtcts_chkBx->TabIndex = 42;
      this->Enable_shrtcts_chkBx->Text = L"Enable Shortcuts";
      this->Enable_shrtcts_chkBx->UseVisualStyleBackColor = true;
      this->Enable_shrtcts_chkBx->CheckedChanged += gcnew System::EventHandler(this, &win_Chat_Commands::Enable_shrtcts_chkBx_CheckedChanged);
      // 
      // okButton
      // 
      this->okButton->Anchor = static_cast<System::Windows::Forms::AnchorStyles>((System::Windows::Forms::AnchorStyles::Bottom | System::Windows::Forms::AnchorStyles::Right));
      this->okButton->DialogResult = System::Windows::Forms::DialogResult::Cancel;
      this->okButton->Location = System::Drawing::Point(440, 134);
      this->okButton->Name = L"okButton";
      this->okButton->Size = System::Drawing::Size(75, 22);
      this->okButton->TabIndex = 41;
      this->okButton->Text = L"&OK";
      this->okButton->Click += gcnew System::EventHandler(this, &win_Chat_Commands::okButton_Click);
      // 
      // activate_txtbx
      // 
      this->activate_txtbx->Location = System::Drawing::Point(162, 29);
      this->activate_txtbx->MaxLength = 25;
      this->activate_txtbx->Name = L"activate_txtbx";
      this->activate_txtbx->ReadOnly = true;
      this->activate_txtbx->Size = System::Drawing::Size(210, 20);
      this->activate_txtbx->TabIndex = 66;
      this->activate_txtbx->Text = L"< char[50] >";
      // 
      // toggle_onoff_btn
      // 
      this->toggle_onoff_btn->BackColor = System::Drawing::SystemColors::Control;
      this->toggle_onoff_btn->Enabled = false;
      this->toggle_onoff_btn->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
      this->toggle_onoff_btn->Location = System::Drawing::Point(433, 42);
      this->toggle_onoff_btn->Name = L"toggle_onoff_btn";
      this->toggle_onoff_btn->Size = System::Drawing::Size(78, 23);
      this->toggle_onoff_btn->TabIndex = 64;
      this->toggle_onoff_btn->Text = L"none";
      this->toggle_onoff_btn->UseVisualStyleBackColor = false;
      this->toggle_onoff_btn->Click += gcnew System::EventHandler(this, &win_Chat_Commands::toggle_onoff_btn_Click);
      // 
      // cmd_off_btn
      // 
      this->cmd_off_btn->BackColor = System::Drawing::SystemColors::Control;
      this->cmd_off_btn->Enabled = false;
      this->cmd_off_btn->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
      this->cmd_off_btn->Location = System::Drawing::Point(433, 98);
      this->cmd_off_btn->Name = L"cmd_off_btn";
      this->cmd_off_btn->Size = System::Drawing::Size(78, 23);
      this->cmd_off_btn->TabIndex = 61;
      this->cmd_off_btn->Text = L"none";
      this->cmd_off_btn->UseVisualStyleBackColor = false;
      this->cmd_off_btn->Click += gcnew System::EventHandler(this, &win_Chat_Commands::cmd_off_btn_Click);
      // 
      // cmd_on_btn
      // 
      this->cmd_on_btn->BackColor = System::Drawing::SystemColors::Control;
      this->cmd_on_btn->Enabled = false;
      this->cmd_on_btn->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
      this->cmd_on_btn->Location = System::Drawing::Point(433, 69);
      this->cmd_on_btn->Name = L"cmd_on_btn";
      this->cmd_on_btn->Size = System::Drawing::Size(78, 23);
      this->cmd_on_btn->TabIndex = 60;
      this->cmd_on_btn->Text = L"none";
      this->cmd_on_btn->UseVisualStyleBackColor = false;
      this->cmd_on_btn->Click += gcnew System::EventHandler(this, &win_Chat_Commands::cmd_on_btn_Click);
      // 
      // label5
      // 
      this->label5->AutoSize = true;
      this->label5->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 9, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
         static_cast<System::Byte>(0)));
      this->label5->Location = System::Drawing::Point(408, 26);
      this->label5->Name = L"label5";
      this->label5->Size = System::Drawing::Size(113, 90);
      this->label5->TabIndex = 59;
      this->label5->Text = L"      Toggle | Activate\r\n\r\n\r\nOn\r\n\r\nOff";
      // 
      // label1
      // 
      this->label1->AutoSize = true;
      this->label1->BackColor = System::Drawing::Color::Transparent;
      this->label1->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 10, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
         static_cast<System::Byte>(0)));
      this->label1->ForeColor = System::Drawing::Color::Black;
      this->label1->Location = System::Drawing::Point(196, 5);
      this->label1->Name = L"label1";
      this->label1->Size = System::Drawing::Size(251, 17);
      this->label1->TabIndex = 56;
      this->label1->Text = L"Chat Commands  |  keyboard shortcuts";
      // 
      // commands_lstBx
      // 
      this->commands_lstBx->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 9, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
         static_cast<System::Byte>(0)));
      this->commands_lstBx->FormattingEnabled = true;
      this->commands_lstBx->ItemHeight = 15;
      this->commands_lstBx->Items->AddRange(gcnew cli::array< System::Object^  >(1) {L"< char[20] >"});
      this->commands_lstBx->Location = System::Drawing::Point(3, 5);
      this->commands_lstBx->Name = L"commands_lstBx";
      this->commands_lstBx->Size = System::Drawing::Size(153, 154);
      this->commands_lstBx->TabIndex = 67;
      this->commands_lstBx->SelectedIndexChanged += gcnew System::EventHandler(this, &win_Chat_Commands::commands_lstBx_SelectedIndexChanged);
      // 
      // descript_lbl
      // 
      this->descript_lbl->AutoSize = true;
      this->descript_lbl->Location = System::Drawing::Point(159, 61);
      this->descript_lbl->Name = L"descript_lbl";
      this->descript_lbl->Size = System::Drawing::Size(226, 13);
      this->descript_lbl->TabIndex = 70;
      this->descript_lbl->Text = L"<                      description    char[60]             >";
      // 
      // activate_set_btn
      // 
      this->activate_set_btn->Enabled = false;
      this->activate_set_btn->Location = System::Drawing::Point(378, 27);
      this->activate_set_btn->Name = L"activate_set_btn";
      this->activate_set_btn->Size = System::Drawing::Size(31, 23);
      this->activate_set_btn->TabIndex = 71;
      this->activate_set_btn->Text = L"set";
      this->activate_set_btn->UseVisualStyleBackColor = true;
      this->activate_set_btn->Click += gcnew System::EventHandler(this, &win_Chat_Commands::activate_set_btn_Click);
      // 
      // lbl_2nd_descript
      // 
      this->lbl_2nd_descript->AutoSize = true;
      this->lbl_2nd_descript->Location = System::Drawing::Point(159, 134);
      this->lbl_2nd_descript->Name = L"lbl_2nd_descript";
      this->lbl_2nd_descript->Size = System::Drawing::Size(118, 13);
      this->lbl_2nd_descript->TabIndex = 74;
      this->lbl_2nd_descript->Text = L"<     2nd description    >";
      // 
      // win_Chat_Commands
      // 
      this->AcceptButton = this->okButton;
      this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
      this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
      this->BackColor = System::Drawing::Color::White;
      this->BackgroundImageLayout = System::Windows::Forms::ImageLayout::Center;
      this->ClientSize = System::Drawing::Size(524, 163);
      this->Controls->Add(this->lbl_2nd_descript);
      this->Controls->Add(this->activate_set_btn);
      this->Controls->Add(this->descript_lbl);
      this->Controls->Add(this->commands_lstBx);
      this->Controls->Add(this->activate_txtbx);
      this->Controls->Add(this->toggle_onoff_btn);
      this->Controls->Add(this->cmd_off_btn);
      this->Controls->Add(this->cmd_on_btn);
      this->Controls->Add(this->label5);
      this->Controls->Add(this->label1);
      this->Controls->Add(this->Enable_shrtcts_chkBx);
      this->Controls->Add(this->okButton);
      this->FormBorderStyle = System::Windows::Forms::FormBorderStyle::FixedToolWindow;
      this->Icon = (cli::safe_cast<System::Drawing::Icon^  >(resources->GetObject(L"$this.Icon")));
      this->MaximizeBox = false;
      this->MinimizeBox = false;
      this->Name = L"win_Chat_Commands";
      this->ShowIcon = false;
      this->ShowInTaskbar = false;
      this->StartPosition = System::Windows::Forms::FormStartPosition::CenterParent;
      this->Text = L"Commands and Shortcuts";
      this->ResumeLayout(false);
      this->PerformLayout();

         }
#pragma endregion
   private: void Enable_shrtcts_chkBx_CheckedChanged(System::Object^  sender, System::EventArgs^  e);
   private: void okButton_Click(System::Object^  sender, System::EventArgs^  e);
   private: void commands_lstBx_SelectedIndexChanged(System::Object^  sender, System::EventArgs^  e);
   private: void toggle_onoff_btn_Click(System::Object^  sender, System::EventArgs^  e);
   private: void cmd_on_btn_Click(System::Object^  sender, System::EventArgs^  e);
   private: void cmd_off_btn_Click(System::Object^  sender, System::EventArgs^  e);
   private: void activate_set_btn_Click(System::Object^  sender, System::EventArgs^  e);
};
}
