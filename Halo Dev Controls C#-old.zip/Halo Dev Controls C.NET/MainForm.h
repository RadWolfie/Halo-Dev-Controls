/********************************************************************************
	 -- Halo Dev Controls
    Copyright � 2011 Jesus7Freak

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*********************************************************************************
	File:    MainForm.h
	Project: Halo Dev Controls C.NET
	Author:  Jesus7Freak
	Date:    11/22/2011
	Game:    Halo and Halo Custom Edition
	Version: all
*********************************************************************************/
#pragma once
#include "WindowsInput.h"
#include "HaloLib.h"

namespace RPG_Beta6_2DevControls {
   
   struct DLL_ADDRS
   {
      DWORD halo_cmd_keys;
      DWORD rpgb62_cmd_keys;
      DWORD cmd_sk_enabled;
      DWORD CurrentDir;
      DWORD game;
   };

   using namespace WindowsInput;

	/// <summary>
	/// Summary for Form1
	///
	/// WARNING: If you change the name of this class, you will need to change the
	///          'Resource File Name' property for the managed resource compiler tool
	///          associated with all .resx files this class depends on.  Otherwise,
	///          the designers will not be able to interact properly with localized
	///          resources associated with this form.
	/// </summary>
	public ref class MainForm : public System::Windows::Forms::Form
	{
   public: System::Windows::Forms::MaskedTextBox^  halo_timer_txt;
   public: System::Windows::Forms::MaskedTextBox^  BLD_timer_txt;
   private: System::Windows::Forms::ToolStripMenuItem^  ExtrasToolStripMenuItem;
   private: System::Windows::Forms::ToolStripMenuItem^  Help_halo_commands;
   private: System::Windows::Forms::ToolStripMenuItem^  Help_rpgbeta6_2_commands;
   public: System::Windows::Forms::CheckBox^  ejection_chkBx;
   public: System::Windows::Forms::Button^  alarm_btn;
   public: System::Windows::Forms::CheckBox^  letterbox_chkBx;
   public: System::Windows::Forms::CheckBox^  showhud_chkBx;
   public: System::Windows::Forms::CheckBox^  IF_chkBx;
   public: System::Windows::Forms::CheckBox^  Deathless_chkBx;
   public: System::Windows::Forms::Label^  status_lbl4;
   public: System::Windows::Forms::Label^  status_lbl3;
   public: System::Windows::Forms::Timer^  update_info_timer;
   public: System::Windows::Forms::Label^  status_lbl2;
   public: System::Windows::Forms::Label^  status_lbl;
   public: System::Windows::Forms::Button^  halo_activate;
   public: System::Windows::Forms::Label^  halo_lbl;
   public: System::Windows::Forms::Button^  halo_set_t;
   public: System::Windows::Forms::Button^  btn_console;

   public: System::Windows::Forms::ComboBox^  ToD_cb;
   public: System::Windows::Forms::Button^  BLD_activate;
   public: System::Windows::Forms::Label^  BLD_lbl;
   public: System::Windows::Forms::Button^  BLD_set_t;
   private: System::Windows::Forms::MenuStrip^  Menu;
   public: System::Windows::Forms::Label^  rcon_lbl;
   private: System::Windows::Forms::ToolStripMenuItem^  Help_about;
   
   public: 
      RWMemory *Halo_Process;
      HANDLE hHDC;
      DLL_ADDRS *dll_addresses;
      
      enum class game_types : WORD
         { not_running = 0, Halo = 1, HCE = 2} running_gt;
         
      enum class server_type : WORD
         { main_menu = 0, client = 1, host = 2 } running_sv_t;
      
      BYTE C_Setting,
           temp;
           
      short Lock_sec, 
            Halo_sec;
            
      bool control_enabled_change, 
           rpgb6_2_running, 
           display_txt,
           dll_injector_failed,
           dev_enabled,
           console_enabled,
           alarm_on,
           Locked,
           Nuked;
      
      wchar_t* main_module_name;
      DWORD Current_Map_address,
            Cheats_address,
            ServerType_address,
            Device_Groups_Header_ptr_address,
            HS_Global_Header_ptr_address,
            dll_addrs_ptr,
            Dev_enabled_address,
            Console_enabled_address,
            ShowHud_address,
            LetterBox_address,
            RiderEjection_address;
            //rapid_fire_hook_address,
            //time_freeze_hook_address,
            //grav_boots_hook_address,
            //vehicle_ntr_hook_address;
      
   private: System::Windows::Forms::ToolStripMenuItem^  playerCommandsToolStripMenuItem;
   public: System::Windows::Forms::Button^  btn_dev;




   private: System::Windows::Forms::ToolStripMenuItem^  teleportLocationsToolStripMenuItem;

   public:    
		MainForm(void);

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~MainForm();
		
   private: System::ComponentModel::IContainer^  components;

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>


#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
      this->components = (gcnew System::ComponentModel::Container());
      System::ComponentModel::ComponentResourceManager^  resources = (gcnew System::ComponentModel::ComponentResourceManager(MainForm::typeid));
      this->halo_timer_txt = (gcnew System::Windows::Forms::MaskedTextBox());
      this->BLD_timer_txt = (gcnew System::Windows::Forms::MaskedTextBox());
      this->ExtrasToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
      this->Help_halo_commands = (gcnew System::Windows::Forms::ToolStripMenuItem());
      this->Help_rpgbeta6_2_commands = (gcnew System::Windows::Forms::ToolStripMenuItem());
      this->playerCommandsToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
      this->teleportLocationsToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
      this->Help_about = (gcnew System::Windows::Forms::ToolStripMenuItem());
      this->ejection_chkBx = (gcnew System::Windows::Forms::CheckBox());
      this->alarm_btn = (gcnew System::Windows::Forms::Button());
      this->letterbox_chkBx = (gcnew System::Windows::Forms::CheckBox());
      this->showhud_chkBx = (gcnew System::Windows::Forms::CheckBox());
      this->IF_chkBx = (gcnew System::Windows::Forms::CheckBox());
      this->Deathless_chkBx = (gcnew System::Windows::Forms::CheckBox());
      this->status_lbl4 = (gcnew System::Windows::Forms::Label());
      this->status_lbl3 = (gcnew System::Windows::Forms::Label());
      this->update_info_timer = (gcnew System::Windows::Forms::Timer(this->components));
      this->status_lbl2 = (gcnew System::Windows::Forms::Label());
      this->status_lbl = (gcnew System::Windows::Forms::Label());
      this->halo_activate = (gcnew System::Windows::Forms::Button());
      this->halo_lbl = (gcnew System::Windows::Forms::Label());
      this->halo_set_t = (gcnew System::Windows::Forms::Button());
      this->btn_console = (gcnew System::Windows::Forms::Button());
      this->ToD_cb = (gcnew System::Windows::Forms::ComboBox());
      this->BLD_activate = (gcnew System::Windows::Forms::Button());
      this->BLD_lbl = (gcnew System::Windows::Forms::Label());
      this->BLD_set_t = (gcnew System::Windows::Forms::Button());
      this->Menu = (gcnew System::Windows::Forms::MenuStrip());
      this->rcon_lbl = (gcnew System::Windows::Forms::Label());
      this->btn_dev = (gcnew System::Windows::Forms::Button());
      this->Menu->SuspendLayout();
      this->SuspendLayout();
      // 
      // halo_timer_txt
      // 
      this->halo_timer_txt->Enabled = false;
      this->halo_timer_txt->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 9, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
         static_cast<System::Byte>(0)));
      this->halo_timer_txt->Location = System::Drawing::Point(121, 107);
      this->halo_timer_txt->Name = L"halo_timer_txt";
      this->halo_timer_txt->Size = System::Drawing::Size(51, 21);
      this->halo_timer_txt->TabIndex = 54;
      this->halo_timer_txt->Text = L"seconds";
      this->halo_timer_txt->ValidatingType = System::Int32::typeid;
      // 
      // BLD_timer_txt
      // 
      this->BLD_timer_txt->Enabled = false;
      this->BLD_timer_txt->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 9, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
         static_cast<System::Byte>(0)));
      this->BLD_timer_txt->Location = System::Drawing::Point(121, 67);
      this->BLD_timer_txt->Name = L"BLD_timer_txt";
      this->BLD_timer_txt->Size = System::Drawing::Size(51, 21);
      this->BLD_timer_txt->TabIndex = 53;
      this->BLD_timer_txt->Text = L"seconds";
      this->BLD_timer_txt->ValidatingType = System::Int32::typeid;
      // 
      // ExtrasToolStripMenuItem
      // 
      this->ExtrasToolStripMenuItem->Alignment = System::Windows::Forms::ToolStripItemAlignment::Right;
      this->ExtrasToolStripMenuItem->AutoSize = false;
      this->ExtrasToolStripMenuItem->BackColor = System::Drawing::Color::Transparent;
      this->ExtrasToolStripMenuItem->DropDownItems->AddRange(gcnew cli::array< System::Windows::Forms::ToolStripItem^  >(5) {this->Help_halo_commands, 
         this->Help_rpgbeta6_2_commands, this->playerCommandsToolStripMenuItem, this->teleportLocationsToolStripMenuItem, this->Help_about});
      this->ExtrasToolStripMenuItem->Font = (gcnew System::Drawing::Font(L"Segoe UI", 9.2F));
      this->ExtrasToolStripMenuItem->ForeColor = System::Drawing::SystemColors::Menu;
      this->ExtrasToolStripMenuItem->Name = L"ExtrasToolStripMenuItem";
      this->ExtrasToolStripMenuItem->Padding = System::Windows::Forms::Padding(0);
      this->ExtrasToolStripMenuItem->Size = System::Drawing::Size(94, 22);
      this->ExtrasToolStripMenuItem->Text = L"Extras";
      // 
      // Help_halo_commands
      // 
      this->Help_halo_commands->BackColor = System::Drawing::Color::White;
      this->Help_halo_commands->Name = L"Help_halo_commands";
      this->Help_halo_commands->Size = System::Drawing::Size(221, 22);
      this->Help_halo_commands->Text = L"Dev Commands";
      this->Help_halo_commands->Click += gcnew System::EventHandler(this, &MainForm::Help_halo_commands_Click);
      // 
      // Help_rpgbeta6_2_commands
      // 
      this->Help_rpgbeta6_2_commands->Name = L"Help_rpgbeta6_2_commands";
      this->Help_rpgbeta6_2_commands->Size = System::Drawing::Size(221, 22);
      this->Help_rpgbeta6_2_commands->Text = L"RPG_Beta6_2 Commands";
      this->Help_rpgbeta6_2_commands->Click += gcnew System::EventHandler(this, &MainForm::Help_rpgbeta6_2_commands_Click);
      // 
      // playerCommandsToolStripMenuItem
      // 
      this->playerCommandsToolStripMenuItem->Name = L"playerCommandsToolStripMenuItem";
      this->playerCommandsToolStripMenuItem->Size = System::Drawing::Size(221, 22);
      this->playerCommandsToolStripMenuItem->Text = L"Player Commands";
      this->playerCommandsToolStripMenuItem->Click += gcnew System::EventHandler(this, &MainForm::playerCommandsToolStripMenuItem_Click);
      // 
      // teleportLocationsToolStripMenuItem
      // 
      this->teleportLocationsToolStripMenuItem->Name = L"teleportLocationsToolStripMenuItem";
      this->teleportLocationsToolStripMenuItem->Size = System::Drawing::Size(221, 22);
      this->teleportLocationsToolStripMenuItem->Text = L"Teleport Locations";
      this->teleportLocationsToolStripMenuItem->Click += gcnew System::EventHandler(this, &MainForm::teleportLocationsToolStripMenuItem_Click);
      // 
      // Help_about
      // 
      this->Help_about->Name = L"Help_about";
      this->Help_about->Size = System::Drawing::Size(221, 22);
      this->Help_about->Text = L"About Halo Dev Controls";
      this->Help_about->Click += gcnew System::EventHandler(this, &MainForm::Help_about_Click);
      // 
      // ejection_chkBx
      // 
      this->ejection_chkBx->AutoSize = true;
      this->ejection_chkBx->BackColor = System::Drawing::Color::Transparent;
      this->ejection_chkBx->Enabled = false;
      this->ejection_chkBx->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 9, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
         static_cast<System::Byte>(0)));
      this->ejection_chkBx->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(51)), static_cast<System::Int32>(static_cast<System::Byte>(153)), 
         static_cast<System::Int32>(static_cast<System::Byte>(255)));
      this->ejection_chkBx->Location = System::Drawing::Point(3, 131);
      this->ejection_chkBx->Name = L"ejection_chkBx";
      this->ejection_chkBx->Size = System::Drawing::Size(103, 19);
      this->ejection_chkBx->TabIndex = 52;
      this->ejection_chkBx->Text = L"Rider Ejection";
      this->ejection_chkBx->UseVisualStyleBackColor = false;
      this->ejection_chkBx->CheckedChanged += gcnew System::EventHandler(this, &MainForm::ejection_chkBx_CheckedChanged);
      // 
      // alarm_btn
      // 
      this->alarm_btn->BackColor = System::Drawing::Color::Transparent;
      this->alarm_btn->Enabled = false;
      this->alarm_btn->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
      this->alarm_btn->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 9, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
         static_cast<System::Byte>(0)));
      this->alarm_btn->ForeColor = System::Drawing::Color::Red;
      this->alarm_btn->Location = System::Drawing::Point(251, 23);
      this->alarm_btn->Name = L"alarm_btn";
      this->alarm_btn->Size = System::Drawing::Size(75, 23);
      this->alarm_btn->TabIndex = 38;
      this->alarm_btn->Text = L"Alarm On";
      this->alarm_btn->UseVisualStyleBackColor = false;
      this->alarm_btn->Click += gcnew System::EventHandler(this, &MainForm::alarm_btn_Click);
      // 
      // letterbox_chkBx
      // 
      this->letterbox_chkBx->AutoSize = true;
      this->letterbox_chkBx->BackColor = System::Drawing::Color::Transparent;
      this->letterbox_chkBx->Enabled = false;
      this->letterbox_chkBx->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 9, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
         static_cast<System::Byte>(0)));
      this->letterbox_chkBx->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(51)), static_cast<System::Int32>(static_cast<System::Byte>(153)), 
         static_cast<System::Int32>(static_cast<System::Byte>(255)));
      this->letterbox_chkBx->Location = System::Drawing::Point(3, 111);
      this->letterbox_chkBx->Name = L"letterbox_chkBx";
      this->letterbox_chkBx->Size = System::Drawing::Size(81, 19);
      this->letterbox_chkBx->TabIndex = 49;
      this->letterbox_chkBx->Text = L"Letter Box";
      this->letterbox_chkBx->UseVisualStyleBackColor = false;
      this->letterbox_chkBx->CheckedChanged += gcnew System::EventHandler(this, &MainForm::letterbox_chkBx_CheckedChanged);
      // 
      // showhud_chkBx
      // 
      this->showhud_chkBx->AutoSize = true;
      this->showhud_chkBx->BackColor = System::Drawing::Color::Transparent;
      this->showhud_chkBx->Enabled = false;
      this->showhud_chkBx->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 9, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
         static_cast<System::Byte>(0)));
      this->showhud_chkBx->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(51)), static_cast<System::Int32>(static_cast<System::Byte>(153)), 
         static_cast<System::Int32>(static_cast<System::Byte>(255)));
      this->showhud_chkBx->Location = System::Drawing::Point(3, 93);
      this->showhud_chkBx->Name = L"showhud_chkBx";
      this->showhud_chkBx->Size = System::Drawing::Size(87, 19);
      this->showhud_chkBx->TabIndex = 48;
      this->showhud_chkBx->Text = L"Show HUD";
      this->showhud_chkBx->UseVisualStyleBackColor = false;
      this->showhud_chkBx->CheckedChanged += gcnew System::EventHandler(this, &MainForm::showhud_chkBx_CheckedChanged);
      // 
      // IF_chkBx
      // 
      this->IF_chkBx->AutoSize = true;
      this->IF_chkBx->BackColor = System::Drawing::Color::Transparent;
      this->IF_chkBx->Enabled = false;
      this->IF_chkBx->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 9, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
         static_cast<System::Byte>(0)));
      this->IF_chkBx->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(51)), static_cast<System::Int32>(static_cast<System::Byte>(153)), 
         static_cast<System::Int32>(static_cast<System::Byte>(255)));
      this->IF_chkBx->Location = System::Drawing::Point(3, 73);
      this->IF_chkBx->Name = L"IF_chkBx";
      this->IF_chkBx->Size = System::Drawing::Size(101, 19);
      this->IF_chkBx->TabIndex = 47;
      this->IF_chkBx->Text = L"Infinite Ammo";
      this->IF_chkBx->UseVisualStyleBackColor = false;
      this->IF_chkBx->CheckedChanged += gcnew System::EventHandler(this, &MainForm::IF_chkBx_CheckedChanged);
      // 
      // Deathless_chkBx
      // 
      this->Deathless_chkBx->AutoSize = true;
      this->Deathless_chkBx->BackColor = System::Drawing::Color::Transparent;
      this->Deathless_chkBx->Enabled = false;
      this->Deathless_chkBx->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 9, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
         static_cast<System::Byte>(0)));
      this->Deathless_chkBx->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(51)), static_cast<System::Int32>(static_cast<System::Byte>(153)), 
         static_cast<System::Int32>(static_cast<System::Byte>(255)));
      this->Deathless_chkBx->Location = System::Drawing::Point(3, 54);
      this->Deathless_chkBx->Name = L"Deathless_chkBx";
      this->Deathless_chkBx->Size = System::Drawing::Size(81, 19);
      this->Deathless_chkBx->TabIndex = 46;
      this->Deathless_chkBx->Text = L"Deathless";
      this->Deathless_chkBx->UseVisualStyleBackColor = false;
      this->Deathless_chkBx->CheckedChanged += gcnew System::EventHandler(this, &MainForm::Deathless_chkBx_CheckedChanged);
      // 
      // status_lbl4
      // 
      this->status_lbl4->AutoSize = true;
      this->status_lbl4->BackColor = System::Drawing::Color::Transparent;
      this->status_lbl4->Font = (gcnew System::Drawing::Font(L"Tahoma", 9.75F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
         static_cast<System::Byte>(0)));
      this->status_lbl4->ForeColor = System::Drawing::SystemColors::Menu;
      this->status_lbl4->Location = System::Drawing::Point(119, 0);
      this->status_lbl4->Name = L"status_lbl4";
      this->status_lbl4->Size = System::Drawing::Size(16, 16);
      this->status_lbl4->TabIndex = 45;
      this->status_lbl4->Text = L"  ";
      // 
      // status_lbl3
      // 
      this->status_lbl3->AutoSize = true;
      this->status_lbl3->BackColor = System::Drawing::Color::Transparent;
      this->status_lbl3->Font = (gcnew System::Drawing::Font(L"Tahoma", 9.75F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
         static_cast<System::Byte>(0)));
      this->status_lbl3->ForeColor = System::Drawing::SystemColors::Menu;
      this->status_lbl3->Location = System::Drawing::Point(79, 0);
      this->status_lbl3->Name = L"status_lbl3";
      this->status_lbl3->Size = System::Drawing::Size(20, 16);
      this->status_lbl3->TabIndex = 44;
      this->status_lbl3->Text = L"   ";
      // 
      // update_info_timer
      // 
      this->update_info_timer->Enabled = true;
      this->update_info_timer->Interval = 700;
      this->update_info_timer->Tick += gcnew System::EventHandler(this, &MainForm::update_info_timer_Tick);
      // 
      // status_lbl2
      // 
      this->status_lbl2->AutoSize = true;
      this->status_lbl2->BackColor = System::Drawing::Color::Transparent;
      this->status_lbl2->Font = (gcnew System::Drawing::Font(L"Tahoma", 9.75F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
         static_cast<System::Byte>(0)));
      this->status_lbl2->ForeColor = System::Drawing::Color::Red;
      this->status_lbl2->Location = System::Drawing::Point(55, 0);
      this->status_lbl2->Name = L"status_lbl2";
      this->status_lbl2->Size = System::Drawing::Size(25, 16);
      this->status_lbl2->TabIndex = 43;
      this->status_lbl2->Text = L"Off";
      // 
      // status_lbl
      // 
      this->status_lbl->AutoSize = true;
      this->status_lbl->BackColor = System::Drawing::Color::Transparent;
      this->status_lbl->Font = (gcnew System::Drawing::Font(L"Tahoma", 9.75F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
         static_cast<System::Byte>(0)));
      this->status_lbl->ForeColor = System::Drawing::SystemColors::Menu;
      this->status_lbl->Location = System::Drawing::Point(0, 0);
      this->status_lbl->Name = L"status_lbl";
      this->status_lbl->Size = System::Drawing::Size(57, 16);
      this->status_lbl->TabIndex = 42;
      this->status_lbl->Text = L"Halo CE:";
      // 
      // halo_activate
      // 
      this->halo_activate->BackColor = System::Drawing::Color::Transparent;
      this->halo_activate->Enabled = false;
      this->halo_activate->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
      this->halo_activate->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 9, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
         static_cast<System::Byte>(0)));
      this->halo_activate->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(51)), static_cast<System::Int32>(static_cast<System::Byte>(153)), 
         static_cast<System::Int32>(static_cast<System::Byte>(255)));
      this->halo_activate->Location = System::Drawing::Point(246, 105);
      this->halo_activate->Name = L"halo_activate";
      this->halo_activate->Size = System::Drawing::Size(80, 25);
      this->halo_activate->TabIndex = 41;
      this->halo_activate->Text = L"Fire";
      this->halo_activate->UseVisualStyleBackColor = false;
      this->halo_activate->Click += gcnew System::EventHandler(this, &MainForm::halo_activate_Click);
      // 
      // halo_lbl
      // 
      this->halo_lbl->AutoSize = true;
      this->halo_lbl->BackColor = System::Drawing::Color::Transparent;
      this->halo_lbl->Enabled = false;
      this->halo_lbl->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 9, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
         static_cast<System::Byte>(0)));
      this->halo_lbl->ForeColor = System::Drawing::SystemColors::Menu;
      this->halo_lbl->Location = System::Drawing::Point(197, 90);
      this->halo_lbl->Name = L"halo_lbl";
      this->halo_lbl->Size = System::Drawing::Size(33, 15);
      this->halo_lbl->TabIndex = 40;
      this->halo_lbl->Text = L"Halo";
      // 
      // halo_set_t
      // 
      this->halo_set_t->BackColor = System::Drawing::Color::Transparent;
      this->halo_set_t->Enabled = false;
      this->halo_set_t->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
      this->halo_set_t->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 9, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
         static_cast<System::Byte>(0)));
      this->halo_set_t->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(51)), static_cast<System::Int32>(static_cast<System::Byte>(153)), 
         static_cast<System::Int32>(static_cast<System::Byte>(255)));
      this->halo_set_t->Location = System::Drawing::Point(178, 105);
      this->halo_set_t->Name = L"halo_set_t";
      this->halo_set_t->Size = System::Drawing::Size(62, 25);
      this->halo_set_t->TabIndex = 39;
      this->halo_set_t->Text = L"Set Timer";
      this->halo_set_t->UseVisualStyleBackColor = false;
      this->halo_set_t->Click += gcnew System::EventHandler(this, &MainForm::halo_set_t_Click);
      // 
      // btn_console
      // 
      this->btn_console->BackColor = System::Drawing::Color::Transparent;
      this->btn_console->Enabled = false;
      this->btn_console->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
      this->btn_console->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 9, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
         static_cast<System::Byte>(0)));
      this->btn_console->ForeColor = System::Drawing::Color::Red;
      this->btn_console->Location = System::Drawing::Point(3, 26);
      this->btn_console->Name = L"btn_console";
      this->btn_console->Size = System::Drawing::Size(115, 25);
      this->btn_console->TabIndex = 33;
      this->btn_console->Text = L"Enable Console";
      this->btn_console->UseVisualStyleBackColor = false;
      this->btn_console->Visible = false;
      this->btn_console->Click += gcnew System::EventHandler(this, &MainForm::btn_console_Click);
      // 
      // ToD_cb
      // 
      this->ToD_cb->DisplayMember = L"Day";
      this->ToD_cb->Enabled = false;
      this->ToD_cb->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 9, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
         static_cast<System::Byte>(0)));
      this->ToD_cb->ForeColor = System::Drawing::SystemColors::WindowText;
      this->ToD_cb->FormattingEnabled = true;
      this->ToD_cb->Items->AddRange(gcnew cli::array< System::Object^  >(3) {L"Day", L"Rain", L"Night"});
      this->ToD_cb->Location = System::Drawing::Point(193, 23);
      this->ToD_cb->MaxLength = 3;
      this->ToD_cb->Name = L"ToD_cb";
      this->ToD_cb->Size = System::Drawing::Size(54, 23);
      this->ToD_cb->TabIndex = 37;
      this->ToD_cb->Text = L"Day";
      this->ToD_cb->SelectedIndexChanged += gcnew System::EventHandler(this, &MainForm::ToD_cb_SelectedIndexChanged);
      // 
      // BLD_activate
      // 
      this->BLD_activate->BackColor = System::Drawing::Color::Transparent;
      this->BLD_activate->Enabled = false;
      this->BLD_activate->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
      this->BLD_activate->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 9, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
         static_cast<System::Byte>(0)));
      this->BLD_activate->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(51)), static_cast<System::Int32>(static_cast<System::Byte>(153)), 
         static_cast<System::Int32>(static_cast<System::Byte>(255)));
      this->BLD_activate->Location = System::Drawing::Point(246, 65);
      this->BLD_activate->Name = L"BLD_activate";
      this->BLD_activate->Size = System::Drawing::Size(80, 25);
      this->BLD_activate->TabIndex = 36;
      this->BLD_activate->Text = L"Activate";
      this->BLD_activate->UseVisualStyleBackColor = false;
      this->BLD_activate->Click += gcnew System::EventHandler(this, &MainForm::BLD_activate_Click);
      // 
      // BLD_lbl
      // 
      this->BLD_lbl->AutoSize = true;
      this->BLD_lbl->BackColor = System::Drawing::Color::Transparent;
      this->BLD_lbl->Enabled = false;
      this->BLD_lbl->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 9, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
         static_cast<System::Byte>(0)));
      this->BLD_lbl->ForeColor = System::Drawing::SystemColors::Menu;
      this->BLD_lbl->Location = System::Drawing::Point(163, 50);
      this->BLD_lbl->Name = L"BLD_lbl";
      this->BLD_lbl->Size = System::Drawing::Size(99, 15);
      this->BLD_lbl->TabIndex = 35;
      this->BLD_lbl->Text = L"Base Lock Down";
      // 
      // BLD_set_t
      // 
      this->BLD_set_t->BackColor = System::Drawing::Color::Transparent;
      this->BLD_set_t->Enabled = false;
      this->BLD_set_t->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
      this->BLD_set_t->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 9, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
         static_cast<System::Byte>(0)));
      this->BLD_set_t->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(51)), static_cast<System::Int32>(static_cast<System::Byte>(153)), 
         static_cast<System::Int32>(static_cast<System::Byte>(255)));
      this->BLD_set_t->Location = System::Drawing::Point(178, 65);
      this->BLD_set_t->Name = L"BLD_set_t";
      this->BLD_set_t->Size = System::Drawing::Size(62, 25);
      this->BLD_set_t->TabIndex = 34;
      this->BLD_set_t->Text = L"Set Timer";
      this->BLD_set_t->UseVisualStyleBackColor = false;
      this->BLD_set_t->Click += gcnew System::EventHandler(this, &MainForm::BLD_set_t_Click);
      // 
      // Menu
      // 
      this->Menu->AutoSize = false;
      this->Menu->BackColor = System::Drawing::Color::Transparent;
      this->Menu->Items->AddRange(gcnew cli::array< System::Windows::Forms::ToolStripItem^  >(1) {this->ExtrasToolStripMenuItem});
      this->Menu->Location = System::Drawing::Point(0, 0);
      this->Menu->Name = L"Menu";
      this->Menu->RenderMode = System::Windows::Forms::ToolStripRenderMode::System;
      this->Menu->Size = System::Drawing::Size(329, 20);
      this->Menu->TabIndex = 51;
      this->Menu->Text = L"menuStrip1";
      // 
      // rcon_lbl
      // 
      this->rcon_lbl->AutoSize = true;
      this->rcon_lbl->BackColor = System::Drawing::Color::Transparent;
      this->rcon_lbl->Cursor = System::Windows::Forms::Cursors::Hand;
      this->rcon_lbl->Enabled = false;
      this->rcon_lbl->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 9, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
         static_cast<System::Byte>(0)));
      this->rcon_lbl->ForeColor = System::Drawing::SystemColors::ControlDark;
      this->rcon_lbl->Location = System::Drawing::Point(119, 26);
      this->rcon_lbl->Name = L"rcon_lbl";
      this->rcon_lbl->Size = System::Drawing::Size(70, 15);
      this->rcon_lbl->TabIndex = 50;
      this->rcon_lbl->Text = L"Main Menu";
      this->rcon_lbl->TextAlign = System::Drawing::ContentAlignment::TopCenter;
      // 
      // btn_dev
      // 
      this->btn_dev->BackColor = System::Drawing::Color::Transparent;
      this->btn_dev->Enabled = false;
      this->btn_dev->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
      this->btn_dev->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 9, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
         static_cast<System::Byte>(0)));
      this->btn_dev->ForeColor = System::Drawing::Color::Red;
      this->btn_dev->Location = System::Drawing::Point(16, 26);
      this->btn_dev->Name = L"btn_dev";
      this->btn_dev->Size = System::Drawing::Size(89, 25);
      this->btn_dev->TabIndex = 55;
      this->btn_dev->Text = L"Enable Dev";
      this->btn_dev->UseVisualStyleBackColor = false;
      this->btn_dev->Click += gcnew System::EventHandler(this, &MainForm::dev_btn_Click);
      // 
      // MainForm
      // 
      this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
      this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
      this->BackColor = System::Drawing::Color::White;
      this->BackgroundImage = (cli::safe_cast<System::Drawing::Image^  >(resources->GetObject(L"$this.BackgroundImage")));
      this->BackgroundImageLayout = System::Windows::Forms::ImageLayout::Stretch;
      this->ClientSize = System::Drawing::Size(329, 151);
      this->Controls->Add(this->btn_dev);
      this->Controls->Add(this->halo_timer_txt);
      this->Controls->Add(this->BLD_timer_txt);
      this->Controls->Add(this->ejection_chkBx);
      this->Controls->Add(this->alarm_btn);
      this->Controls->Add(this->letterbox_chkBx);
      this->Controls->Add(this->showhud_chkBx);
      this->Controls->Add(this->IF_chkBx);
      this->Controls->Add(this->Deathless_chkBx);
      this->Controls->Add(this->status_lbl4);
      this->Controls->Add(this->status_lbl3);
      this->Controls->Add(this->status_lbl2);
      this->Controls->Add(this->status_lbl);
      this->Controls->Add(this->halo_activate);
      this->Controls->Add(this->halo_lbl);
      this->Controls->Add(this->halo_set_t);
      this->Controls->Add(this->btn_console);
      this->Controls->Add(this->ToD_cb);
      this->Controls->Add(this->BLD_activate);
      this->Controls->Add(this->BLD_lbl);
      this->Controls->Add(this->BLD_set_t);
      this->Controls->Add(this->Menu);
      this->Controls->Add(this->rcon_lbl);
      this->DoubleBuffered = true;
      this->FormBorderStyle = System::Windows::Forms::FormBorderStyle::FixedToolWindow;
      this->Icon = (cli::safe_cast<System::Drawing::Icon^  >(resources->GetObject(L"$this.Icon")));
      this->MaximizeBox = false;
      this->MinimizeBox = false;
      this->Name = L"MainForm";
      this->Text = L"Halo Dev Controls  -  Jesus7Freak";
      this->TransparencyKey = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(64)), static_cast<System::Int32>(static_cast<System::Byte>(0)), 
         static_cast<System::Int32>(static_cast<System::Byte>(64)));
      this->Menu->ResumeLayout(false);
      this->Menu->PerformLayout();
      this->ResumeLayout(false);
      this->PerformLayout();

         }
#pragma endregion

   private: 
      void update_info_timer_Tick(System::Object^  sender, System::EventArgs^  e);
   
      void dev_btn_Click(System::Object^  sender, System::EventArgs^  e);
      void btn_console_Click(System::Object^  sender, System::EventArgs^  e);
      void Deathless_chkBx_CheckedChanged(System::Object^  sender, System::EventArgs^  e);
      void IF_chkBx_CheckedChanged(System::Object^  sender, System::EventArgs^  e);
      void showhud_chkBx_CheckedChanged(System::Object^  sender, System::EventArgs^  e);
      void letterbox_chkBx_CheckedChanged(System::Object^  sender, System::EventArgs^  e);
      //void ckbx_rapid_fire_CheckedChanged(System::Object^  sender, System::EventArgs^  e);
      //void ckbx_time_freeze_CheckedChanged(System::Object^  sender, System::EventArgs^  e);
      //void ckbx_grav_boots_CheckedChanged(System::Object^  sender, System::EventArgs^  e);
      //void ckbx_vehicle_ntr_CheckedChanged(System::Object^  sender, System::EventArgs^  e);
      void ejection_chkBx_CheckedChanged(System::Object^  sender, System::EventArgs^  e);
      void ToD_cb_SelectedIndexChanged(System::Object^  sender, System::EventArgs^  e);
      void alarm_btn_Click(System::Object^  sender, System::EventArgs^  e);
      void BLD_set_t_Click(System::Object^  sender, System::EventArgs^  e);
      void BLD_activate_Click(System::Object^  sender, System::EventArgs^  e);
      void halo_set_t_Click(System::Object^  sender, System::EventArgs^  e);
      void halo_activate_Click(System::Object^  sender, System::EventArgs^  e);
      //void debug_vars(System::DateTime time);
      
      void Help_halo_commands_Click(System::Object^  sender, System::EventArgs^  e);
      void Help_rpgbeta6_2_commands_Click(System::Object^  sender, System::EventArgs^  e);
      void playerCommandsToolStripMenuItem_Click(System::Object^  sender, System::EventArgs^  e);
      void teleportLocationsToolStripMenuItem_Click(System::Object^  sender, System::EventArgs^  e);
      void Help_about_Click(System::Object^  sender, System::EventArgs^  e);
};
}

