#include "Teleport_Locations.h"

namespace RPG_Beta6_2DevControls
{
   Teleport_Locations::Teleport_Locations(std::vector<MAPS>* locations, bool *cmd_changed)
   {
      InitializeComponent();
      Locations = locations;
      locations_changed_ptr = cmd_changed;
      intern_change = false;
      
      lstbx_maps->Items->Clear();
      lstbx_locations->Items->Clear();
      for (unsigned int i = 0; i < Locations->size(); i++)
         lstbx_maps->Items->Add(gcnew System::String((*Locations)[i].map_name));
         
      //trigger lstBx_SelectedIndexChanged
      lstbx_maps->SelectedIndex = -1;
      if (Locations->size())
      {
         lstbx_maps->SelectedIndex = 0;
         btn_add->Enabled = true;
         btn_remove->Enabled = true;
         btn_set_location->Enabled = true;
      }
      else
      {
         btn_add->Enabled = false;
         btn_remove->Enabled = false;
         btn_set_location->Enabled = false;
      }
   }
   
   void Teleport_Locations::okButton_Click(System::Object^  sender, System::EventArgs^  e)
   {
      if (intern_change)
         *locations_changed_ptr = true;
   }
   
   void Teleport_Locations::no_space_mask(System::Object^  sender, System::Windows::Forms::KeyEventArgs^  e)
   {
      if (e->KeyCode == System::Windows::Forms::Keys::Space)
      {
         e->SuppressKeyPress = true;
      }
   }
   
   void Teleport_Locations::float_mask(System::Object^  sender, System::Windows::Forms::KeyEventArgs^  e)
   {
      bool SuppressKey = true;
      unsigned int vKey = (unsigned int)e->KeyCode;//to save all those function calls...
      
      /*if (keycode != System::Windows::Forms::Keys::OemMinus && 
         keycode != System::Windows::Forms::Keys::OemPeriod &&
         keycode != System::Windows::Forms::Keys::Subtract &&
         keycode != System::Windows::Forms::Keys::Decimal &&
         keycode != System::Windows::Forms::Keys::D0 &&
         keycode != System::Windows::Forms::Keys::D1 &&
         keycode != System::Windows::Forms::Keys::D2 &&
         keycode != System::Windows::Forms::Keys::D3 &&
         keycode != System::Windows::Forms::Keys::D4 &&
         keycode != System::Windows::Forms::Keys::D5 &&
         keycode != System::Windows::Forms::Keys::D6 &&
         keycode != System::Windows::Forms::Keys::D7 &&
         keycode != System::Windows::Forms::Keys::D8 &&
         keycode != System::Windows::Forms::Keys::D9 &&
         keycode != System::Windows::Forms::Keys::NumPad0 &&
         keycode != System::Windows::Forms::Keys::NumPad1 &&
         keycode != System::Windows::Forms::Keys::NumPad2 &&
         keycode != System::Windows::Forms::Keys::NumPad3 &&
         keycode != System::Windows::Forms::Keys::NumPad4 &&
         keycode != System::Windows::Forms::Keys::NumPad5 &&
         keycode != System::Windows::Forms::Keys::NumPad6 &&
         keycode != System::Windows::Forms::Keys::NumPad7 &&
         keycode != System::Windows::Forms::Keys::NumPad8 &&
         keycode != System::Windows::Forms::Keys::NumPad9 &&
         keycode != System::Windows::Forms::Keys::Back &&
         keycode != System::Windows::Forms::Keys::Delete && !e->Control)*/
         
      if (vKey >= '0' && vKey <= '9' ||
         vKey >= 0x60 /*VK_NUMPAD0*/ && vKey <= 0x69 /*VK_NUMPAD9*/ ||
         vKey == 0xBD /*VK_OEM_MINUS*/ ||
         vKey == 0xBE/*VK_OEM_PERIOD*/ ||
         vKey == 0x6D/*VK_SUBTRACT*/ ||
         vKey == 0x6E/*VK_DECIMAL*/ ||
         vKey == 0x08/*VK_BACK*/ ||
         vKey == 0x2E/*VK_DELETE*/ ||
         e->Control)
      {
         SuppressKey = false;
      }
      
      e->SuppressKeyPress = SuppressKey;
   }
   
   void Teleport_Locations::lstbx_maps_SelectedIndexChanged(System::Object^  sender, System::EventArgs^  e)
   {
      if (lstbx_maps->SelectedIndex != -1)
      {
         lstbx_locations->Items->Clear();
         for (unsigned int i = 0; i < (*Locations)[lstbx_maps->SelectedIndex].teleport_locations.size(); i++)
            lstbx_locations->Items->Add(gcnew System::String((*Locations)[lstbx_maps->SelectedIndex].teleport_locations[i].teleport_loc_name));
            
         //trigger lstBx_SelectedIndexChanged
         lstbx_locations->SelectedIndex = -1;
         lstbx_locations->SelectedIndex = 0;
      }
   }
   
   void Teleport_Locations::lstbx_locations_SelectedIndexChanged(System::Object^  sender, System::EventArgs^  e)
   {
      if (lstbx_maps->SelectedIndex != -1 && lstbx_locations->SelectedIndex != -1)
      {
         txtbx_loc_name->Text = gcnew System::String((*Locations)[lstbx_maps->SelectedIndex].teleport_locations[lstbx_locations->SelectedIndex].teleport_loc_name);
         txtbx_x_coor->Text = (*Locations)[lstbx_maps->SelectedIndex].teleport_locations[lstbx_locations->SelectedIndex].coordinates[0].ToString();
         txtbx_y_coor->Text = (*Locations)[lstbx_maps->SelectedIndex].teleport_locations[lstbx_locations->SelectedIndex].coordinates[1].ToString();
         txtbx_z_coor->Text = (*Locations)[lstbx_maps->SelectedIndex].teleport_locations[lstbx_locations->SelectedIndex].coordinates[2].ToString();
      }
   }
   
   void Teleport_Locations::btn_add_Click(System::Object^  sender, System::EventArgs^  e)
   {
      if (lstbx_maps->SelectedIndex != -1)
      {
         TELEPORT_LOCATION new_loc = { {L'n',L'e',L'w',L'_',L'l',L'o',L'c',L'\0'}, {0,0,0}};
         (*Locations)[lstbx_maps->SelectedIndex].teleport_locations.push_back(new_loc);
         
         int temp = lstbx_maps->SelectedIndex;
         lstbx_maps->SelectedIndex = -1;
         lstbx_maps->SelectedIndex = temp;
         lstbx_locations->SelectedIndex = (*Locations)[temp].teleport_locations.size() - 1;
         
         txtbx_loc_name->Focus();
         txtbx_loc_name->Select(0, txtbx_loc_name->Text->Length);
         intern_change = true;
      }
   }
   
   void Teleport_Locations::btn_remove_Click(System::Object^  sender, System::EventArgs^  e)
   {
      if (lstbx_maps->SelectedIndex != -1)
      {
         (*Locations)[lstbx_maps->SelectedIndex].teleport_locations.erase((*Locations)[lstbx_maps->SelectedIndex].teleport_locations.begin() + lstbx_locations->SelectedIndex);
         
         
         if (!(*Locations)[lstbx_maps->SelectedIndex].teleport_locations.size())
         {
            Locations->erase(Locations->begin() + lstbx_maps->SelectedIndex);
            lstbx_maps->Items->RemoveAt(lstbx_maps->SelectedIndex);
            lstbx_maps->SelectedIndex = -1;
            lstbx_locations->SelectedIndex = -1;
            if (Locations->size())
            {
               lstbx_maps->SelectedIndex = 0;
               lstbx_locations->SelectedIndex = 0;
            }
         }
         else
         {
            int temp = lstbx_maps->SelectedIndex;
            lstbx_maps->SelectedIndex = -1;
            lstbx_maps->SelectedIndex = temp;
            lstbx_locations->SelectedIndex = (*Locations)[temp].teleport_locations.size() - 1;
         }
         
         intern_change = true;
      }
   }
   
   void Teleport_Locations::btn_set_location_Click(System::Object^  sender, System::EventArgs^  e)
   {
      if (lstbx_maps->SelectedIndex != -1 && lstbx_locations->SelectedIndex != -1)
      {
         for (int i = 0; i < TELE_LOC_NAME_SIZE; i++)
         {
            if (i < txtbx_loc_name->Text->Length)
               if (txtbx_loc_name->Text[i] != L' ')
                  (*Locations)[lstbx_maps->SelectedIndex].teleport_locations[lstbx_locations->SelectedIndex].teleport_loc_name[i] = txtbx_loc_name->Text[i];
               else
                  (*Locations)[lstbx_maps->SelectedIndex].teleport_locations[lstbx_locations->SelectedIndex].teleport_loc_name[i] = L'_';
            else
               (*Locations)[lstbx_maps->SelectedIndex].teleport_locations[lstbx_locations->SelectedIndex].teleport_loc_name[i] = '\0';
         }
         
         float coordinate = 0;
         float::TryParse(txtbx_x_coor->Text, coordinate);
         (*Locations)[lstbx_maps->SelectedIndex].teleport_locations[lstbx_locations->SelectedIndex].coordinates[0] = coordinate;
         
         coordinate = 0;
         float::TryParse(txtbx_y_coor->Text, coordinate);
         (*Locations)[lstbx_maps->SelectedIndex].teleport_locations[lstbx_locations->SelectedIndex].coordinates[1] = coordinate;
         
         coordinate = 0;
         float::TryParse(txtbx_z_coor->Text, coordinate);
         (*Locations)[lstbx_maps->SelectedIndex].teleport_locations[lstbx_locations->SelectedIndex].coordinates[2] = coordinate;
         
         int temp = lstbx_maps->SelectedIndex;
         lstbx_maps->SelectedIndex = -1;
         lstbx_maps->SelectedIndex = temp;
         lstbx_locations->SelectedIndex = (*Locations)[temp].teleport_locations.size() - 1;
         
         intern_change = true;
      }
   }
}
