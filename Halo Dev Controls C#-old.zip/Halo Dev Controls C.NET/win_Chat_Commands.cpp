#include "win_Chat_Commands.h"
//ChangeKey.h includes WindowsInput.h
#include "ChangeKey.h"

namespace RPG_Beta6_2DevControls
{
   win_Chat_Commands::win_Chat_Commands(CMDsLib::COMMANDS *commands, bool *cmd_changed)
   {
      constructing = true;
      Commands = commands;
      
      InitializeComponent();
		
		this->Text = gcnew System::String(commands->cmds_group_name) + L" Commands and Shortcuts     commands work in console, rcon, and chat";
	   cmd_val_changed = cmd_changed;
	   
		this->commands_lstBx->Items->Clear();
      for (int i = 0; i < commands->size; i++)
         commands_lstBx->Items->Add(gcnew System::String(commands->cmd_descripts[i].cmd_name));

      switch (commands->Enable_Shrtcts)
      {
         case 0:
            Enable_shrtcts_chkBx->Checked = false;
            break;
         case 1:
            Enable_shrtcts_chkBx->Checked = true;
            break;
         case -1:
            Enable_shrtcts_chkBx->Checked = false;
            Enable_shrtcts_chkBx->Enabled = false;
            break;
      }
      
      //trigger lstBx_SelectedIndexChanged
      commands_lstBx->SelectedIndex = -1;
      commands_lstBx->SelectedIndex = 0;
      
      constructing = false;
   }
		
   void win_Chat_Commands::Enable_shrtcts_chkBx_CheckedChanged(System::Object^  sender, System::EventArgs^  e)
   {
      //nothings changed when setting up
      if (!constructing)
      {
         *cmd_val_changed = true;
         Commands->Enable_Shrtcts = Enable_shrtcts_chkBx->Checked;
         //trigger lstBx_SelectedIndexChanged
         commands_lstBx->SelectedIndex = -1;
         commands_lstBx->SelectedIndex = 0;
      }
   }
   
   void win_Chat_Commands::okButton_Click(System::Object^  sender, System::EventArgs^  e)
   {
      //if (*cmd_val_changed)
   }
   
   void win_Chat_Commands::commands_lstBx_SelectedIndexChanged(System::Object^  sender, System::EventArgs^  e)
   {
      if (this->commands_lstBx->SelectedIndex != -1)
      {
         activate_txtbx->Text = gcnew System::String(Commands->cmd_strs[commands_lstBx->SelectedIndex]);
         descript_lbl->Text = gcnew System::String(Commands->cmd_descripts[commands_lstBx->SelectedIndex].cmd_descript);
         if (Commands->cmd_keys)
         {
            toggle_onoff_btn->Text = gcnew System::String(Get_Key_Name(Commands->cmd_keys[commands_lstBx->SelectedIndex].toggle_key));
            cmd_on_btn->Text = gcnew System::String(Get_Key_Name(Commands->cmd_keys[commands_lstBx->SelectedIndex].on_key));
            cmd_off_btn->Text = gcnew System::String(Get_Key_Name(Commands->cmd_keys[commands_lstBx->SelectedIndex].off_key));
            
            toggle_onoff_btn->Enabled = Commands->cmd_keys[commands_lstBx->SelectedIndex].toggle_key != -1 && Enable_shrtcts_chkBx->Checked;
            cmd_on_btn->Enabled = Commands->cmd_keys[commands_lstBx->SelectedIndex].on_key != -1 && Enable_shrtcts_chkBx->Checked;
            cmd_off_btn->Enabled = Commands->cmd_keys[commands_lstBx->SelectedIndex].off_key != -1 && Enable_shrtcts_chkBx->Checked;
         }
      }
   }
   
   void win_Chat_Commands::toggle_onoff_btn_Click(System::Object^  sender, System::EventArgs^  e)
   {
      short temp = Commands->cmd_keys[commands_lstBx->SelectedIndex].toggle_key;
      ChangeKey^ f4 = gcnew ChangeKey(&Commands->cmd_keys[commands_lstBx->SelectedIndex].toggle_key);
      f4->ShowDialog();

      while (f4->Visible) ;//pause
      toggle_onoff_btn->Text = Get_Key_Name(Commands->cmd_keys[commands_lstBx->SelectedIndex].toggle_key);

      if (temp != Commands->cmd_keys[commands_lstBx->SelectedIndex].toggle_key)
         *cmd_val_changed = true;
   }
   
   void win_Chat_Commands::cmd_on_btn_Click(System::Object^  sender, System::EventArgs^  e)
   {
      short temp = Commands->cmd_keys[commands_lstBx->SelectedIndex].on_key;
      ChangeKey^ f4 = gcnew ChangeKey(&Commands->cmd_keys[commands_lstBx->SelectedIndex].on_key);
      f4->ShowDialog();

      while (f4->Visible) ;//pause
      cmd_on_btn->Text = Get_Key_Name(Commands->cmd_keys[commands_lstBx->SelectedIndex].on_key);

      if (temp != Commands->cmd_keys[commands_lstBx->SelectedIndex].on_key)
         *cmd_val_changed = true;
   }
   
   void win_Chat_Commands::cmd_off_btn_Click(System::Object^  sender, System::EventArgs^  e)
   {
      short temp = Commands->cmd_keys[commands_lstBx->SelectedIndex].off_key;
      ChangeKey^ f4 = gcnew ChangeKey(&Commands->cmd_keys[commands_lstBx->SelectedIndex].off_key);
      f4->ShowDialog();

      while (f4->Visible) ;//pause
      cmd_off_btn->Text = Get_Key_Name(Commands->cmd_keys[commands_lstBx->SelectedIndex].off_key);

      if (temp != Commands->cmd_keys[commands_lstBx->SelectedIndex].off_key)
         *cmd_val_changed = true;
   }
   
   void win_Chat_Commands::activate_set_btn_Click(System::Object^  sender, System::EventArgs^  e)
   {
      System::String^ str_temp = gcnew System::String(Commands->cmd_strs[commands_lstBx->SelectedIndex]);
      
      if (str_temp != activate_txtbx->Text)
      {
         //convert .NET String to char*
         MarshalString(activate_txtbx->Text, Commands->cmd_strs[commands_lstBx->SelectedIndex], CMD_STR_SIZE);
         *cmd_val_changed = true;
      }
   }
}