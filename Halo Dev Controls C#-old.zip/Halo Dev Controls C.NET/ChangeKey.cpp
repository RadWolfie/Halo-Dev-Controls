/********************************************************************************
	 -- Halo Dev Controls
    Copyright � 2011 Jesus7Freak

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*********************************************************************************
	File:    ChangeKey.cpp
	Project: Halo Dev Controls C.NET
	Author:  Jesus7Freak
	Date:    11/22/2011
	Game:    Halo and Halo Custom Edition
	Version: all
*********************************************************************************/
#include "ChangeKey.h"

namespace RPG_Beta6_2DevControls
{
   ChangeKey::ChangeKey(short *key)
	{
	   InitializeComponent();
		Orig_Key = key;
      this->keycode_txtbx->Text = Orig_Key->ToString();
      this->keycode_lbl->Text = Get_Key_Name(*Orig_Key);
      this->keycode_hex_txtbx->Text = "0x" + Orig_Key->ToString("X");
	}
	
   void ChangeKey::keycode_txtbx_KeyDown(System::Object^  sender, System::Windows::Forms::KeyEventArgs^  e) 
   {
      e->SuppressKeyPress = true;
      keycode_txtbx->Text = e->KeyValue.ToString();
      keycode_hex_txtbx->Text = "0x" + e->KeyValue.ToString("X");
      keycode_lbl->Text = Get_Key_Name(System::Int16::Parse(keycode_txtbx->Text));
   }

   void ChangeKey::none_btn_Click(System::Object^  sender, System::EventArgs^  e)
   {
      keycode_txtbx->Text = "0";
      keycode_hex_txtbx->Text = "0x0";
      keycode_lbl->Text = "none";
   }

   void ChangeKey::ok_btn_Click(System::Object^  sender, System::EventArgs^  e)
   {
      short key = System::Int16::Parse(keycode_txtbx->Text);
      *Orig_Key = key;
      this->Close();
   }
}