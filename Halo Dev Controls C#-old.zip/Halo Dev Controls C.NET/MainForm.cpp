//******1|0*******2|0*******3|0*******4|0*******5|0*******6|0*******7|0*******8|0*****89|
/********************************************************************************
	 -- Halo Dev Controls
    Copyright � 2011 Jesus7Freak

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*********************************************************************************
	File:    MainForm.cpp
	Project: Halo Dev Controls C.NET
	Author:  Jesus7Freak
	Date:    11/22/2011
	Game:    Halo and Halo Custom Edition
	Version: all
*********************************************************************************/
#include "MainForm.h"
#include "win_About.h"
#include "win_Chat_Commands.h"
#include "Teleport_Locations.h"

#define tobool(num) ((num) ? true : false)

using namespace RPG_Beta6_2DevControls;

wchar_t *Debug_Log_Name = L"debug_app_log.txt",
   *Locations_File_Name = L"locations.bin",
   *Settings_File_Name = L"shortcuts.bin",
   *Dll_Name = L"HDC.drv",
   *szHaloCE_exe = L"haloce.exe",
   *szHaloPC_exe = L"halo.exe";

//System::String^ sFileName = gcnew System::String(SettingsFileName);
   //unhide file to make changes
   //if (System::IO::File::Exists(sFileName))
   //   System::IO::File::SetAttributes(
   //       sFileName, 
   //       System::IO::File::GetAttributes(sFileName) 
   //          & ~System::IO::FileAttributes::Hidden
   //       );
   
   //hide file
   //System::IO::File::SetAttributes(
   //   sFileName, 
   //   System::IO::File::GetAttributes(sFileName) 
   //      | System::IO::FileAttributes::Hidden
   //    );
   //delete sFileName;
   
//static var is better than new, new is evil...
HaloCE_lib::DATA_HEADER Device_Groups_Header,
                        HS_Global_Header;
                              
char map_str[MAP_STR_SIZE] = {0};
ULONG_PTR base_address = NULL;
DWORD scan_size = 0;               

MainForm::MainForm(void)
{
   //love you Patr�cia <3
   C_Setting = 0;
   Lock_sec = 0, Halo_sec = 0;
   rpgb6_2_running = false;
   display_txt = true;
   dev_enabled = false,
   console_enabled = false,
   alarm_on = false,
   Locked = false,
   Nuked = false;
           
   Halo_Process = NULL;
   hHDC = NULL;
   dll_injector_failed = false;
   
   main_module_name = L"";
   Current_Map_address = NULL;
   Cheats_address = NULL;
   ServerType_address = NULL;
   Device_Groups_Header_ptr_address = NULL;
   HS_Global_Header_ptr_address = NULL;
   dll_addresses = NULL;
   Dev_enabled_address = NULL;
   Console_enabled_address = NULL;
   ShowHud_address = NULL;
   LetterBox_address = NULL;
   RiderEjection_address = NULL;
   //rapid_fire_hook_address = NULL;
   //time_freeze_hook_address = NULL;
   //grav_boots_hook_address = NULL;
   //vehicle_ntr_hook_address = NULL;
         
   //force update
   running_sv_t = (server_type)3;
   
	InitializeComponent();
	CMDsLib::GetSKeysFromFile(Settings_File_Name);

	std::fstream testfile;
	testfile.open(Dll_Name);
	if (testfile.fail())
	{
	   int dll_name_length = 0; do dll_name_length++; while(Dll_Name[dll_name_length]);
	   wchar_t *caption = new wchar_t[0xB + dll_name_length]();
   	
	   for (int i = 0; i < dll_name_length; i++)
	      caption[i] = Dll_Name[i];
   	
	   caption[dll_name_length + 0] = L' ';
	   caption[dll_name_length + 1] = L'n';
	   caption[dll_name_length + 2] = L'o';
	   caption[dll_name_length + 3] = L't';
	   caption[dll_name_length + 4] = L' ';
	   caption[dll_name_length + 5] = L'f';
	   caption[dll_name_length + 6] = L'o';
	   caption[dll_name_length + 7] = L'u';
	   caption[dll_name_length + 8] = L'n';
	   caption[dll_name_length + 9] = L'd';
	
	   ::MessageBoxW(
         NULL, 
         L"Commands and key-shortcuts will not work\nNeeds to be in the same folder\nas Halo Dev Controls", 
         caption, 
         MB_OK | MB_ICONWARNING | MB_TASKMODAL
         );
         
      delete[] caption;
   }
   else
      testfile.close();
}

MainForm::~MainForm()
{
   if (hHDC)
      Halo_Process->UnloadDLL(hHDC, false);
   
   if (Halo_Process)
      delete Halo_Process;
      
   if (components)
      delete components;
}
      
void MainForm::update_info_timer_Tick(System::Object^  sender, System::EventArgs^  e)
{
   //one thread at a time
   this->update_info_timer->Enabled = false;
   
   if (RWMemory::GetProcessesByNameW(szHaloPC_exe).size())
   {
      running_gt = game_types::Halo;
      main_module_name = szHaloPC_exe;
      status_lbl->Text = "Halo PC";
   }
   else if (RWMemory::GetProcessesByNameW(szHaloCE_exe).size())
   {
      running_gt = game_types::HCE;
      main_module_name = szHaloCE_exe;
      status_lbl->Text = "Halo CE";
   }
   else
   {
      if (Halo_Process)
      {
         running_gt = game_types::not_running;
         rpgb6_2_running = false;
         dev_enabled = false,
         console_enabled = false,
         alarm_on = false,
         Locked = false,
         Nuked = false;
           
         status_lbl->Text = "Halo CE";
         status_lbl2->Text = "Off";
         status_lbl2->ForeColor = System::Drawing::Color::Red;
         
         main_module_name = L"";
         status_lbl4->Text = "";
         status_lbl3->Text = "";
            
         halo_timer_txt->Text = L"seconds";
         BLD_timer_txt->Text = L"seconds";
      
         dll_injector_failed = false;
         base_address = NULL;
         scan_size = 0;
         
         HS_Global_Header_ptr_address = NULL;
         Device_Groups_Header_ptr_address = NULL;
         if (dll_addresses)
         {
            delete dll_addresses;
            dll_addresses = NULL;
         }
            
         Current_Map_address = NULL;
         Cheats_address = NULL;
         ServerType_address = NULL;

         control_enabled_change = true;
         
         Dev_enabled_address = NULL;
         Console_enabled_address = NULL;
         ShowHud_address = NULL;
         LetterBox_address = NULL;
         RiderEjection_address = NULL;
         //rapid_fire_hook_address = NULL;
         //time_freeze_hook_address = NULL;
         //grav_boots_hook_address = NULL;
         //vehicle_ntr_hook_address = NULL;
      
         hHDC = NULL;
         
         //force update
         running_sv_t = server_type::host;
         
         //debug_vars(System::DateTime::Now);
         delete Halo_Process;
         Halo_Process = NULL;
      }
   }
   
   if (running_gt != game_types::not_running)
   {
      
      //if (Static_Players != nullptr)
      //   delete[] Static_Players;
      if (!Halo_Process)
         Halo_Process = new RWMemory(main_module_name);
      
      if (Halo_Process->LastWin32Error == ERROR_ACCESS_DENIED)
      {
         ::MessageBoxW(
            NULL, 
            L"This App needs to be run as administrator", 
            L"Error", 
            MB_OK | MB_ICONWARNING | MB_TASKMODAL
            );
         this->Close();
      }
         
      //if (Players_Table_Header_ptr_address < 10)
         control_enabled_change = true;
         
      status_lbl2->Text = "On";
      status_lbl2->ForeColor = System::Drawing::Color::Green;
      
      
      //inject dll
      if (!hHDC && !dll_injector_failed)
      {
         //give game time to load
         System::Threading::Thread::Sleep(250);
         
         wchar_t *current_directory = NULL; DWORD cd_size = 0;
         cd_size = ::GetCurrentDirectoryW(cd_size, current_directory);

         int dll_name_length = 0; do dll_name_length++; while(Dll_Name[dll_name_length]);
         
         current_directory = new wchar_t[cd_size + 1 + dll_name_length];
         ::GetCurrentDirectoryW(cd_size, current_directory);
         
         //dll releases the memory
         DWORD CurrentDir_address = (DWORD)Halo_Process->AllocateMemory(cd_size);
         Halo_Process->WriteMemArray<wchar_t>((LPVOID)CurrentDir_address, (wchar_t&)*current_directory, cd_size);
            
         current_directory[cd_size - 1] = L'\\';
         
         for (int i = 0; i <= dll_name_length; i++)
            current_directory[cd_size + i] = Dll_Name[i];
         
         hHDC = Halo_Process->InjectDLL(current_directory, false);
         if (!hHDC)
         {
            dll_injector_failed = true;
         }
         else
         {
            Halo_Process->ModuleSectionAddr_Size((HMODULE)hHDC, base_address, scan_size, (BYTE*)".data\0\0", false);
            
            dll_addrs_ptr = Halo_Process->FindMemPattern(
               base_address,
               scan_size,
               (BYTE*)"dll_st_addrs",
               "xxxxxxxxxxxx") + 12;
               
            ::Sleep(10);//give time for dll to load
            dll_addresses = new DLL_ADDRS(Halo_Process->ReadMem<DLL_ADDRS>((LPVOID)dll_addrs_ptr));
            Halo_Process->WriteMem<DWORD>((LPVOID)(dll_addrs_ptr + 0xC), CurrentDir_address);
            
            //copy current settings to dll
            Halo_Process->WriteMemArray<CMDsLib::CMD_SCKEYS>((LPVOID)
               dll_addresses->halo_cmd_keys, 
               (CMDsLib::CMD_SCKEYS&)CMDsLib::halo_cmd_keys, 
               HALO_CMDS_SIZE);
               
            Halo_Process->WriteMemArray<CMDsLib::CMD_SCKEYS>((LPVOID)
               dll_addresses->rpgb62_cmd_keys, 
               (CMDsLib::CMD_SCKEYS&)CMDsLib::rpg_beta6_2_cmd_keys, 
               RPGB_CMDS_SIZE);
               
            int dll_cmd_ske[2] = { CMDsLib::halo_commands.Enable_Shrtcts, CMDsLib::rpgbeta6_2_commands.Enable_Shrtcts };
            Halo_Process->WriteMemArray<int>((LPVOID)
               dll_addresses->cmd_sk_enabled,
               (int&)dll_cmd_ske,
               2);
            
            Halo_Process->WriteMem<WORD>((LPVOID)dll_addresses->game, (WORD)running_gt);
            
            base_address = NULL;//reset for below
         }
         delete[] current_directory;
      }
      
      //find halo module info
      if (!base_address)
         Halo_Process->ModuleSectionAddr_Size(
               Halo_Process->GetProcessModuleByNameW(main_module_name).hModule, 
               base_address, 
               scan_size, 
               (BYTE*)".text\0\0", 
               false);
      
      //find patterns
      if (Device_Groups_Header_ptr_address < 10)
      {
         ULONG_PTR DGHptr_ptr = Halo_Process->FindMemPattern(
                           base_address,
                           scan_size,
                           HaloCE_lib::Device_Groups_ptr_sig);
         
         Device_Groups_Header_ptr_address = Halo_Process->ReadMem<DWORD>((LPVOID)DGHptr_ptr);
      }
      
      if (HS_Global_Header_ptr_address < 10)
      {
         ULONG_PTR HSGptr_ptr = Halo_Process->FindMemPattern(
                                 base_address,
                                 scan_size,
                                 HaloCE_lib::HS_Globals_ptr_sig);
         
         HS_Global_Header_ptr_address = Halo_Process->ReadMem<DWORD>((LPVOID)HSGptr_ptr);
      }
   
      if (Dev_enabled_address < 10 && running_gt == game_types::HCE)
      {
         ULONG_PTR Dev_ptr = Halo_Process->FindMemPattern(
                         base_address,
                         scan_size,
                         HCE_Lib::Dev_addr_sig);
                         
         Dev_enabled_address = Halo_Process->ReadMem<DWORD>((LPVOID)Dev_ptr);
      }
      
      if (Console_enabled_address < 10)
      {
         ULONG_PTR console_ptr = Halo_Process->FindMemPattern(
                             base_address,
                             scan_size,
                             HaloCE_lib::Console_addr_sig);
                             
         Console_enabled_address = Halo_Process->ReadMem<DWORD>((LPVOID)console_ptr) + HaloCE_lib::Console::Enabled_offset;
      }

      if (Current_Map_address < 10)
      {
         ULONG_PTR CMA_ptr = Halo_Process->FindMemPattern(
                         base_address,
                         scan_size,
                         HaloCE_lib::Current_map_addr_sig);
                         
         Current_Map_address = Halo_Process->ReadMem<DWORD>((LPVOID)CMA_ptr);
      }
      
      if (Cheats_address < 10)
      {
         ULONG_PTR mem_region_ptr = Halo_Process->FindMemPattern(
                                base_address,
                                scan_size,
                                HaloCE_lib::Cheats_addr_sig);
                                
         Cheats_address = Halo_Process->ReadMem<DWORD>((LPVOID)mem_region_ptr);
      }
      
      if (ShowHud_address < 10)
      {
         ULONG_PTR SHp_ptr = Halo_Process->FindMemPattern(
                         base_address,
                         scan_size,
                         HaloCE_lib::Show_Hud_ptr_addr_sig);
                         
         ShowHud_address = Halo_Process->ReadMem<DWORD>((LPVOID)Halo_Process->ReadMem<DWORD>((LPVOID)SHp_ptr));
      }

      if (LetterBox_address < 20)
      {
         ULONG_PTR lb_ptr = Halo_Process->FindMemPattern(
                        base_address,
                        scan_size,
                        HaloCE_lib::letterbox_ptr_addr_sig);
                        
         LetterBox_address = Halo_Process->ReadMem<DWORD>((LPVOID)Halo_Process->ReadMem<DWORD>((LPVOID)lb_ptr)) + 8;
      }
      
      if (RiderEjection_address < 10)
      {
         ULONG_PTR re_ptr = Halo_Process->FindMemPattern(
                        base_address,
                        scan_size,
                        HaloCE_lib::Rider_Eject_addr_sig);
                        
         RiderEjection_address = Halo_Process->ReadMem<DWORD>((LPVOID)re_ptr);
      }
      
      /*if (rapid_fire_hook_address < 10)
      {
         rapid_fire_hook_address = (DWORD)Halo_Process->FindMemPattern(
                        base_address,
                        scan_size,
                        HaloCE_lib::Rapid_Fire_addr_sig);
      }*/
      
      /*if (time_freeze_hook_address < 10)
      {
         time_freeze_hook_address = (DWORD)Halo_Process->FindMemPattern(
                        base_address,
                        scan_size,
                        HaloCE_lib::Time_Freeze_addr_sig);
      }*/
      
      /*if (grav_boots_hook_address < 10)
      {
         grav_boots_hook_address = (DWORD)Halo_Process->FindMemPattern(
                        base_address,
                        scan_size,
                        HaloCE_lib::Grav_Boots_addr_sig);
      }*/
      
      /*if (vehicle_ntr_hook_address < 10)
      {
         vehicle_ntr_hook_address = (DWORD)Halo_Process->FindMemPattern(
                        base_address,
                        scan_size,
                        HaloCE_lib::Vehicle_NTR_addr_sig);
      }*/
      
      if (ServerType_address < 10)
      {
         ULONG_PTR svhc_ptr = Halo_Process->FindMemPattern(
                        base_address,
                        scan_size,
                        HaloCE_lib::sv_ban_func_addr_sig);
                        
         ServerType_address = Halo_Process->ReadMem<DWORD>((LPVOID)(svhc_ptr + 3));
      }
      Device_Groups_Header = Halo_Process->ReadMem<HaloCE_lib::DATA_HEADER>(
         (LPVOID)Halo_Process->ReadMem<DWORD>((LPVOID)Device_Groups_Header_ptr_address)); 
      
      HS_Global_Header = Halo_Process->ReadMem<HaloCE_lib::DATA_HEADER>(
         (LPVOID)Halo_Process->ReadMem<DWORD>((LPVOID)HS_Global_Header_ptr_address));
         
      status_lbl3->Text = "Map:";
      for (int i = 0; i < MAP_STR_SIZE; i++)
         map_str[i] = 0;//reset
      
      Halo_Process->ReadMemString((LPVOID)Current_Map_address, map_str);
      status_lbl4->Text = gcnew System::String(map_str);
      
      //update host/client lbl 0 - main menu, 1 - client, 2 - host
      temp = (BYTE)running_sv_t;
      running_sv_t = Halo_Process->ReadMem<server_type>((LPVOID)ServerType_address);
      if ((BYTE)running_sv_t != temp)
      {
         if (running_sv_t == server_type::main_menu)
         {
            //if (str_cmp(map_str, "ui"))
            //{
               rcon_lbl->ForeColor = System::Drawing::Color::Red;
               rcon_lbl->Text = "Main Menu";
            //}
            //else
            //{
            //   rcon_lbl->ForeColor = System::Drawing::SystemColors::Highlight;
            //   rcon_lbl->Text = "Campaign";
            //}
            //debug_vars(System::DateTime::Now);
         }
         else if (running_sv_t == server_type::client)
         {
            rcon_lbl->ForeColor = System::Drawing::Color::Red;
            rcon_lbl->Text = "Client";
            //debug_vars(System::DateTime::Now);
         }
         else if (running_sv_t == server_type::host)
         {
            rcon_lbl->ForeColor = System::Drawing::Color::Green;
            rcon_lbl->Text = "Hosting";
            //debug_vars(System::DateTime::Now);
         }
      }
      
      //update dev btn
      bool btemp = Halo_Process->ReadMem<bool>((LPVOID)Dev_enabled_address);
      if (dev_enabled != btemp)
      {
         dev_enabled = btemp;
         if (dev_enabled)
         {
            btn_dev->Text = "Disable Dev";
            btn_dev->ForeColor = System::Drawing::Color::Green;//Chartreuse;
         }
         else
         {
            btn_dev->Text = "Enable Dev";;
            btn_dev->ForeColor = System::Drawing::Color::Red;
         }
      }
      
      //update console btn
      btemp = Halo_Process->ReadMem<bool>((LPVOID)Console_enabled_address);
      if (console_enabled != btemp)
      {
         console_enabled = btemp;
         if (console_enabled)
         {
            btn_console->Text = "Disable Console";
            btn_console->ForeColor = System::Drawing::Color::Green;//Chartreuse;
         }
         else
         {
            btn_console->Text = "Enable Console";
            btn_console->ForeColor = System::Drawing::Color::Red;
         }
      }
      
      //update deathless value
       if (Deathless_chkBx->Checked != (temp = Halo_Process->ReadMem<bool>((LPVOID)(Cheats_address + HaloCE_lib::CheatsEx::Deathless_offset))))
         Deathless_chkBx->Checked = temp ? true : false;

      //update infinite ammo value
      if (IF_chkBx->Checked != (temp = Halo_Process->ReadMem<bool>((LPVOID)(Cheats_address + HaloCE_lib::CheatsEx::Infinite_Ammo_offset))))
         IF_chkBx->Checked = temp != 0;

      //update show hud value
      if (showhud_chkBx->Checked != (temp = Halo_Process->ReadMem<bool>((LPVOID)ShowHud_address)))
         showhud_chkBx->Checked = !!temp;//same as temp ? true : false;

      //update letter box value
      if (letterbox_chkBx->Checked != (temp = Halo_Process->ReadMem<bool>((LPVOID)LetterBox_address)))
         letterbox_chkBx->Checked = tobool(temp);

      //update rider ejction value
      if (ejection_chkBx->Checked != (temp = Halo_Process->ReadMem<bool>((LPVOID)RiderEjection_address)))
         ejection_chkBx->Checked = tobool(temp);
      
      /*/update rapid fire value 90 or D9
      if (Halo_Process->ReadMem<BYTE>((LPVOID)rapid_fire_hook_address) == 0xD9)
         temp = false;
      else
         temp = true;
         
      if (ckbx_rapid_fire->Checked != tobool(temp))
         ckbx_rapid_fire->Checked = tobool(temp);*/
      
      /*/update time freeze value 75 or 74
      if (Halo_Process->ReadMem<BYTE>((LPVOID)time_freeze_hook_address) == 0x74)
         temp = false;
      else
         temp = true;
         
      if (ckbx_time_freeze->Checked != tobool(temp))
         ckbx_time_freeze->Checked = tobool(temp);*/
      
      /*/update grav boots value
      if (Halo_Process->ReadMem<DWORD>((LPVOID)(grav_boots_hook_address - 7)) == 0x00000242)
         temp = true;
      else
         temp = false;
         
      if (ckbx_grav_boots->Checked != tobool(temp))
         ckbx_grav_boots->Checked = tobool(temp);*/
      
      /*/update vehicle ntr value EB or 74
      if (Halo_Process->ReadMem<BYTE>((LPVOID)vehicle_ntr_hook_address) == 0x74)
         temp = false;
      else
         temp = true;
         
      if (ckbx_vehicle_ntr->Checked != tobool(temp))
         ckbx_vehicle_ntr->Checked = tobool(temp);*/
      
      //test for rpg_beta6_2 map///////////////////////////////////////
      if (str_cmp(map_str, "rpg_beta6_2"))
      {
         //get address for this map
         if (!rpgb6_2_running)
         {
            control_enabled_change = true;
            rpgb6_2_running = true;
            //debug_vars(System::DateTime::Now);
         }
         
         status_lbl4->ForeColor = System::Drawing::Color::Green;
         
         if (halo_timer_txt->Mask != "000")
         {
            BLD_timer_txt->Mask = "000";
            halo_timer_txt->Mask = "000";
         }

         //update alarm button
         bool btemp = Halo_Process->ReadMem<bool>((LPVOID)(HS_Global_Header.ItemArray_ptr + HCE_Lib::rpg_beta6_2_hs_global::alarmed_offset));
         if (alarm_on != btemp)
         {
            alarm_on = btemp;
            if (alarm_on)
            {
               alarm_btn->Text = "Alarm Off";
               alarm_btn->ForeColor = System::Drawing::Color::FromArgb(51,153,255);
            }
            else
            {
               alarm_btn->Text = "Alarm On";
               alarm_btn->ForeColor = System::Drawing::Color::Red;
            }
         }
         
         //update setting
         temp = Halo_Process->ReadMem<BYTE>((LPVOID)(HS_Global_Header.ItemArray_ptr + HCE_Lib::rpg_beta6_2_hs_global::setting_offset));
         if (C_Setting != temp)
         {
            C_Setting = temp;
            if (C_Setting >= 0 && C_Setting <= 2)
               ToD_cb->SelectedIndex = C_Setting;
         }

         //update lockdown timer
         short stemp = Halo_Process->ReadMem<short>((LPVOID)(HS_Global_Header.ItemArray_ptr + HCE_Lib::rpg_beta6_2_hs_global::lock_timer_offset));
         if (Lock_sec != stemp)
         {
            Lock_sec = stemp;
            BLD_timer_txt->Text = (Lock_sec / 30).ToString();
         }
         
         //update lockdown button
         btemp = Halo_Process->ReadMem<bool>((LPVOID)(HS_Global_Header.ItemArray_ptr + HCE_Lib::rpg_beta6_2_hs_global::locked_offset));
         if (Locked != btemp)
         {
            Locked = btemp;
            if (!Locked)
            {
               BLD_activate->ForeColor = System::Drawing::Color::FromArgb(51,153,255);
               BLD_activate->Text = "Activate";
            }
            else
            {
               BLD_activate->ForeColor = System::Drawing::Color::Red;
               BLD_activate->Text = "Locked";
            }
         }
         
         //update fire halo button
         btemp = Halo_Process->ReadMem<bool>((LPVOID)(HS_Global_Header.ItemArray_ptr + HCE_Lib::rpg_beta6_2_hs_global::nuked_offset));
         if (Nuked != btemp)
         {
            Nuked = btemp;
            if (!Nuked)
            {
               halo_activate->ForeColor = System::Drawing::Color::FromArgb(51,153,255);
               halo_activate->Text = "Fire";
            }
            else
            {
               halo_activate->ForeColor = System::Drawing::Color::Red;
               halo_activate->Text = "Cool Down";
            }
         }
         
         //update halo timer
         stemp = Halo_Process->ReadMem<short>((LPVOID)(HS_Global_Header.ItemArray_ptr + HCE_Lib::rpg_beta6_2_hs_global::boom_timer_offset));
         if (Halo_sec != stemp)
         {
            Halo_sec = stemp;
            halo_timer_txt->Text = (Halo_sec / 30).ToString();
         }
      }
      else
      {
         rpgb6_2_running = false;
         status_lbl4->ForeColor = System::Drawing::Color::Red;
      }
   }
   
   if (control_enabled_change)
   {
      btn_dev->Enabled = running_gt == game_types::HCE;
      btn_dev->Visible = running_gt != game_types::Halo;
      btn_console->Enabled = running_gt == game_types::Halo;
      btn_console->Visible = running_gt == game_types::Halo;
      showhud_chkBx->Enabled = running_gt != game_types::not_running;
      letterbox_chkBx->Enabled = running_gt != game_types::not_running;
      rcon_lbl->Enabled = running_gt != game_types::not_running;
      ejection_chkBx->Enabled = running_sv_t != server_type::client && running_gt != game_types::not_running;
      Deathless_chkBx->Enabled = running_sv_t != server_type::client && running_gt != game_types::not_running;
      IF_chkBx->Enabled = running_sv_t != server_type::client && running_gt != game_types::not_running;

      //ckbx_rapid_fire->Enabled = running_gt != game_types::not_running;
      //ckbx_time_freeze->Enabled = running_gt != game_types::not_running;
      //ckbx_grav_boots->Enabled = running_gt != game_types::not_running;
      //ckbx_vehicle_ntr->Enabled = running_gt != game_types::not_running;
      
      //rpg_beta6_2 functions
      ToD_cb->Enabled = running_sv_t == server_type::host && rpgb6_2_running;
      alarm_btn->Enabled = running_sv_t == server_type::host && rpgb6_2_running;
      BLD_lbl->Enabled = running_sv_t == server_type::host && rpgb6_2_running;
      BLD_timer_txt->Enabled = running_sv_t == server_type::host && rpgb6_2_running;
      BLD_activate->Enabled = running_sv_t == server_type::host && rpgb6_2_running;
      halo_lbl->Enabled = running_sv_t == server_type::host && rpgb6_2_running;
      halo_timer_txt->Enabled = running_sv_t == server_type::host && rpgb6_2_running;
      halo_activate->Enabled = running_sv_t == server_type::host && rpgb6_2_running;

      BLD_set_t->Enabled = running_sv_t == server_type::host && rpgb6_2_running;
      halo_set_t->Enabled = running_sv_t == server_type::host && rpgb6_2_running;
         
      control_enabled_change = false;
   }
   
   this->update_info_timer->Enabled = true;
}


void MainForm::dev_btn_Click(System::Object^  sender, System::EventArgs^  e)
{  
   bool Dev_enabled = Halo_Process->ReadMem<bool>((LPVOID)Dev_enabled_address);
   
   if (!Dev_enabled)
      //enable console
      Halo_Process->WriteMem<bool>((LPVOID)Console_enabled_address, true);

   Halo_Process->WriteMem<bool>((LPVOID)Dev_enabled_address, !Dev_enabled);
}

void MainForm::btn_console_Click(System::Object^  sender, System::EventArgs^  e)
{
   Halo_Process->WriteMem<bool>((LPVOID)Console_enabled_address, !Halo_Process->ReadMem<bool>((LPVOID)Console_enabled_address));
}

void MainForm::Deathless_chkBx_CheckedChanged(System::Object^  sender, System::EventArgs^  e)
{
   Halo_Process->WriteMem<bool>((LPVOID)(Cheats_address + HaloCE_lib::CheatsEx::Deathless_offset), Deathless_chkBx->Checked);
}

void MainForm::IF_chkBx_CheckedChanged(System::Object^  sender, System::EventArgs^  e)
{
   Halo_Process->WriteMem<bool>((LPVOID)(Cheats_address + HaloCE_lib::CheatsEx::Infinite_Ammo_offset), IF_chkBx->Checked);
}

void MainForm::showhud_chkBx_CheckedChanged(System::Object^  sender, System::EventArgs^  e)
{
   Halo_Process->WriteMem<bool>((LPVOID)ShowHud_address, showhud_chkBx->Checked);
}

void MainForm::letterbox_chkBx_CheckedChanged(System::Object^  sender, System::EventArgs^  e)
{
   Halo_Process->WriteMem<bool>((LPVOID)LetterBox_address, letterbox_chkBx->Checked);
}

void MainForm::ejection_chkBx_CheckedChanged(System::Object^  sender, System::EventArgs^  e)
{
   Halo_Process->WriteMem<bool>((LPVOID)RiderEjection_address, ejection_chkBx->Checked);
}

/*void MainForm::ckbx_rapid_fire_CheckedChanged(System::Object^  sender, System::EventArgs^  e)
{
   if (ckbx_rapid_fire->Checked)
   {            
      DWORD number = 0xD9909090;
      Halo_Process->WriteMem<DWORD>((LPVOID)rapid_fire_hook_address, number);
   }
   else
   {
      DWORD number = 0xD91047D9;
      Halo_Process->WriteMem<DWORD>((LPVOID)rapid_fire_hook_address, number);
   }
}*/

/*void MainForm::ckbx_time_freeze_CheckedChanged(System::Object^  sender, System::EventArgs^  e)
{
   short number = 0x2A74;
   if (ckbx_time_freeze->Checked)
      number = 0x3975;

   Halo_Process->WriteMem<short>((LPVOID)time_freeze_hook_address, number);
}*/

/*void MainForm::ckbx_grav_boots_CheckedChanged(System::Object^  sender, System::EventArgs^  e)
{
   //on find this -> 0x00560E70: eax,[eax+000002F4]
   //mov [eax+000002F4],00000242
   //jmp 00560E76
   
   //off
   //mov [eax+000002F4],00000202
   //jmp 00560E76
   DWORD number_address = grav_boots_hook_address - 7;
   DWORD jmp_to_address = grav_boots_hook_address - 0xD;
   
   if (Halo_Process->ReadMem<BYTE>((LPVOID)(grav_boots_hook_address - 3)) != 0xEB)
   {
      BYTE grav_boots_code[19] = 
      {  
         //mov [eax+000002F4],00000202
         0xC7, 0x80, 0xF4, 0x02, 0x00, 0x00, 0x02, 0x02, 0x00, 0x00,
         //jmp 
         0xEB, 0x07,
         //int3
         0xCC,
         //jmp to code cave
         0xEB, 0xF1,
         //nop the rest
         0x90, 0x90, 0x90, 0x90
      };
      
      Halo_Process->WriteMemArray<BYTE>((LPVOID)jmp_to_address, (BYTE&)grav_boots_code, 19);
   }
   
   DWORD number = 0x202;
   if (ckbx_grav_boots->Checked)
      number = 0x242;
      
   Halo_Process->WriteMem<DWORD>((LPVOID)number_address, number); 
}*/

/*void MainForm::ckbx_vehicle_ntr_CheckedChanged(System::Object^  sender, System::EventArgs^  e)
{
   BYTE number = 0x74;
   if (ckbx_vehicle_ntr->Checked)
      number = 0xEB;

   Halo_Process->WriteMem<BYTE>((LPVOID)vehicle_ntr_hook_address, number);
}*/

void MainForm::ToD_cb_SelectedIndexChanged(System::Object^  sender, System::EventArgs^  e)
{
   Halo_Process->WriteMem<BYTE>((LPVOID)(HS_Global_Header.ItemArray_ptr + HCE_Lib::rpg_beta6_2_hs_global::setting_offset), (BYTE)ToD_cb->SelectedIndex);
}

void MainForm::alarm_btn_Click(System::Object^  sender, System::EventArgs^  e)
{
   Halo_Process->WriteMem<bool>((LPVOID)(Device_Groups_Header.ItemArray_ptr 
      + HCE_Lib::rpg_beta6_2_device_groups::alarm_control_2_offset), true);
}

void MainForm::BLD_set_t_Click(System::Object^  sender, System::EventArgs^  e)
{
   short seconds = 0;
   if (short::TryParse(BLD_timer_txt->Text, seconds))
      Halo_Process->WriteMem<short>((LPVOID)(HS_Global_Header.ItemArray_ptr + HCE_Lib::rpg_beta6_2_hs_global::lock_timer_offset), seconds * 30);
}

void MainForm::BLD_activate_Click(System::Object^  sender, System::EventArgs^  e)
{
   if (!Halo_Process->ReadMem<bool>((LPVOID)(HS_Global_Header.ItemArray_ptr + HCE_Lib::rpg_beta6_2_hs_global::locked_offset)))
      Halo_Process->WriteMem<BYTE>((LPVOID)(Device_Groups_Header.ItemArray_ptr
         + HCE_Lib::rpg_beta6_2_device_groups::lock_control_offset), 1);
   else
   {
      //Halo_Process->WriteMemBool(HCE_Lib.Locked, false);
   }
}

void MainForm::halo_set_t_Click(System::Object^  sender, System::EventArgs^  e)
{
   short seconds = 0;
   if (short::TryParse(halo_timer_txt->Text, seconds))
      Halo_Process->WriteMem<short>((LPVOID)(HS_Global_Header.ItemArray_ptr + HCE_Lib::rpg_beta6_2_hs_global::boom_timer_offset), seconds * 30);
}

void MainForm::halo_activate_Click(System::Object^  sender, System::EventArgs^  e)
{
   if (!Halo_Process->ReadMem<bool>((LPVOID)(HS_Global_Header.ItemArray_ptr + HCE_Lib::rpg_beta6_2_hs_global::nuked_offset)))
      Halo_Process->WriteMem<BYTE>((LPVOID)(Device_Groups_Header.ItemArray_ptr 
         + HCE_Lib::rpg_beta6_2_device_groups::boom_control_offset), 1);
   else
   {
      
   }
}

/*void MainForm::debug_vars(System::DateTime time)
{
   DWORD last_error = ::GetLastError();
   
   std::fstream File;
   File.open(Debug_Log_Name, std::ios::out | std::ios::app);
   //save settings changes to file
   File << "time stamp: " << time.Hour << "h:" << time.Minute << "m:" << time.Second << "s:" << time.Millisecond << "ms\n";
   
   File << "\nHalo_Process " << std::hex << Halo_Process;
   if (Halo_Process)
      File << "->Handle: " << Halo_Process->GetProcessHandle();
      
   File << "\nhHDC " << hHDC << '\n';
   File << "dll_addresses " << dll_addresses << '\n';
   if (dll_addresses)
   {
      File << "   ->halo_cmd_keys " << dll_addresses->halo_cmd_keys << '\n';
      File << "   ->rpgb62_cmd_keys " << dll_addresses->rpgb62_cmd_keys << '\n';
      File << "   ->cmd_sk_enabled " << dll_addresses->cmd_sk_enabled << "\n\n";
   }
   
   File << "Device_Groups_Header " << Device_Groups_Header << '\n';
   if (Device_Groups_Header)
   {
      File << "   ->TName " << Device_Groups_Header.TName << '\n';   
      File << "   ->MaxItems " << Device_Groups_Header.MaxItems << '\n';
      File << "   ->ItemSize " << Device_Groups_Header.ItemSize << '\n';
      File << "   ->Unknown " << Device_Groups_Header.Unknown << '\n';
      File << "   ->Data ";
      for (int i = 0; i < 4; i++)
         File << Device_Groups_Header.Data[i];
         
      File << "\n   ->InMainMenu " << Device_Groups_Header.InMainMenu << '\n';
      File << "   ->NumOfItems " << Device_Groups_Header.NumOfItems << '\n';
      File << "   ->NextItemIndex " << Device_Groups_Header.NextItemIndex << '\n';
      File << "   ->NextItemID " << Device_Groups_Header.NextItemID << '\n';
      File << "   ->ItemArray_ptr " << Device_Groups_Header.ItemArray_ptr << "\n\n";
   }
   
   File << "HS_Global_Header " << HS_Global_Header << '\n';
   if (Device_Groups_Header)
   {
      File << "   ->TName " << HS_Global_Header.TName << '\n';
      File << "   ->MaxItems " << HS_Global_Header.MaxItems << '\n';
      File << "   ->ItemSize " << HS_Global_Header.ItemSize << '\n';
      File << "   ->Unknown " << HS_Global_Header.Unknown << '\n';
      File << "   ->Data ";
      for (int i = 0; i < 4; i++)
         File << HS_Global_Header.Data[i];
         
      File << "\n   ->InMainMenu " << HS_Global_Header.InMainMenu << '\n';
      File << "   ->NumOfItems " << HS_Global_Header.NumOfItems << '\n';
      File << "   ->NextItemIndex " << HS_Global_Header.NextItemIndex << '\n';
      File << "   ->NextItemID " << HS_Global_Header.NextItemID << '\n';
      File << "   ->ItemArray_ptr " << HS_Global_Header.ItemArray_ptr << "\n\n";
   }
   
   File << "running_gt " << (WORD)running_gt << '\n';
   File << "running_sv_t " << (WORD)running_sv_t << '\n';
   
   File << "\nC_Setting " << (WORD)C_Setting << '\n';
   File << "temp " << (WORD)temp << '\n';
   
   File << "\nLock_sec " << Lock_sec << '\n';
   File << "Halo_sec " << Halo_sec << '\n';
   
   File << "\ncontrol_enabled_change " << control_enabled_change << '\n';
   File << "rpgb6_2_running " << rpgb6_2_running << '\n';
   File << "display_txt " << display_txt << '\n';
   File << "dll_injector_failed " << dll_injector_failed << '\n';
   
   File << "\nmain_module_name " << main_module_name << ": ";
   if (main_module_name)
      for (int i = 0; main_module_name[i] && i < 10; i++)
         File << (char)main_module_name[i];
         
   File << "\nCurrent_Map_address " << Current_Map_address << '\n';
   File << "Cheats_address " << Cheats_address << '\n';
   File << "ServerType_address " << ServerType_address << '\n';
   File << "Device_Groups_Header_ptr_address " << Device_Groups_Header_ptr_address << '\n';
   File << "HS_Global_Header_ptr_address " << HS_Global_Header_ptr_address << '\n';
   File << "dll_addrs_ptr " << dll_addrs_ptr << '\n';
   
   File << "\nmap_str " << map_str << '\n';
   File << "base_address " << base_address << '\n';
   File << "scan_size " << scan_size << '\n';
   
   File << "\nhalo_cmd_data[0].cmd_address " << halo_cmd_data[0].cmd_address << '\n';
   File << "halo_cmd_data[1].cmd_address " << halo_cmd_data[1].cmd_address << '\n';
   File << "(Cheats_address + HaloCE_lib::CheatsEx::Deathless_offset) " << (Cheats_address + HaloCE_lib::CheatsEx::Deathless_offset) << '\n';
   File << "(Cheats_address + HaloCE_lib::CheatsEx::Infinite_Ammo_offset) " << (Cheats_address + HaloCE_lib::CheatsEx::Infinite_Ammo_offset) << '\n';
   File << "halo_cmd_data[5].cmd_address " << halo_cmd_data[5].cmd_address << '\n';
   File << "halo_cmd_data[6].cmd_address " << halo_cmd_data[6].cmd_address << '\n';
   File << "halo_cmd_data[7].cmd_address " << halo_cmd_data[7].cmd_address << '\n';
   File << "rapid_fire_hook_address " << rapid_fire_hook_address << '\n';
   File << "time_freeze_hook_address " << time_freeze_hook_address << '\n';
   File << "grav_boots_hook_address " << grav_boots_hook_address << '\n';
   File << "vehicle_ntr_hook_address " << vehicle_ntr_hook_address << '\n';
   
   File << "\nrpg_beta6_2_cmd_data[0].cmd_address " << (HS_Global_Header.ItemArray_ptr+ HCE_Lib::rpg_beta6_2_hs_global::setting_offset) << '\n';
   File << "(HS_Global_Header.ItemArray_ptr + HCE_Lib::rpg_beta6_2_hs_global::alarmed_offset) " << (HS_Global_Header.ItemArray_ptr + HCE_Lib::rpg_beta6_2_hs_global::alarmed_offset) << '\n';
   File << "(HS_Global_Header.ItemArray_ptr + HCE_Lib::rpg_beta6_2_hs_global::locked_offset) " << (HS_Global_Header.ItemArray_ptr + HCE_Lib::rpg_beta6_2_hs_global::locked_offset) << '\n';
   File << "(HS_Global_Header.ItemArray_ptr + HCE_Lib::rpg_beta6_2_hs_global::nuked_offset) " << (HS_Global_Header.ItemArray_ptr + HCE_Lib::rpg_beta6_2_hs_global::nuked_offset) << '\n';
   File << "(HS_Global_Header.ItemArray_ptr + HCE_Lib::rpg_beta6_2_hs_global::lock_timer_offset) " << (HS_Global_Header.ItemArray_ptr + HCE_Lib::rpg_beta6_2_hs_global::lock_timer_offset) << '\n';
   File << "(HS_Global_Header.ItemArray_ptr + HCE_Lib::rpg_beta6_2_hs_global::boom_timer_offset) " << (HS_Global_Header.ItemArray_ptr + HCE_Lib::rpg_beta6_2_hs_global::boom_timer_offset) << '\n';
   
   File << "\n::GetLastError() " << last_error << '\n';
   File << "\n\n\n";
   
   File.close();
}*/

void MainForm::Help_halo_commands_Click(System::Object^  sender, System::EventArgs^  e)
{
   bool commands_changed = false;
   win_Chat_Commands^ f3 = gcnew win_Chat_Commands(&CMDsLib::halo_commands, &commands_changed);
   f3->lbl_2nd_descript->Text = "";
   f3->ShowDialog();
   
   if (commands_changed)
   {
      if (hHDC)
      {
         //update keys in dll too
         Halo_Process->WriteMemArray<CMDsLib::CMD_SCKEYS>((LPVOID)
            dll_addresses->halo_cmd_keys, 
            (CMDsLib::CMD_SCKEYS&)CMDsLib::halo_cmd_keys, 
            HALO_CMDS_SIZE);
         
         int dll_cmd_ske[2] = { CMDsLib::halo_commands.Enable_Shrtcts, CMDsLib::rpgbeta6_2_commands.Enable_Shrtcts };
         Halo_Process->WriteMemArray<int>((LPVOID)
            dll_addresses->cmd_sk_enabled, (int&)dll_cmd_ske, 2);
      }
      CMDsLib::WriteSKeysToFile(Settings_File_Name);
   }
}

void MainForm::Help_rpgbeta6_2_commands_Click(System::Object^  sender, System::EventArgs^  e)
{
   bool commands_changed = false;
   win_Chat_Commands^ f3 = gcnew win_Chat_Commands(&CMDsLib::rpgbeta6_2_commands, &commands_changed);
   f3->lbl_2nd_descript->Text = "";
   f3->ShowDialog();
   
   if (commands_changed)
   {  
      if (hHDC)
      {
         //update keys in dll too
         Halo_Process->WriteMemArray<CMDsLib::CMD_SCKEYS>((LPVOID)
            dll_addresses->rpgb62_cmd_keys, 
            (CMDsLib::CMD_SCKEYS&)CMDsLib::rpg_beta6_2_cmd_keys, 
            RPGB_CMDS_SIZE);
         
         int dll_cmd_ske[2] = { CMDsLib::halo_commands.Enable_Shrtcts, CMDsLib::rpgbeta6_2_commands.Enable_Shrtcts };
         Halo_Process->WriteMemArray<int>((LPVOID)
            dll_addresses->cmd_sk_enabled, (int&)dll_cmd_ske, 2);
      }
      CMDsLib::WriteSKeysToFile(Settings_File_Name);
   }
}

void MainForm::playerCommandsToolStripMenuItem_Click(System::Object^  sender, System::EventArgs^  e)
{
   bool commands_changed = false;
   win_Chat_Commands^ f3 = gcnew win_Chat_Commands(&CMDsLib::player_commands, &commands_changed);
   //f3->lbl_2nd_descript->Text = "p0 to p15  p* for all players"
   f3->lbl_2nd_descript->Text = "[pExpression] based on devicator";
   f3->ShowDialog();
   
   //if (commands_changed)
   //   WriteSKeysToFile(Settings_File_Name);
}

void MainForm::teleportLocationsToolStripMenuItem_Click(System::Object^  sender, System::EventArgs^  e)
{
   bool locations_changed = false;
   std::vector<MAPS> maps_tele_sites;
   GetLocationsFromFile(Locations_File_Name, &maps_tele_sites);
   
   Teleport_Locations^ f4 = gcnew Teleport_Locations(&maps_tele_sites, &locations_changed);
   f4->ShowDialog();
   
   if (locations_changed)
   {
      WriteLocationsToFile(Locations_File_Name, &maps_tele_sites);
      if (hHDC)
         Halo_Process->WriteMem<bool>((LPVOID)(dll_addrs_ptr + sizeof(DLL_ADDRS)), true);
   }
}

void MainForm::Help_about_Click(System::Object^  sender, System::EventArgs^  e)
{
   win_About^ f2 = gcnew win_About();
   f2->ShowDialog();
}