/********************************************************************************
	 -- Halo Dev Controls
    Copyright � 2011 Jesus7Freak

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*********************************************************************************
	File:    RPG_Beta6_2 Dev Controls.cpp
	Project: Halo Dev Controls C.NET
	Author:  Jesus7Freak
	Date:    11/22/2011
	Game:    Halo and Halo Custom Edition
	Version: all
*********************************************************************************/
#include "MainForm.h"

using namespace RPG_Beta6_2DevControls;

[System::STAThreadAttribute]
int main(array<System::String ^> ^args)
{
	// Enabling Windows XP visual effects before any controls are created
	System::Windows::Forms::Application::EnableVisualStyles();
	System::Windows::Forms::Application::SetCompatibleTextRenderingDefault(false); 
   
   //only run 1 instance
   bool FirstInstance;
   System::Threading::Mutex^ objMutex = gcnew System::Threading::Mutex(false, L"Local\\Halo Dev Controls.NET", FirstInstance);
   
      if (!FirstInstance)
         System::Windows::Forms::Application::Exit();
      else
         // Create the main window and run it
	      System::Windows::Forms::Application::Run(gcnew MainForm());
	
	return 0;
}