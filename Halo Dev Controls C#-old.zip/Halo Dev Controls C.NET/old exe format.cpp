//******1|0*******2|0*******3|0*******4|0*******5|0*******6|0*******7|0*******8|0*****89|
/********************************************************************************
	 -- Halo Dev Controls
    Copyright � 2011 Jesus7Freak

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*********************************************************************************
	File:    old exe format.cpp
	Project: Halo Dev Controls C.NET
	Author:  Jesus7Freak
	Date:    11/22/2011
	Game:    Halo and Halo Custom Edition
	Version: all
*********************************************************************************/
#include "MainForm.h"
#include "win_About.h"
#include "win_Chat_Commands.h"
#include "Teleport_Locations.h"
#include <fstream>

#define tobool(num) ((num) ? true : false)

using namespace RPG_Beta6_2DevControls;

static CMD_DESCRIPT halo_cmd_descripts[HALO_CMDS_SIZE] =
{
   {"Console", "Enable Console"},//0
   {"Dev Mode", "Enable Developers Mode"},//1
   {"Deathless", "cheat_deathless_player 1"},//2
   {"Infinite Ammo", "cheat_infinite_ammo 1"},//3
   {"Bottomless Clip", "cheat_bottomless_clip 1"},//4
   {"Show Hud", "show_hud 0"},//5
   {"LetterBox", "cinematic_show_letterbox 1"},//6
   {"Rider Ejection", "rider_ejection"},//7
   {"Omnipotent", "cheat_omnipotent 1"},//8
   {"JetPack", "cheat_jetpack 1 (no fall damage)"},//9
   {"Bump Possession", "cheat_bump_possession 1"},//10
   {"Super Jump", "cheat_super_jump 1"},//11
   {"Reflexive Damage", "cheat_reflexive_damage_effects 1"},//12
   {"Medusa", "cheat_medusa 1"},//13
   {"Xbox Controller", "cheat_controller 1 /enables Xbox controller to change cheats ingame"},//14
   {"WireFrame", "rasterizer_wireframe 1"},//15
   {"Fog", "rasterizer_fog_atmosphere 1"},//16
   {"FogPlane", "rasterizer_fog_plane 1"},//17
   {"FPS", "rasterizer_fps 1"},//18
   {"Game Speed", "game_speed # only works in single player"}//19
};
static CMD_DATA halo_cmd_data[HALO_CMDS_SIZE] =
{
   { NULL, false, false },//0
   { NULL, true, false },//1
   { NULL, false, true },//2
   { NULL, false, true },//3
   { NULL, false, false },//4
   { NULL, false, false },//5
   { NULL, false, false },//6
   { NULL, false, true },//7
   { NULL, false, true },//8
   { NULL, false, true },//9
   { NULL, false, true },//10
   { NULL, false, false },//11
   { NULL, false, true },//12
   { NULL, false, true },//13
   { NULL, false, false },//14
   { NULL, false, false },//15
   { NULL, false, false },//16
   { NULL, false, false },//17
   { NULL, false, false },//18
   { NULL, false, true }//19
};
static CMD_STRS halo_cmd_strs[HALO_CMDS_SIZE] =
{
   {"", "/console 1;", "/console 0;"},//0
   {"", "/dev 1;", "/dev 0;"},//1
   {"", "/deathless 1;", "/deathless 0;"},//2
   {"", "/infammo 1;", "/infammo 0;"},//3
   {"", "/bottomless 1;", "/bottomless 0;"},//4
   {"", "/hud 1", "/hud 0"},//5
   {"", "/letterbox 1;", "/letterbox 0;"},//6
   {"", "/ejection 1;", "/ejection 0;"},//7
   {"", "/one shot 1;", "/one shot 0;"},//8
   {"", "/no fall damage 1;", "/no fall damage 0;"},//9
   {"", "/possess 1;", "/possess 0;"},//10
   {"", "/super jump 1;", "/super jump 0;"},//11
   {"", "/reflex damage 1;", "/reflex damage 0;",},//12
   {"", "/medusa 1;", "/medusa 0;"},//13
   {"", "/controller 1;", "/controller 0;"},//14
   {"", "/wireframe 1;", "/wireframe 0;"},//15
   {"", "/fog 1;", "/fog 0;"},//16
   {"", "/fogplane 1;", "/fogplane 0;"},//17
   {"", "/fps 1;", "/fps 0;"},//18
   {"/game_speed #;", "", ""}//19
};
//data that can be written to file
static CMD_SCKEYS halo_cmd_keys[HALO_CMDS_SIZE] = 
{
   {0, 0, 0},//0
   {0, 33, 34},//1
   {97, 0, 0},//2
   {98, 0, 0},//3
   {0, 0, 0},//4
   {99, 0, 0},//5
   {100, 0, 0},//6
   {101, 0, 0},//7
   {0, 0, 0},//8
   {0, 0, 0},//9
   {0, 0, 0},//10
   {0, 0, 0},//11
   {0, 0, 0},//12
   {0, 0, 0},//13
   {0, 0, 0},//14
   {0, 0, 0},//15
   {0, 0, 0},//16
   {0, 0, 0},//17
   {0, 0, 0},//18
   {-1, -1, -1}//19
};


static CMD_DESCRIPT rpg_beta6_2_cmd_descripts[RPGB_CMDS_SIZE] =
{
   {"Setting", "set setting 1"},//0
   {"Air Base Alarm", "device_set_position alarm_control_1 1"},//1
   {"Air Base LockDown", "device_set_position lock_control 1 "},//2
   {"Fire Halo", "device_set_position boom_control 1"},//3
   {"LockDown Timer", "set lock_timer #"},//4
   {"Fire Halo Timer", "set boom_timer #"}//5
};
static CMD_DATA rpg_beta6_2_cmd_data[RPGB_CMDS_SIZE] =
{
   { NULL, true, true },//0
   { NULL, true, true },//1
   { NULL, true, true },//2
   { NULL, true, true },//3
   { NULL, true, true },//4
   { NULL, true, true }//5
};
static CMD_STRS rpg_beta6_2_cmd_strs[RPGB_CMDS_SIZE] =
{
   {"/day;", "/rain;", "/night;"},//0
   {"", "/alarm 1;", "/alarm 0;"},//1
   {"/start lockdown;", "", ""},//2
   {"/fire halo;", "", ""},//3
   {"/lockdown timer #;", "", ""},//4
   {"/halo timer #;", "", ""}//5
};
static CMD_SCKEYS rpg_beta6_2_cmd_keys[RPGB_CMDS_SIZE] =
{
   {102, 0, 0},//0
   {103, 0, 0},//1
   {104, 0, 0},//2
   {105, 0, 0},//3
   {-1, -1, -1},//4
   {-1, -1, -1}//5
};

static CMD_DESCRIPT player_cmd_descripts[PLAYER_CMDS_SIZE] =
{
   {"Speed", "adjust players speed, 0 to 999"},//0
   {"ActiveCamo", "give player active camo"},//1
   {"Suspend", "suspends player"},//2
   {"Teleport", "teleport player to coordinates or to location"},//3
   {"Player Teleport", "teleports player to another player"},//4
   {"Jump Teleport", "teleport player to current coordinates with offset"},//5
   {"Velocity", "changes the players velocity"},//6
   {"Ammo", "adjusts player ammo, # of rounds"},//7
   {"Battery", "adjusts player battery"},//8
   {"Health", "adjusts player health, amount of health"},//9
   {"Shield", "adjusts player shields, amount of shields"},//10
   {"AFK", "player doesn't respawn in afk mode"},//11
   {"Team Change", "changes player to other team"},//12
   {"Kick", "kicks player from server"},//13
   {"Ban", "bans player from server"},//14
   {"Kill", "kills a player"}//15
};
static CMD_DATA player_cmd_data[PLAYER_CMDS_SIZE] =
{
   { NULL, false, true },//0
   { NULL, false, false },//1
   { NULL, false, false },//2
   { NULL, false, true },//3
   { NULL, false, true },//4
   { NULL, false, true },//5
   { NULL, false, true },//6
   { NULL, false, true },//7
   { NULL, false, true },//8
   { NULL, false, true },//9
   { NULL, false, true },//10
   { NULL, false, true },//11
   { NULL, false, true },//12
   { NULL, false, true },//13
   { NULL, false, true },//14
   { NULL, false, true }//15
};
static CMD_STRS player_cmd_strs[PLAYER_CMDS_SIZE] =
{
   {"/spd [pExpression] #;", "", ""},//0
   {"", "/camo [pExpression] 1;", "/camo [pExpression] 0;"},//1
   {"", "/suspend [pExpression] 1;", "/suspend [pExpression] 0;"},//2
   {"/t [pExpression] x y z;", "or  /t [pExpression] [locname];", ""},//3
   {"/tp [pExpression] [pExpression];", "", ""},//4
   {"/j [pExpression] x y z;","", ""},//5
   {"/v [pExpression] x y z;", "", ""},//6
   {"/ammo [pExpression] #;", "", ""},//7
   {"/bat [pExpression] #;", "", ""},//8
   {"/health [pExpression] #;", "", ""},//9
   {"/shield [pExpression] #;", "", ""},//10
   {"", "/afk [pExpression] 1;", "/afk [pExpression] 0;"},//11
   {"/team [pExpression];", "", ""},//12
   {"/k [pExpression];", "", ""},//13
   {"/b [pExpression];", "", ""},//14
   {"/kill [pExpression];", "", ""}//15
};
static CMD_SCKEYS player_cmd_keys[PLAYER_CMDS_SIZE] =
{
   {-1, -1, -1},//0
   {-1, -1, -1},//1
   {-1, -1, -1},//2
   {-1, -1, -1},//3
   {-1, -1, -1},//4
   {-1, -1, -1},//5
   {-1, -1, -1},//6
   {-1, -1, -1},//7
   {-1, -1, -1},//8
   {-1, -1, -1},//9
   {-1, -1, -1},//10
   {-1, -1, -1},//11
   {-1, -1, -1},//12
   {-1, -1, -1},//13
   {-1, -1, -1},//14
   {-1, -1, -1}//15
};

static COMMANDS halo_commands =
{  
   "Halo CE", HALO_CMDS_SIZE, 0,
   reinterpret_cast<CMD_DESCRIPT*>(&halo_cmd_descripts),
   reinterpret_cast<CMD_DATA*>(&halo_cmd_data),
   reinterpret_cast<CMD_STRS*>(&halo_cmd_strs),
   reinterpret_cast<CMD_SCKEYS*>(&halo_cmd_keys)
};

static COMMANDS rpgbeta6_2_commands =
{
   "RPG_Beta6_2", RPGB_CMDS_SIZE, 0,
   reinterpret_cast<CMD_DESCRIPT*>(&rpg_beta6_2_cmd_descripts),
   reinterpret_cast<CMD_DATA*>(&rpg_beta6_2_cmd_data), 
   reinterpret_cast<CMD_STRS*>(&rpg_beta6_2_cmd_strs), 
   reinterpret_cast<CMD_SCKEYS*>(&rpg_beta6_2_cmd_keys)
};

static COMMANDS player_commands =
{
   "Player", PLAYER_CMDS_SIZE, -1,
   reinterpret_cast<CMD_DESCRIPT*>(&player_cmd_descripts),
   reinterpret_cast<CMD_DATA*>(&player_cmd_data), 
   reinterpret_cast<CMD_STRS*>(&player_cmd_strs), 
   reinterpret_cast<CMD_SCKEYS*>(&player_cmd_keys)
};

static char* SettingsFileName = "settings.bin";
void WriteSettingsToFile()
{
   System::String^ sFileName = gcnew System::String(SettingsFileName);
   //unhide file to make changes
   //if (System::IO::File::Exists(sFileName))
   //   System::IO::File::SetAttributes(
   //       sFileName, 
   //       System::IO::File::GetAttributes(sFileName) 
   //          & ~System::IO::FileAttributes::Hidden
   //       );
      
   std::fstream File;
   File.open(SettingsFileName, std::ios::out | std::ios::binary);
   //save settings changes to file
   File.write(
      reinterpret_cast<char*>(&halo_cmd_keys),
      sizeof(CMD_SCKEYS) * HALO_CMDS_SIZE
      );
   File.write(
      reinterpret_cast<char*>(&rpg_beta6_2_cmd_keys),
      sizeof(CMD_SCKEYS) * RPGB_CMDS_SIZE
      );
   File.write(
      reinterpret_cast<char*>(&halo_commands.Enable_Shrtcts),
      sizeof(bool)
      );
   File.write(
      reinterpret_cast<char*>(&rpgbeta6_2_commands.Enable_Shrtcts),
      sizeof(bool)
      );
   File.close();
   
   //hide file
   //System::IO::File::SetAttributes(
   //   sFileName, 
   //   System::IO::File::GetAttributes(sFileName) 
   //      | System::IO::FileAttributes::Hidden
   //    );
   delete sFileName;
}

void GetSettingsFromFile()
{
   std::fstream File;
   File.open(SettingsFileName, std::ios::in | std::ios::binary);
   if (!File.fail())
   {
      File.read(
         reinterpret_cast<char*>(&halo_cmd_keys),
         sizeof(CMD_SCKEYS) * HALO_CMDS_SIZE
         );
      File.read(
         reinterpret_cast<char*>(&rpg_beta6_2_cmd_keys),
         sizeof(CMD_SCKEYS) * RPGB_CMDS_SIZE
         );
      File.read(
         reinterpret_cast<char*>(&halo_commands.Enable_Shrtcts),
         sizeof(bool)
         );
      File.read(
         reinterpret_cast<char*>(&rpgbeta6_2_commands.Enable_Shrtcts),
         sizeof(bool)
         );
      File.close();
   }
}

void PressKey(BYTE key, short times)
{
   for (short i = 0; i < times; i++)
   {
      System::Threading::Thread::Sleep(150);
      ::keybd_event(key, 0x1C, 0, NULL);
      System::Threading::Thread::Sleep(150);
      ::keybd_event(key, 0x1C, KEYEVENTF_KEYUP, NULL);
   }
}

int FindCMDArgIndex(System::String^ cmd_str, int num_of_spaces = 2)
{
   //count the number of spaces
   int str_2arg_index = 0; bool is_in_parenth = false;
   for (short spaces_cnt = 0; 
      str_2arg_index < cmd_str->Length && spaces_cnt < num_of_spaces; 
      str_2arg_index++)
   {
      if (cmd_str[str_2arg_index] == '\"')
      is_in_parenth = !is_in_parenth;
                        
      if (cmd_str[str_2arg_index] == ' ' && !is_in_parenth)
         spaces_cnt++;
   }
   return str_2arg_index;
}

template <typename T> inline
bool ParseCMDStringNumbers(System::String^ str_num, T* num_array, int size_of_array)
{
   bool succeded = true; System::String^ str_number;
   
   for (int str_i = 0, num_i = 0;
      str_i < str_num->Length && num_i < size_of_array && succeded;
      str_i++)
   {
      if (str_num[str_i] >= '-' && str_num[str_i] <= '9')
      {
         for (int num_cnt = 1; num_cnt < str_num->Length; num_cnt++)
         {
            //if the next character at this index is not a number
            //then we found the length
            if (str_num[str_i + num_cnt] < '-' || str_num[str_i + num_cnt] > '9')
            {
               str_number = str_num->Substring(str_i, num_cnt);
               if (!T::TryParse(str_number, num_array[num_i++]))
                  succeded = false;
                  
               str_i += num_cnt;
               break;
            }
         }
      }
   }
   return succeded;
}

//parse str for p0 - p15
/*bool ParseCMDStringPlayerIndexes(System::String^ str, int* player_num_array, int size_of_array)
{
   bool succeded = true; System::String^ str_number;
   //count the number of digits to the space
   for (int str_i = 0, num_i = 0; str_i < str->Length && num_i < size_of_array && succeded; str_i++)
   {
      if (str[str_i] == ' ' && str[str_i + 1] == 'p')
      {
         for (int num_cnt = 0; num_cnt < 2; num_cnt++)
         {
            //* is for all players
            if (str[str_i + 2 + num_cnt] == '*')
            {
               player_num_array[num_i++] = 16;
               break;
            }
            //if the next character at this index is not a number then we found the length
            else if (str[str_i + 2 + num_cnt] < '-' || str[str_i + 2 + num_cnt] > '9')
            {
               str_number = str->Substring(str_i + 2, num_cnt);
               if (!int::TryParse(str_number, player_num_array[num_i++]))
                  succeded = false;
                  
               break;
            }
         }
      }
   }
   return succeded;
}*/

//parse str by player name
bool MainForm::ParseCMDStringPlayerIndexes(System::String^ cmd_str, short* player_index_array, int &pi_found)
{
   DWORD static_player = 0; wchar_t player_name[HaloCE_lib::PlayerNameMaxSize] = {0};
   int max_players_to_find;
   
   if (pi_found != 0)
   {
      max_players_to_find = pi_found;
      pi_found = 0;
   }
   else
      max_players_to_find = Players_Table_Header->NumOfItems;
   
   if (cmd_str[0] == '\"')
   {
      int length = 0; while(cmd_str[length + 1] != '\"' && length < cmd_str->Length - 2) length++;
      cmd_str = cmd_str->Substring(1, length);
   }
   
   for (int pi = 0; pi < Players_Table_Header->NumOfItems && pi_found < max_players_to_find; pi++)
   {
      static_player = Players_Table_Header->ItemArray_ptr + (pi * Players_Table_Header->ItemSize);
      Halo_Process->ReadMemArray<wchar_t>((LPVOID)(static_player + 0x4), *player_name, HaloCE_lib::PlayerNameMaxSize);
      
      for (int i = 0; i < cmd_str->Length && i < HaloCE_lib::PlayerNameMaxSize; i++)
      {
            
         if (cmd_str[i] != '*' && cmd_str[i] != '?' && cmd_str[i] != player_name[i])
            break;
            
         if (cmd_str[i] == '*' || !player_name[i + 1])
         {
            player_index_array[pi_found++] = pi;
            break;
         }
      }
   }
   

   return pi_found > 0;
}

bool ParseCMDStringEndText(System::String^ str, wchar_t* text)
{
   bool succeded = true; int length = 0;

   for (int i = str->Length - 2; i > 0; i--, length++)
   {
      if (str[i] == ' ')
         break;
      if (i < 2)
      {
         succeded = false;
         break;
      }
   }
   
   for (int str_i = str->Length - length - 1, i = 0; str_i < str->Length - 1; str_i++, i++)
      text[i] = str[str_i];

   return succeded;
}
                      
static char* LocationsFileName = "locations.bin";
void WriteLocationsToFile(std::vector<MAPS>* locations)
{
   if (locations->size())
   {
      System::String^ sFileName = gcnew System::String(LocationsFileName);
      DWORD num_of_maps = locations->size(), num_of_locations = 0;
      
      //unhide file to make changes
      //if (System::IO::File::Exists(sFileName))
      //   System::IO::File::SetAttributes(sFileName, System::IO::File::GetAttributes(sFileName) & ~System::IO::FileAttributes::Hidden);
         
      std::fstream File;
      File.open(LocationsFileName, std::ios::out | std::ios::binary);
      //save settings changes to file
      File.write(reinterpret_cast<char*>(&num_of_maps), sizeof(DWORD));
      
      for (DWORD i = 0; i < num_of_maps; i++)
      {
         File.write(reinterpret_cast<char*>(&(*locations)[i].map_name), sizeof(char) * MAP_STR_SIZE);
         
         num_of_locations = (*locations)[i].teleport_locations.size();
         File.write(reinterpret_cast<char*>(&num_of_locations), sizeof(DWORD));
         for (DWORD j = 0; j < num_of_locations; j++)
            File.write(reinterpret_cast<char*>(&(*locations)[i].teleport_locations[j]), sizeof(TELEPORT_LOCATION));
      }
      
      File.close();
      
      //hide file
      //System::IO::File::SetAttributes(sFileName, System::IO::File::GetAttributes(sFileName) | System::IO::FileAttributes::Hidden);
      delete sFileName;
   }
}

void GetLocationsFromFile(std::vector<MAPS>* locations)
{
   std::fstream File; MAPS map_site; TELEPORT_LOCATION tele_site = {0};
   DWORD num_of_maps = 0, num_of_locations = 0;
   
   File.open(LocationsFileName, std::ios::in | std::ios::binary);
   if (!File.fail())
   {
      File.read(reinterpret_cast<char*>(&num_of_maps), sizeof(DWORD));
      
      for (DWORD i = 0; i < num_of_maps; i++)
      {
         File.read(reinterpret_cast<char*>(&map_site.map_name), sizeof(char) * MAP_STR_SIZE);
         
         File.read(reinterpret_cast<char*>(&num_of_locations), sizeof(DWORD));
         for (DWORD j = 0; j < num_of_locations; j++)
         {
            File.read(reinterpret_cast<char*>(&tele_site), sizeof(TELEPORT_LOCATION));
            map_site.teleport_locations.push_back(tele_site);
         }
         
         locations->push_back(map_site);
         map_site.teleport_locations.clear();
      }
      File.close();
   }
}

DWORD inline MainForm::GetStaticPlayer(short player_index)
{
   return Players_Table_Header->ItemArray_ptr
      + (player_index * Players_Table_Header->ItemSize);
}

DWORD inline MainForm::GetObj(short obj_index)
{
   DWORD obj_address = NULL;
   
   if(obj_index != -1)
      obj_address = Halo_Process->ReadMem<DWORD>(
         (LPVOID)(Object_Table_Header->ItemArray_ptr
         + (obj_index * Object_Table_Header->ItemSize) + 8));
         
   return obj_address;
}

DWORD inline MainForm::GetPlayerObj(short player_index)
{
   short player_object_index = Halo_Process->ReadMem<short>(
      (LPVOID)(GetStaticPlayer(player_index) + 0x34));
   
   return GetObj(player_object_index);
}

DWORD inline MainForm::GetPlayerVehObj(DWORD player_obj)
{
   DWORD veh_obj_address = NULL;
   short vehicle_obj_index = Halo_Process->ReadMem<WORD>((LPVOID)(player_obj + 0x11C));
   
   if (vehicle_obj_index != -1)
      veh_obj_address = GetObj(vehicle_obj_index);
      
   return veh_obj_address;
}

bool inline MainForm::KillPlayer(short player_index)
{
   bool succeded = false;
   DWORD player_object = GetPlayerObj(player_index);
   
   if(player_object)
   {
      Halo_Process->WriteMem<BYTE>((LPVOID)(player_object + 0x106), 0x20);
      succeded = true;
   }
   
   return succeded;
}

void MainForm::HaloDrawText(char *str, BYTE alpha, BYTE red, BYTE green, BYTE blue)
{
   //c string length
   int length = 0; do length++; while(str[length]);
   int resources_size = (sizeof(float) * 4) + (sizeof(char) * length); 
   float ARGB[4] = {0};
   
   ARGB[0] = (float)alpha / (float)255;
   ARGB[1] = (float)red / (float)255;
   ARGB[2] = (float)green / (float)255;
   ARGB[3] = (float)blue / (float)255;
   
   DWORD resources_loc = (DWORD)Halo_Process->AllocateMemory(resources_size);
   DWORD str_loc = resources_loc + (sizeof(float) * 4);
   
   Halo_Process->WriteMemArray<float>((LPVOID)resources_loc, (float&)*ARGB, 4);
   Halo_Process->WriteMemArray<char>((LPVOID)str_loc, *str, length);
   
   int asm_func_size = 23;
   BYTE *asm_func = new BYTE[asm_func_size]();
   DWORD asm_func_loc = (DWORD)Halo_Process->AllocateMemory(asm_func_size + sizeof(DWORD));
   
   
   int byte_loc = 0;
   asm_func[byte_loc++] = 0x55;                    //push ebp
   asm_func[byte_loc++] = 0x8B;                    //mov  ebp,esp
   asm_func[byte_loc++] = 0xEC;
   
   asm_func[byte_loc++] = 0xA1;                    //mov  eax,ARGB
   RWMemory::ToBytes_little_endian<DWORD>(&asm_func[byte_loc], asm_func_loc + asm_func_size);
   byte_loc += sizeof(DWORD);
   
   asm_func[byte_loc++] = 0x068;                    //push str
   RWMemory::ToBytes_little_endian<DWORD>(&asm_func[byte_loc], str_loc);
   byte_loc += sizeof(DWORD);
   
   asm_func[byte_loc++] = 0xE8;                    //call <function address>
   RWMemory::ToBytes_little_endian<DWORD>(&asm_func[byte_loc], (DWORD)HaloDrawText_Func_address - ((DWORD)asm_func_loc + byte_loc + 4));
   byte_loc += sizeof(DWORD);
   
   asm_func[byte_loc++] = 0x83;                    //add  esp,sizeof(DWORD)
   asm_func[byte_loc++] = 0xC4;
   asm_func[byte_loc++] = (BYTE)sizeof(DWORD);
      
   asm_func[byte_loc++] = 0x5D;                     //pop  ebp
   asm_func[byte_loc++] = 0xC3;                     //ret
   
   //it has to be a pointer to the array of floats...dumb huh
   Halo_Process->WriteMem<DWORD>((LPVOID)(asm_func_loc + byte_loc), resources_loc);
   
   //write the calling function to allocated space
   Halo_Process->WriteMemArray<BYTE>((LPVOID)asm_func_loc, (BYTE&)*asm_func, asm_func_size);
   
   HANDLE NewThreadhnd = ::CreateRemoteThread(Halo_Process->GetProcessHandle(), 0, 0, (LPTHREAD_START_ROUTINE)asm_func_loc, 0, 0, 0);
   ::WaitForSingleObject(NewThreadhnd, INFINITE);
   
   Halo_Process->FreeMemory((LPVOID)resources_loc, resources_size);
   Halo_Process->FreeMemory((LPVOID)asm_func_loc, asm_func_size + sizeof(DWORD));
   delete[] asm_func;
}

void MainForm::HaloConsole(char *func_str)
{
   //c string length
   int length = 0; do length++; while(func_str[length]);
   
   int asm_func_size = 20;
   BYTE *asm_func = new BYTE[asm_func_size]();
   DWORD asm_func_loc = (DWORD)Halo_Process->AllocateMemory(asm_func_size + (length * sizeof(char)));
   
   int byte_loc = 0;
   asm_func[byte_loc++] = 0x55;                    //push ebp
   asm_func[byte_loc++] = 0x8B;                    //mov  ebp,esp
   asm_func[byte_loc++] = 0xEC;
   
   asm_func[byte_loc++] = 0x6A;                    //push 0
   asm_func[byte_loc++] = 0x00;
   
   asm_func[byte_loc++] = 0xBF;                    //mov  edi,func_str
   RWMemory::ToBytes_little_endian<DWORD>(&asm_func[byte_loc], asm_func_loc + asm_func_size);
   byte_loc += sizeof(DWORD);
   
   asm_func[byte_loc++] = 0xE8;                    //call <function address>
   RWMemory::ToBytes_little_endian<DWORD>(&asm_func[byte_loc], HaloConsole_Func_address - ((DWORD)asm_func_loc + byte_loc + 4));
   byte_loc += sizeof(DWORD);
   
   asm_func[byte_loc++] = 0x83;                    //add  esp,sizeof(DWORD)
   asm_func[byte_loc++] = 0xC4;
   asm_func[byte_loc++] = (BYTE)sizeof(DWORD);
      
   asm_func[byte_loc++] = 0x5D;                     //pop  ebp
   asm_func[byte_loc++] = 0xC3;                     //ret
   
   //write the calling function to allocated space
   Halo_Process->WriteMemArray<BYTE>((LPVOID)asm_func_loc, (BYTE&)*asm_func, asm_func_size);
   Halo_Process->WriteMemArray<char>((LPVOID)(asm_func_loc + asm_func_size), (char&)*func_str, length);
   

   HANDLE NewThreadhnd = ::CreateRemoteThread(Halo_Process->GetProcessHandle(), 0, 0, (LPTHREAD_START_ROUTINE)asm_func_loc, 0, 0, 0);
   ::WaitForSingleObject(NewThreadhnd, INFINITE);
   
   Halo_Process->FreeMemory((LPVOID)asm_func_loc, asm_func_size + (length * sizeof(char)));
   delete[] asm_func;
}

void MainForm::HaloLocal_Chat(wchar_t *message)
{
   //c string length
   int length = 0; do length++; while(message[length]);
   LPVOID str_loc = Halo_Process->AllocateMemory(sizeof(wchar_t) * length);
   Halo_Process->WriteMemArray<wchar_t>(str_loc, (wchar_t&)*message, sizeof(wchar_t) * length);
   
   ULONG_PTR parameters[] = { (ULONG_PTR)str_loc };
   Halo_Process->CallRemoteFunction((LPTHREAD_START_ROUTINE)HaloLocal_Chat_Func_address, __CDECL, parameters, 1);
   
   Halo_Process->FreeMemory(str_loc, sizeof(wchar_t) * length);
}

void MainForm::sv_say(char *message)
{
   //c string length
   int length = 0; do length++; while(message[length]);
   LPVOID str_loc = Halo_Process->AllocateMemory(sizeof(char) * length);
   Halo_Process->WriteMemArray<char>(str_loc, (char&)*message, sizeof(char) * length);
                        
   ULONG_PTR parameters[] = { (ULONG_PTR)str_loc };
   Halo_Process->CallRemoteFunction((LPTHREAD_START_ROUTINE)sv_say_Func_address, __FASTCALL, parameters, 1);
   Halo_Process->FreeMemory(str_loc, sizeof(char) * length);
}

char map_str[MAP_STR_SIZE] = {0};
ULONG_PTR base_address = NULL;
DWORD scan_size = 0;               
//HaloCE_lib::STATIC_PLAYER* Static_Players;
std::vector<MAPS> maps_tele_sites;

MainForm::MainForm(void)
{
   C_Setting = 0;
   Lock_sec = 0, Halo_sec = 0;
   rpgb6_2_running = false;
   erase_chat = false;
   erase_cmd_terminator = false;
   display_txt = true;
   
   main_module_name = L"";
   Current_Map_address = NULL;
   Cheats_address = NULL;
   Base_ptr_address = NULL;
   chat_address_ptr = NULL;
   Console_chck_address = NULL;
   Console_txt_address = NULL;
   Rasterizer_address = NULL;
   ServerType_address = NULL;
   HaloConsole_Func_address = NULL;
   HaloDrawText_Func_address = NULL;
   HaloLocal_Chat_Func_address = NULL;
   sv_say_Func_address = NULL;
   Players_Table_Header_ptr_address = NULL;
   Device_Groups_Header_ptr_address = NULL;
   Object_Table_Header_ptr_address = NULL;
   HS_Global_Header_ptr_address = NULL;
             
	InitializeComponent();
	GetSettingsFromFile();
	GetLocationsFromFile(&maps_tele_sites);
}

MainForm::~MainForm()
{
   WriteLocationsToFile(&maps_tele_sites);
   if (components)
   {
	   delete components;
	}
}
      
void MainForm::update_info_timer_Tick(System::Object^  sender, System::EventArgs^  e)
{
   if (RWMemory::IsProcessOpenA("halo.exe") > 0)
   {
      running_gt = game_types::Halo;
      main_module_name = L"halo.exe";
      status_lbl->Text = "Halo";
   }
   else if (RWMemory::IsProcessOpenA("haloce.exe") > 0)
   {
      running_gt = game_types::HCE;
      main_module_name = L"haloce.exe";
      status_lbl->Text = "Halo CE";
   }
   else
   {
      if (Halo_Process)
      {
         running_gt = game_types::not_running;
         rpgb6_2_running = false;

         status_lbl->Text = "Halo CE";
         status_lbl2->Text = "Off";
         status_lbl2->ForeColor = System::Drawing::Color::Red;

         status_lbl4->Text = "";
         status_lbl3->Text = "";
         
         base_address = NULL;
         
         Players_Table_Header_ptr_address = NULL;
         Object_Table_Header_ptr_address = NULL;
         HS_Global_Header_ptr_address = NULL;
             
         //reset all halo cmd addresses to NULL
         for (int i = 0; i < HALO_CMDS_SIZE; i++)
            halo_cmd_data[i].cmd_address = NULL;
            
         Current_Map_address = NULL;
         Cheats_address = NULL;
         Base_ptr_address = NULL;
         chat_address_ptr = NULL;
         Console_chck_address = NULL;
         Console_txt_address = NULL;
         Rasterizer_address = NULL;
         ServerType_address = NULL;
         
         HaloConsole_Func_address = NULL;
         HaloDrawText_Func_address = NULL;
         HaloLocal_Chat_Func_address = NULL;
         sv_say_Func_address = NULL;
         
         control_enabled_change = true;
         
         Players_Table_Header = NULL;
         Device_Groups_Header = NULL;
         Object_Table_Header = NULL;
         HS_Global_Header = NULL;
         
         Halo_Process = NULL;
      }
   }
   
   if (running_gt != game_types::not_running)
   {
      //Free memory
      if (Halo_Process)
         delete Halo_Process;
         
      if (Players_Table_Header)
         delete Players_Table_Header;
      
      if (Device_Groups_Header)
         delete Device_Groups_Header;
         
      if (Object_Table_Header)
         delete Object_Table_Header;
         
      if (HS_Global_Header)
         delete HS_Global_Header;
      
      //if (Static_Players != nullptr)
      //   delete[] Static_Players;
   
      Halo_Process = new RWMemory(main_module_name);
      
      //if (Players_Table_Header_ptr_address < 10)
         control_enabled_change = true;
         
      status_lbl2->Text = "On";
      status_lbl2->ForeColor = System::Drawing::Color::Green;
      
      //find halo module info
      if (!base_address)
      {
         //give game time to load
         System::Threading::Thread::Sleep(250);
         Halo_Process->ModuleBaseCodeSize(main_module_name, base_address, scan_size);
      }
      
      //find patterns
      if (Players_Table_Header_ptr_address < 10)
      {
         ULONG_PTR SPHptr_ptr = Halo_Process->FindMemPattern(
                           base_address,
                           scan_size,
                           HaloCE_lib::Players_Table_Header_ptr_sig);
          
         Players_Table_Header_ptr_address = Halo_Process->ReadMem<DWORD>((LPVOID)SPHptr_ptr);
      }
      
      if (Device_Groups_Header_ptr_address < 10)
      {
         ULONG_PTR DGHptr_ptr = Halo_Process->FindMemPattern(
                           base_address,
                           scan_size,
                           HaloCE_lib::Device_Groups_Header_ptr_sig);
         
         Device_Groups_Header_ptr_address = Halo_Process->ReadMem<DWORD>((LPVOID)DGHptr_ptr);
      }
      
      if (Object_Table_Header_ptr_address < 10)
      {
         ULONG_PTR OTHptr_ptr = Halo_Process->FindMemPattern(
                           base_address,
                           scan_size,
                           HaloCE_lib::Object_Table_Header_ptr_sig);
          
         Object_Table_Header_ptr_address = Halo_Process->ReadMem<DWORD>((LPVOID)OTHptr_ptr);
      }
      
      if (HS_Global_Header_ptr_address < 10)
      {
         ULONG_PTR HSGptr_ptr = Halo_Process->FindMemPattern(
                                 base_address,
                                 scan_size,
                                 HaloCE_lib::HS_Global_Header_ptr_sig);
         
         HS_Global_Header_ptr_address = Halo_Process->ReadMem<DWORD>((LPVOID)HSGptr_ptr);
      }
      
      if (HaloConsole_Func_address < 10)
      {
         HaloConsole_Func_address = Halo_Process->FindMemPattern(
                         base_address,
                         scan_size,
                         HaloCE_lib::Console_func_addr_sig);
      }
      
      if (HaloDrawText_Func_address < 10)
      {
         HaloDrawText_Func_address = Halo_Process->FindMemPattern(
                         base_address,
                         scan_size,
                         HaloCE_lib::EngineDrawText_func_addr_sig);
      }
      
      if (HaloLocal_Chat_Func_address < 10)
      {
         HaloLocal_Chat_Func_address = (DWORD)Halo_Process->FindMemPattern(
                         base_address,
                         scan_size,
                         HaloCE_lib::Local_Chat_func_addr_sig);
      }
      
      if (sv_say_Func_address < 10 && running_gt == game_types::HCE)
      {
         sv_say_Func_address = (DWORD)Halo_Process->FindMemPattern(
                                  base_address,
                                  scan_size,
                                  HCE_Lib::sv_say_func_addr_sig);
      }
      
      if (halo_cmd_data[1].cmd_address < 10 && running_gt == game_types::HCE)
      {
         ULONG_PTR Dev_ptr = Halo_Process->FindMemPattern(
                         base_address,
                         scan_size,
                         HCE_Lib::Dev_addr_sig);
                         
         halo_cmd_data[1].cmd_address = Halo_Process->ReadMem<DWORD>((LPVOID)Dev_ptr);
      }
      
      if (Console_chck_address < 10)
      {
         ULONG_PTR console_ptr = Halo_Process->FindMemPattern(
                             base_address,
                             scan_size,
                             HaloCE_lib::Console_addr_sig);
                             
         Console_chck_address = Halo_Process->ReadMem<DWORD>((LPVOID)console_ptr);
         halo_cmd_data[0].cmd_address = Console_chck_address + HaloCE_lib::Console::Enabled_offset;
         Console_txt_address = Console_chck_address + HaloCE_lib::Console::Text_offset;
      }

      if (Current_Map_address < 10)
      {
         ULONG_PTR CMA_ptr = Halo_Process->FindMemPattern(
                         base_address,
                         scan_size,
                         HaloCE_lib::Current_map_addr_sig);
                         
         Current_Map_address = Halo_Process->ReadMem<DWORD>((LPVOID)CMA_ptr);
      }
      
      if (Cheats_address < 10)
      {
         ULONG_PTR mem_region_ptr = Halo_Process->FindMemPattern(
                                base_address,
                                scan_size,
                                HaloCE_lib::Cheats_addr_sig);
                                
         Cheats_address = Halo_Process->ReadMem<DWORD>((LPVOID)mem_region_ptr);
         halo_cmd_data[2].cmd_address = Cheats_address + HaloCE_lib::Cheats::Deathless_offset;
         halo_cmd_data[3].cmd_address = Cheats_address + HaloCE_lib::Cheats::Infinite_Ammo_offset;
         halo_cmd_data[4].cmd_address = Cheats_address + HaloCE_lib::Cheats::Bottomless_Clip_offset;
         halo_cmd_data[8].cmd_address = Cheats_address + HaloCE_lib::Cheats::Omnipotent_offset;
         halo_cmd_data[9].cmd_address = Cheats_address + HaloCE_lib::Cheats::JetPack_offset;
         halo_cmd_data[10].cmd_address = Cheats_address + HaloCE_lib::Cheats::Bmp_Possession_offset;
         halo_cmd_data[11].cmd_address = Cheats_address + HaloCE_lib::Cheats::Super_jmp_offset;
         halo_cmd_data[12].cmd_address = Cheats_address + HaloCE_lib::Cheats::Reflexive_damage_offset;
         halo_cmd_data[13].cmd_address = Cheats_address + HaloCE_lib::Cheats::Medusa_offset;
         halo_cmd_data[14].cmd_address = Cheats_address + HaloCE_lib::Cheats::Controller_offset;
      }

      if (Base_ptr_address < 10)
      {
         ULONG_PTR BPA_ptr = Halo_Process->FindMemPattern(
                         base_address,
                         scan_size,
                         HaloCE_lib::Base_ptr_addr_sig);
                         
         Base_ptr_address = Halo_Process->ReadMem<DWORD>((LPVOID)BPA_ptr);
      }

      if (halo_cmd_data[5].cmd_address < 10)
      {
         ULONG_PTR SHp_ptr = Halo_Process->FindMemPattern(
                         base_address,
                         scan_size,
                         HaloCE_lib::Show_Hud_ptr_addr_sig);
                         
         halo_cmd_data[5].cmd_address = Halo_Process->ReadMem<DWORD>((LPVOID)Halo_Process->ReadMem<DWORD>((LPVOID)SHp_ptr));
      }

      if (halo_cmd_data[6].cmd_address < 20)
      {
         ULONG_PTR lb_ptr = Halo_Process->FindMemPattern(
                        base_address,
                        scan_size,
                        HaloCE_lib::letterbox_ptr_addr_sig);
                        
         halo_cmd_data[6].cmd_address = Halo_Process->ReadMem<DWORD>((LPVOID)Halo_Process->ReadMem<DWORD>((LPVOID)lb_ptr)) + 8;
      }
      
      if (halo_cmd_data[7].cmd_address < 10)
      {
         ULONG_PTR re_ptr = Halo_Process->FindMemPattern(
                        base_address,
                        scan_size,
                        HaloCE_lib::Rider_Eject_addr_sig);
                        
         halo_cmd_data[7].cmd_address = Halo_Process->ReadMem<DWORD>((LPVOID)re_ptr);
      }
      
      if (Rasterizer_address < 10)
      {
         ULONG_PTR ra_ptr = Halo_Process->FindMemPattern(
                        base_address,
                        scan_size,
                        HaloCE_lib::Rasterizer_addr_sig);
                        
         Rasterizer_address = Halo_Process->ReadMem<DWORD>((LPVOID)ra_ptr);
         halo_cmd_data[15].cmd_address = Rasterizer_address + HaloCE_lib::Rasterizer::WireFrame_offset;
         halo_cmd_data[16].cmd_address = Rasterizer_address + HaloCE_lib::Rasterizer::FogAtmosphere_offset;
         halo_cmd_data[17].cmd_address = Rasterizer_address + HaloCE_lib::Rasterizer::FogPlane_offset;
         halo_cmd_data[18].cmd_address = Rasterizer_address + HaloCE_lib::Rasterizer::FPS_offset;
      }
      
      if (halo_cmd_data[19].cmd_address < 50)
      {
         ULONG_PTR gs_ptr = Halo_Process->FindMemPattern(
                        base_address,
                        scan_size,
                        HaloCE_lib::Game_Speed_ptr_addr_sig);
                        
         halo_cmd_data[19].cmd_address = Halo_Process->ReadMem<DWORD>(
            (LPVOID)Halo_Process->ReadMem<DWORD>((LPVOID)gs_ptr)) + 0x18;
      }
      
      if (ServerType_address < 10)
      {
         ULONG_PTR svhc_ptr = Halo_Process->FindMemPattern(
                        base_address,
                        scan_size,
                        HaloCE_lib::ServerType_ptr_addr_sig);
                        
         ServerType_address = Halo_Process->ReadMem<DWORD>((LPVOID)svhc_ptr);
      }
      
      Players_Table_Header = new HaloCE_lib::DATA_HEADER(Halo_Process->ReadMem<HaloCE_lib::DATA_HEADER>(
         (LPVOID)Halo_Process->ReadMem<DWORD>((LPVOID)Players_Table_Header_ptr_address)));
      
      Device_Groups_Header = new HaloCE_lib::DATA_HEADER(Halo_Process->ReadMem<HaloCE_lib::DATA_HEADER>(
         (LPVOID)Halo_Process->ReadMem<DWORD>((LPVOID)Device_Groups_Header_ptr_address))); 
            
      Object_Table_Header = new HaloCE_lib::DATA_HEADER(Halo_Process->ReadMem<HaloCE_lib::DATA_HEADER>(
         (LPVOID)Halo_Process->ReadMem<DWORD>((LPVOID)Object_Table_Header_ptr_address)));
      
      HS_Global_Header = new HaloCE_lib::DATA_HEADER(Halo_Process->ReadMem<HaloCE_lib::DATA_HEADER>(
         (LPVOID)Halo_Process->ReadMem<DWORD>((LPVOID)HS_Global_Header_ptr_address)));
         
      //Static_Players = new HaloCE_lib::STATIC_PLAYER[Players_Table_Header.NumOfItems];
      //for (int i = 0; i < Players_Table_Header.NumOfItems && i < 16; i++)
      //   Static_Players[i] = Halo_Process->ReadMem<HaloCE_lib::STATIC_PLAYER>((LPVOID)(Players_Table_Header.ItemArray_ptr + i * Players_Table_Header.ItemSize));
      
      //update host/client lbl 0 - main menu, 1 - client, 2 - host
      temp = (BYTE)running_sv_t;
      running_sv_t = Halo_Process->ReadMem<server_type>((LPVOID)ServerType_address);
      if ((BYTE)running_sv_t != temp)
      {
         if (running_sv_t == server_type::main_menu)
         {
            rcon_lbl->ForeColor = System::Drawing::Color::Red;
            rcon_lbl->Text = "Main Menu";
         }
         else if (running_sv_t == server_type::client)
         {
            rcon_lbl->ForeColor = System::Drawing::Color::Red;
            rcon_lbl->Text = "Client";
         }
         else if (running_sv_t == server_type::host)
         {
            rcon_lbl->ForeColor = System::Drawing::Color::Green;
            rcon_lbl->Text = "Hosting";
         }
      }
      
      status_lbl3->Text = "Map:";
      for (int i = 0; i < MAP_STR_SIZE; i++)
         map_str[i] = 0;//reset
      
      Halo_Process->ReadMemString((LPVOID)Current_Map_address, map_str);
      status_lbl4->Text = gcnew System::String(map_str);
      if (status_lbl4->Text == "ui" && display_txt)
      {
         HaloDrawText("Halo Dev Controls - Jesus7Freak", 255, 255, 255, 255);
         display_txt = false;
      }
      else if (status_lbl4->Text != "ui")
         display_txt = true;
      
      //update dev btn
      if (Halo_Process->ReadMem<bool>((LPVOID)halo_cmd_data[1].cmd_address))
      {
         btn_dev->Text = "Disable Dev";
         btn_dev->ForeColor = System::Drawing::Color::Green;//Chartreuse;
      }
      else
      {
         btn_dev->Text = "Enable Dev";;
         btn_dev->ForeColor = System::Drawing::Color::Red;
      }
      
      //update console btn
      if (Halo_Process->ReadMem<bool>((LPVOID)halo_cmd_data[0].cmd_address))
      {
         btn_console->Text = "Disable Console";
         btn_console->ForeColor = System::Drawing::Color::Green;//Chartreuse;
      }
      else
      {
         btn_console->Text = "Enable Console";
         btn_console->ForeColor = System::Drawing::Color::Red;
      }
      
      //update deathless value
       if (Deathless_chkBx->Checked != (temp = Halo_Process->ReadMem<bool>((LPVOID)halo_cmd_data[2].cmd_address)))
         Deathless_chkBx->Checked = temp ? true : false;

      //update infinite ammo value
      if (IF_chkBx->Checked != (temp = Halo_Process->ReadMem<bool>((LPVOID)halo_cmd_data[3].cmd_address)))
         IF_chkBx->Checked = temp != 0;

      //update show hud value
      if (showhud_chkBx->Checked != (temp = Halo_Process->ReadMem<bool>((LPVOID)halo_cmd_data[5].cmd_address)))
         showhud_chkBx->Checked = !!temp;//same as temp ? true : false;

      //update letter box value
      if (letterbox_chkBx->Checked != (temp = Halo_Process->ReadMem<bool>((LPVOID)halo_cmd_data[6].cmd_address)))
         letterbox_chkBx->Checked = tobool(temp);

      //update rider ejction value
      if (ejection_chkBx->Checked != (temp = Halo_Process->ReadMem<bool>((LPVOID)halo_cmd_data[7].cmd_address)))
         ejection_chkBx->Checked = tobool(temp);
      
      //keyboard shortcuts
      if (halo_commands.Enable_Shrtcts)
      {
         for (int i = 0; i < HALO_CMDS_SIZE - 4; i++)
         {
            //skip if not running the specified game type for game dependent cmds
            if (halo_cmd_data[i].gametype_affect)
               if (running_gt != game_types::HCE)
                  continue;
                  
            //skip if not hosting for host dependent cmds
            if (halo_cmd_data[i].host_affected)
               if (running_sv_t == server_type::client)
                  continue;
               
            //toggle cmd on/off
            if (IsKeyDown(halo_cmd_keys[i].toggle_key))
            {
               Halo_Process->WriteMem<bool>((LPVOID)halo_cmd_data[i].cmd_address, !Halo_Process->ReadMem<bool>((LPVOID)halo_cmd_data[i].cmd_address));
               break;
            }
            //turn cmd on
            else if (IsKeyDown(halo_cmd_keys[i].on_key))
            {
               Halo_Process->WriteMem<bool>((LPVOID)halo_cmd_data[i].cmd_address, true);
               break;
            }
            //turn cmd off
            else if (IsKeyDown(halo_cmd_keys[i].off_key))
            {
               Halo_Process->WriteMem<bool>((LPVOID)halo_cmd_data[i].cmd_address, false);
               break;
            }
         }
      }

      //if console isnt open, use chat for commands
      if (!Halo_Process->ReadMem<bool>((LPVOID)Console_chck_address))
      {
         //check for in game chat commands///
         //Chat_address = HCE_Lib.Console_Buffer_address;
         chat_address_ptr = Halo_Process->ReadMem<DWORD>(
                   (LPVOID)(Halo_Process->ReadMem<DWORD>(
                   (LPVOID)(Halo_Process->ReadMem<DWORD>(
                   (LPVOID)(Halo_Process->ReadMem<DWORD>(
                   (LPVOID)(Halo_Process->ReadMem<DWORD>(
                   (LPVOID)Base_ptr_address) + 0x94)) + 0x4)) + 0x8)))) + 0x94;

         Chat_address = Halo_Process->ReadMem<DWORD>((LPVOID)chat_address_ptr);
         wchar_t chat_str[CMD_STR_SIZE] = {0};
         Halo_Process->ReadMemArray<wchar_t>((LPVOID)Chat_address, *chat_str, CMD_STR_SIZE);
         chat = gcnew System::String(chat_str);
      }
      else
      {
         Chat_address = Console_txt_address;
         char chat_str[CMD_STR_SIZE] = {0};
         Halo_Process->ReadMemArray<char>((LPVOID)Chat_address, *chat_str, CMD_STR_SIZE);
         chat = gcnew System::String(chat_str);
      }
      
      if (chat != "" && chat[0] == '/' && chat[chat->Length - 1] == ';')
      {
         for (int i = 0; i < HALO_CMDS_SIZE - 4; i++)
         {
         
            //skip if not running the specified game type for game dependent cmds
            if (halo_cmd_data[i].gametype_affect)
               if (running_gt != game_types::HCE)
                  continue;
                     
            //skip if not hosting for host dependent cmds
            if (halo_cmd_data[i].host_affected)
               if (running_sv_t == server_type::client)
                  continue;
                  
            //toggle cmd on/off
            /*if (chat == gcnew System::String(halo_cmd_data[i].cmd_activate))
            {
               Halo_Process->WriteMem<bool>(halo_cmd_data[i].cmd_address, !Halo_Process->ReadMem<bool>(halo_cmd_data[i].cmd_address));
               erase_chat = true;
               break;
            }
            //turn cmd on
            else*/ if (chat == gcnew System::String(halo_cmd_strs[i].cmd_on))
            {
               Halo_Process->WriteMem<bool>((LPVOID)halo_cmd_data[i].cmd_address, true);
               erase_chat = true;
               break;
            }
            //turn cmd off
            else if (chat == gcnew System::String(halo_cmd_strs[i].cmd_off))
            {
               Halo_Process->WriteMem<bool>((LPVOID)halo_cmd_data[i].cmd_address, false);
               erase_chat = true;
               break;
            }
         }
         
         if (!erase_chat && running_sv_t != server_type::client)
         {
            if (chat->Contains("/game_speed "))
            {
               float number = 0;
                  
               if (ParseCMDStringNumbers<float>(chat->Substring(12), &number, 1))
               {
                  Halo_Process->WriteMem<float>((LPVOID)halo_cmd_data[19].cmd_address, number);
                  erase_chat = true;
               }
            }
            else if (chat->Contains("/spd "))
            {
               float number = 0; 
                  
               int str_2arg_index = FindCMDArgIndex(chat);
               short *player_index = new short[Players_Table_Header->NumOfItems](); int pi_found = 0;
                  
               if (ParseCMDStringPlayerIndexes(chat->Substring(5), player_index, pi_found))
               {
                  if (ParseCMDStringNumbers<float>(chat->Substring(str_2arg_index), &number, 1))
                  {
                     /*if (player_index < Players_Table_Header->NumOfItems || player_index == 16)
                     {
                        /*short pi = 0;
                        if (player_index < Players_Table_Header->NumOfItems)
                           pi = player_index++;
                        else if (player_index == 16)
                           //all players
                           player_index = Players_Table_Header->NumOfItems;*/
                              
                     for (int i = 0; i < pi_found; i++)
                        Halo_Process->WriteMem<float>((LPVOID)(GetStaticPlayer(player_index[i]) + 0x6C), number);
                              
                     erase_chat = true;
                  }
               }
               
               erase_cmd_terminator = !erase_chat;
               if (player_index != nullptr)
                  delete[] player_index;
            }
            else if (chat->Contains("/team "))
            {
               bool Team = 0;
               short *player_index = new short[Players_Table_Header->NumOfItems](); int pi_found = 0;
               if (ParseCMDStringPlayerIndexes(chat->Substring(6), player_index, pi_found))
               {
                  for (int i = 0; i < pi_found; i++)
                  {
                     KillPlayer(player_index[i]);
                     LPVOID Player_Team_address = (LPVOID)(GetStaticPlayer(player_index[i]) +0x20);
                     Team = Halo_Process->ReadMem<bool>(Player_Team_address);
                     Halo_Process->WriteMem<bool>(Player_Team_address, !Team);
                     erase_chat = true;
                  }
               }
               
               erase_cmd_terminator = !erase_chat;
               if (player_index != nullptr)
                  delete[] player_index;
            }
            else if (chat->Contains("/afk "))
            {
               DWORD number = 90;
               short *player_index = new short[Players_Table_Header->NumOfItems](); int pi_found = 0;
               if (ParseCMDStringPlayerIndexes(chat->Substring(5), player_index, pi_found))
               {
                  for (int i = 0; i < pi_found; i++)
                  {
                     if (KillPlayer(player_index[i]))
                     {
                        number = 0x7FFFFFFF;
                        Sleep(50);
                     }
                        
                     Halo_Process->WriteMem<DWORD>((LPVOID)(GetStaticPlayer(player_index[i]) + 0x2C), number);
                     erase_chat = true;
                  }
                  
                  erase_cmd_terminator = !erase_chat;
                  if (player_index != nullptr)
                     delete[] player_index;
               }
            }
            else if (chat->Contains("/k "))
            {
               short *player_index = new short[Players_Table_Header->NumOfItems](); int pi_found = 0;
               if (ParseCMDStringPlayerIndexes(chat->Substring(3), player_index, pi_found))
               {
                  for (int i = 0; i < pi_found; i++)
                  {
                     char _str[11] = {0};
                     _str[0] = 's';
                     _str[1] = 'v';
                     _str[2] = '_';
                     _str[3] = 'k';
                     _str[4] = 'i';
                     _str[5] = 'c';
                     _str[6] = 'k';
                     _str[7] = ' ';
                     
                     if (++player_index[i] > 9)
                     {
                        _str[8] = '1';
                        _str[9] = (player_index[i] - 10) + 48;
                     }
                     else
                     {
                        _str[8] = '0';
                        _str[9] = player_index[i] + 48;
                     }
                     
                     HaloConsole(_str);
                     erase_chat = true;
                  }
               }
               
               erase_cmd_terminator = erase_chat;
               if (player_index != nullptr)
                  delete[] player_index;
            }
            else if (chat->Contains("/b "))
            {
               short *player_index = new short[Players_Table_Header->NumOfItems](); int pi_found = 0;
               if (ParseCMDStringPlayerIndexes(chat->Substring(3), player_index, pi_found))
               {
                  for (int i = 0; i < pi_found; i++)
                  {
                     char _str[10] = {0};
                     _str[0] = 's';
                     _str[1] = 'v';
                     _str[2] = '_';
                     _str[3] = 'b';
                     _str[4] = 'a';
                     _str[5] = 'n';
                     _str[6] = ' ';
                     
                     if (++player_index[i] > 9)
                     {
                        _str[7] = '1';
                        _str[8] = (player_index[i] - 10) + 48;
                     }
                     else
                     {
                        _str[7] = '0';
                        _str[8] = player_index[i] + 48;
                     }
                     
                     HaloConsole(_str);
                     erase_chat = true;
                  }
               }
               
               erase_cmd_terminator = erase_chat;
               if (player_index != nullptr)
                  delete[] player_index;
            }
            else if (chat->Contains("/kill "))
            {
               short *player_index = new short[Players_Table_Header->NumOfItems](); int pi_found = 0;
               if (ParseCMDStringPlayerIndexes(chat->Substring(6), player_index, pi_found))
               {
                  for (int i = 0; i < pi_found; i++)
                  {
                     KillPlayer(player_index[i]);
                     erase_chat = true;
                  }
               }
               
               erase_cmd_terminator = erase_chat;
               if (player_index != nullptr)
                  delete[] player_index;
            }
            else if (chat->Contains("/health "))
            {
               float number = 0;
                 
               int str_2arg_index = FindCMDArgIndex(chat);
               if (ParseCMDStringNumbers<float>(chat->Substring(str_2arg_index), &number, 1))
               {
                  short *player_index = new short[Players_Table_Header->NumOfItems](); int pi_found = 0;
                  if (ParseCMDStringPlayerIndexes(chat->Substring(8), player_index, pi_found))
                  {
                     for (int i = 0; i < pi_found; i++)
                     {
                        DWORD player_object = GetPlayerObj(player_index[i]);
                        if(player_object)
                        {
                           Halo_Process->WriteMem<float>((LPVOID)(player_object + 0xE0), number);
                           erase_chat = true;
                        } 
                     } 
                  }
                  
                  erase_cmd_terminator = !erase_chat;
                  if (player_index != nullptr)
                     delete[] player_index;
               }
            }
            else if (chat->Contains("/shield "))
            {
               float number = 0;
                  
               int str_2arg_index = FindCMDArgIndex(chat);
               if (ParseCMDStringNumbers<float>(chat->Substring(str_2arg_index), &number, 1))
               {
                  short *player_index = new short[Players_Table_Header->NumOfItems](); int pi_found = 0;
                  if (ParseCMDStringPlayerIndexes(chat->Substring(8), player_index, pi_found))
                  {
                     for (int i = 0; i < pi_found; i++)
                     {
                        DWORD player_object = GetPlayerObj(player_index[i]);
                        if(player_object)
                        {
                           Halo_Process->WriteMem<float>((LPVOID)(player_object + 0xE4), number);
                           erase_chat = true;
                        }
                     }
                  }
                  
                  erase_cmd_terminator = !erase_chat;
                  if (player_index != nullptr)
                     delete[] player_index;
               }
            }
            else if (chat->Contains("/t "))
            {
               float coordinates[3] = {0}; 
               short *player_index = new short[Players_Table_Header->NumOfItems](); int pi_found = 0;
               bool teleport = false; DWORD player2_object = 0;
               
               //count the number of spaces
               int num_of_chars = 0;
               for (int i = 0; i < chat->Length; i++)
                  if (chat[i] == ' ')
                     num_of_chars++;
                  
               if (num_of_chars == 4)
               {
                  int str_2arg_index = FindCMDArgIndex(chat);
                  if (ParseCMDStringPlayerIndexes(chat->Substring(3), player_index, pi_found))
                     if (ParseCMDStringNumbers<float>(chat->Substring(str_2arg_index), coordinates, 3))
                        teleport = true;
               }
               else
               {
                  wchar_t tele_loc_name[TELE_LOC_NAME_SIZE] = {0};
                        
                  ParseCMDStringPlayerIndexes(chat->Substring(3), player_index, pi_found);
                  ParseCMDStringEndText(chat, tele_loc_name);
                        
                  unsigned int map_i = 0;
                  if (FindMapIndex(&maps_tele_sites, map_str, map_i))
                  {
                     unsigned int tele_loc_i = 0;
                     if (FindTeleLocNameIndex(&maps_tele_sites[map_i].teleport_locations, tele_loc_name, tele_loc_i))
                     {
                        for (int i = 0; i < 3; i++)
                           coordinates[i] =  maps_tele_sites[map_i].teleport_locations[tele_loc_i].coordinates[i];
                              
                        teleport = true;
                     }
                  }
               }
                  
               if (teleport)
               {
                  for (int i = 0; i < pi_found; i++)
                  {
                     DWORD player_object = GetPlayerObj(player_index[i]);
                     if(player_object)
                     {
                        //if player is in a vehicle, use vehicle's coordinates
                        DWORD vehicle_object = GetPlayerVehObj(player_object);
                        if (vehicle_object)
                           player_object = vehicle_object;
                                    
                        if (player2_object && i) 
                           coordinates[2] += 1;
                                    
                        Halo_Process->WriteMemArray<float>((LPVOID)(player_object + 0x5C), (float&)coordinates, 3);
                        erase_chat = true;
                     }
                  }
               }
               
               erase_cmd_terminator = !erase_chat;
               if (player_index != nullptr)
                  delete[] player_index;
            }
            else if (chat->Contains("/tp "))
            {
               float coordinates[3] = {0}; 
               short *player_index = new short[Players_Table_Header->NumOfItems](); int pi_found = 0;
               short player2_index = 0; int pi2_to_find = 1;
                  
               if (ParseCMDStringPlayerIndexes(chat->Substring(4), player_index, pi_found))
               {
                  int str_2p_index = FindCMDArgIndex(chat);
                  if (ParseCMDStringPlayerIndexes(chat->Substring(str_2p_index), &player2_index, pi2_to_find))
                  {
                     DWORD player2_object = GetPlayerObj(player2_index);
                     if (player2_object)
                     {
                        //if player is in a vehicle, use vehicle's coordinates
                        DWORD vehicle_object = GetPlayerVehObj(player2_object);
                        if (vehicle_object)
                           player2_object = vehicle_object;
                                    
                        for (int i = 0; i < 3; i++)
                           coordinates[i] += Halo_Process->ReadMem<float>(
                              (LPVOID)(player2_object + 0x5C + sizeof(float) * i));
                              
                        for (int i = 0; i < pi_found; i++)
                        {
                           DWORD player_object = GetPlayerObj(player_index[i]);
                           if (player_object)
                           {        
                              //if player is in a vehicle, use vehicle's coordinates
                              vehicle_object = GetPlayerVehObj(player_object);
                              if (vehicle_object)
                                 player_object = vehicle_object;
                                
                              coordinates[2] += 1;       
                              Halo_Process->WriteMemArray<float>((LPVOID)(player_object + 0x5C), (float&)coordinates, 3);
                              erase_chat = true;
                           }
                        }
                     }
                  }
               }
               
               erase_cmd_terminator = !erase_chat;
               if (player_index != nullptr)
                  delete[] player_index;
            }
            else if (chat->Contains("/v "))
            {
               float velocity_direction[3] = {0}; 
               short *player_index = new short[Players_Table_Header->NumOfItems](); int pi_found = 0;
                  
               if (ParseCMDStringPlayerIndexes(chat->Substring(3), player_index, pi_found))
               {
                  int str_2arg_index = FindCMDArgIndex(chat);
                  if (ParseCMDStringNumbers<float>(chat->Substring(str_2arg_index), velocity_direction, 3))
                  { 
                     for (int i = 0; i < pi_found; i++)
                     {
                        DWORD player_object = GetPlayerObj(player_index[i]);
                        if (player_object)
                        {               
                           //if player is in a vehicle, use vehicle's coordinates
                           DWORD vehicle_object = GetPlayerVehObj(player_object);
                           if (vehicle_object)
                              player_object = vehicle_object;
                                      
                           Halo_Process->WriteMemArray<float>((LPVOID)(player_object + 0x68), (float&)velocity_direction, 3);  
                           erase_chat = true;
                        }
                     }
                  }
               }
               
               erase_cmd_terminator = !erase_chat;
               if (player_index != nullptr)
                  delete[] player_index;
            }
            else if (chat->Contains("/st "))
            {
               TELEPORT_LOCATION tele_site = {0};
                  
               if (ParseCMDStringEndText(chat, tele_site.teleport_loc_name))
               {
                  short *player_index = new short[Players_Table_Header->NumOfItems](); int pi_found = 1;
                  if (ParseCMDStringPlayerIndexes(chat->Substring(4), player_index, pi_found))
                  {
                     DWORD player_object = GetPlayerObj(player_index[0]);
                     if (player_object)
                     {            
                        //if player is in a vehicle, use vehicle's coordinates
                        DWORD vehicle_object = GetPlayerVehObj(player_object);
                        if (vehicle_object)
                           player_object = vehicle_object;
                                       
                        Halo_Process->ReadMemArray<float>((LPVOID)(player_object + 0x5C), (float&)tele_site.coordinates, 3);

                        unsigned int map_i = 0, tele_loc_i = 0;
                        if (!FindMapIndex(&maps_tele_sites, map_str, map_i))
                        {
                           MAPS map_loc;
                                 
                           for (int i = 0; i < MAP_STR_SIZE; i++)
                              map_loc.map_name[i] = map_str[i];
                                    
                           maps_tele_sites.push_back(map_loc);
                           map_i = maps_tele_sites.size() - 1;
                        }
                              
                        //if the tele site exists, overwrite it
                        if (FindTeleLocNameIndex(&maps_tele_sites[map_i].teleport_locations, tele_site.teleport_loc_name, tele_loc_i))
                           maps_tele_sites[map_i].teleport_locations[tele_loc_i] = tele_site;
                        else
                           maps_tele_sites[map_i].teleport_locations.push_back(tele_site);
                           
                        erase_chat = true;
                     }     
                  }
                  
                  erase_cmd_terminator = !erase_chat;
                  if (player_index != nullptr)
                     delete[] player_index;
               }
            }
            else if (chat->Contains("/j "))
            {
               float coordinates[3] = {0};
                  
               int str_2arg_index = FindCMDArgIndex(chat);
               if (ParseCMDStringNumbers<float>(chat->Substring(str_2arg_index), coordinates, 3))
               {
                  short *player_index = new short[Players_Table_Header->NumOfItems](); int pi_found = 0;
                  if (ParseCMDStringPlayerIndexes(chat->Substring(3), player_index, pi_found))
                  {
                     for (int i = 0; i < pi_found; i++)
                     {
                        DWORD player_object = GetPlayerObj(player_index[i]);
                        if (player_object)
                        {        
                           //if player is in a vehicle, use vehicle's coordinates
                           DWORD vehicle_object = GetPlayerVehObj(player_object);
                           if (vehicle_object)
                              player_object = vehicle_object;
                                       
                           for (int i = 0; i < 3; i++)
                              coordinates[i] += Halo_Process->ReadMem<float>((LPVOID)(player_object + 0x5C + sizeof(float) * i));
                                    
                           Halo_Process->WriteMemArray<float>((LPVOID)(player_object + 0x5C), (float&)coordinates, 3);
                           erase_chat = true; 
                        }    
                     } 
                  }
                  
                  if (player_index != nullptr)
                     delete[] player_index;
               }
               
               erase_cmd_terminator = !erase_chat;
            }
            else if (chat->Contains("/ammo "))
            {
               short number = 0;
                  
               int str_2arg_index = FindCMDArgIndex(chat);
               if (ParseCMDStringNumbers<short>(chat->Substring(str_2arg_index), &number, 1))
               {
                  short *player_index = new short[Players_Table_Header->NumOfItems](); int pi_found = 0;
                  if (ParseCMDStringPlayerIndexes(chat->Substring(6), player_index, pi_found))
                  {
                     for (int i = 0; i < pi_found; i++)
                     { 
                        DWORD player_object = GetPlayerObj(player_index[i]);
                        if (player_object)
                        {
                           short weapon_index = Halo_Process->ReadMem<short>((LPVOID)(player_object + 0x118));
                           DWORD weapon_object = GetObj(weapon_index);
                           if (weapon_object)
                           { 
                              Halo_Process->WriteMem<short>((LPVOID)(weapon_object + 0x2B6), number);
                              erase_chat = true;
                           }
                        }
                     }
                  }
                  if (player_index != nullptr)
                     delete[] player_index;
               }
               
               erase_cmd_terminator = !erase_chat;
            }
            else if (chat->Contains("/bat "))
            {
               short number = 0;
                  
               int str_2arg_index = FindCMDArgIndex(chat);
               if (ParseCMDStringNumbers<short>(chat->Substring(str_2arg_index), &number, 1))
               {
                  short *player_index = new short[Players_Table_Header->NumOfItems](); int pi_found = 0;
                  if (ParseCMDStringPlayerIndexes(chat->Substring(5), player_index, pi_found))
                  {
                     for (int i = 0; i < pi_found; i++)
                     { 
                        DWORD player_object = GetPlayerObj(player_index[i]);
                        if (player_object)
                        {
                           short weapon_index = Halo_Process->ReadMem<short>((LPVOID)(player_object + 0x118));
                           DWORD weapon_object = GetObj(weapon_index);
                           if (weapon_object)
                           {
                              float battery_used = (100 - (float)number)/ 100;
                              Halo_Process->WriteMem<float>((LPVOID)(weapon_object + 0x240), battery_used);
                              erase_chat = true;
                           }
                        }
                     }
                  }
                  if (player_index != nullptr)
                     delete[] player_index;
               }
               
               erase_cmd_terminator = !erase_chat;
            }
         }
         if (!erase_chat)
         {
            if (chat->Contains("/camo "))
            {
               BYTE number = 0;
                  
               int str_2arg_index = FindCMDArgIndex(chat);
               if (ParseCMDStringNumbers<BYTE>(chat->Substring(str_2arg_index), &number, 1))
               {
                  if (number == 1)
                     number = 0x51;
                  else if (number == 0)
                     number = 0x41;
                        
                  short *player_index = new short[Players_Table_Header->NumOfItems](); int pi_found = 0;
                  if (ParseCMDStringPlayerIndexes(chat->Substring(6), player_index, pi_found))
                  {
                     for (int i = 0; i < pi_found; i++)
                     { 
                        DWORD player_object = GetPlayerObj(player_index[i]);
                        if (player_object)
                        {
                           Halo_Process->WriteMem<BYTE>((LPVOID)(player_object + 0x204), number);
                           erase_chat = true;
                        }
                     }
                  }
                  
                  erase_cmd_terminator = !erase_chat;
                  if (player_index != nullptr)
                     delete[] player_index;
               }
            }
            else if (chat->Contains("/suspend "))
            {
               BYTE number = 0;
               
               int str_2arg_index = FindCMDArgIndex(chat);
               if (ParseCMDStringNumbers<BYTE>(chat->Substring(str_2arg_index), &number, 1))
               {
                  short *player_index = new short[Players_Table_Header->NumOfItems](); int pi_found = 0;
                  if (ParseCMDStringPlayerIndexes(chat->Substring(9), player_index, pi_found))
                  {
                     for (int i = 0; i < pi_found; i++)
                     {
                        DWORD player_object = GetPlayerObj(player_index[i]);
                        if (player_object)
                        {
                           Halo_Process->WriteMem<BYTE>((LPVOID)(player_object + 0x207), number);
                           erase_chat = true;
                        }
                     }
                  }
                  
                  erase_cmd_terminator = !erase_chat;
                  if (player_index != nullptr)
                     delete[] player_index;
               }
            }
         }
      }
      
      //test for rpg_beta6_2 map///////////////////////////////////////
      //if (map_str != "rpg_beta6_2")
      if (map_str[0] == 'r' && map_str[1] == 'p' && map_str[2] == 'g' &&
         map_str[3] == '_' && map_str[4] == 'b' && map_str[5] == 'e' &&
         map_str[6] == 't' && map_str[7] == 'a' && map_str[8] == '6' &&
         map_str[9] == '_' && map_str[10] == '2' && map_str[11] == '\0')
      {
         //get address for this map
         if (!rpgb6_2_running)
         {
            rpg_beta6_2_cmd_data[0].cmd_address = HS_Global_Header->ItemArray_ptr
               + HCE_Lib::rpg_beta6_2_hs_global::setting_offset;
            
            rpg_beta6_2_cmd_data[1].cmd_address = HS_Global_Header->ItemArray_ptr 
               + HCE_Lib::rpg_beta6_2_hs_global::alarmed_offset;
            
            rpg_beta6_2_cmd_data[2].cmd_address = HS_Global_Header->ItemArray_ptr 
               + HCE_Lib::rpg_beta6_2_hs_global::locked_offset;
            
            rpg_beta6_2_cmd_data[3].cmd_address = HS_Global_Header->ItemArray_ptr 
               + HCE_Lib::rpg_beta6_2_hs_global::nuked_offset;
            
            rpg_beta6_2_cmd_data[4].cmd_address = HS_Global_Header->ItemArray_ptr 
               + HCE_Lib::rpg_beta6_2_hs_global::lock_timer_offset;
               
            rpg_beta6_2_cmd_data[5].cmd_address = HS_Global_Header->ItemArray_ptr 
               + HCE_Lib::rpg_beta6_2_hs_global::boom_timer_offset;
               
            control_enabled_change = true;
            rpgb6_2_running = true;
         }
         
         status_lbl4->ForeColor = System::Drawing::Color::Green;
         
         if (halo_timer_txt->Mask != "000")
         {
            BLD_timer_txt->Mask = "000";
            halo_timer_txt->Mask = "000";
         }

         //update alarm button
         if (Halo_Process->ReadMem<bool>((LPVOID)rpg_beta6_2_cmd_data[1].cmd_address))
         {
            alarm_btn->Text = "Alarm Off";
            alarm_btn->ForeColor = System::Drawing::SystemColors::Highlight;
         }
         else
         {
            alarm_btn->Text = "Alarm On";
            alarm_btn->ForeColor = System::Drawing::Color::Red;
         }

         //update setting
         if (C_Setting != Halo_Process->ReadMem<BYTE>((LPVOID)rpg_beta6_2_cmd_data[1].cmd_address))
         {
            C_Setting = Halo_Process->ReadMem<BYTE>((LPVOID)HCE_Lib::Setting_address);
            if (C_Setting >= 0 && C_Setting <= 2)
               ToD_cb->SelectedIndex = C_Setting;
         }

         //update lockdown timer
         if (Lock_sec != Halo_Process->ReadMem<short>((LPVOID)rpg_beta6_2_cmd_data[4].cmd_address))
         {
            Lock_sec = Halo_Process->ReadMem<short>((LPVOID)rpg_beta6_2_cmd_data[4].cmd_address);
            BLD_timer_txt->Text = (Lock_sec / 30).ToString();
         }

         //update lockdown button
         if (!Halo_Process->ReadMem<bool>((LPVOID)rpg_beta6_2_cmd_data[2].cmd_address))
         {
            BLD_activate->ForeColor = System::Drawing::SystemColors::Highlight;
            BLD_activate->Text = "Activate";
         }
         else
         {
            BLD_activate->ForeColor = System::Drawing::Color::Red;
            BLD_activate->Text = "Locked";
         }

         //update fire halo button
         if (!Halo_Process->ReadMem<bool>((LPVOID)rpg_beta6_2_cmd_data[3].cmd_address))
         {
            halo_activate->ForeColor = System::Drawing::SystemColors::Highlight;
            halo_activate->Text = "Fire";
         }
         else
         {
            halo_activate->ForeColor = System::Drawing::Color::Red;
            halo_activate->Text = "Cool Down";
         }

         //update halo timer
         if (Halo_sec != Halo_Process->ReadMem<short>((LPVOID)rpg_beta6_2_cmd_data[5].cmd_address))
         {
            Halo_sec = Halo_Process->ReadMem<short>((LPVOID)rpg_beta6_2_cmd_data[5].cmd_address);
            halo_timer_txt->Text = (Halo_sec / 30).ToString();
         }
         
         //keyboard shortcuts
         if (rpgbeta6_2_commands.Enable_Shrtcts && running_sv_t == server_type::host)
         {
            //setting
            if (IsKeyDown(rpg_beta6_2_cmd_keys[0].toggle_key))
               if (ToD_cb->SelectedIndex != 2)
                  ToD_cb->SelectedIndex = ToD_cb->SelectedIndex + 1;
               else
                  ToD_cb->SelectedIndex = ToD_cb->SelectedIndex - 2;

            //alarm on/off
            if (IsKeyDown(rpg_beta6_2_cmd_keys[1].toggle_key))
               alarm_btn->PerformClick();

            //lockdown
            if (IsKeyDown(rpg_beta6_2_cmd_keys[2].toggle_key))
               BLD_activate->PerformClick();

            //fire halo
            if (IsKeyDown(rpg_beta6_2_cmd_keys[3].toggle_key))
               halo_activate->PerformClick();
         }
         
         //check for rpg_beta chat commands//
         if (chat != "" && !erase_chat)
         {
            if (running_sv_t == server_type::host && chat[0] == '/' && chat[chat->Length - 1] == ';')
            {      
               //change setting to day
               if (chat == gcnew System::String(rpg_beta6_2_cmd_strs[0].cmd_activate))
               {
                  erase_chat = true;
                  ToD_cb->SelectedIndex = 0;
               }
               //change setting to rain
               else if (chat == gcnew System::String(rpg_beta6_2_cmd_strs[0].cmd_on))
               {
                  erase_chat = true;
                  ToD_cb->SelectedIndex = 1;
               }
               //change setting to night
               else if (chat == gcnew System::String(rpg_beta6_2_cmd_strs[0].cmd_off))
               {
                  erase_chat = true;
                  ToD_cb->SelectedIndex = 2;
               }
               //turn alarm on
               else if (chat == gcnew System::String(rpg_beta6_2_cmd_strs[1].cmd_on))
               {
                  erase_chat = true;
                  if (!Halo_Process->ReadMem<bool>((LPVOID)rpg_beta6_2_cmd_data[1].cmd_address))
                     alarm_btn->PerformClick();
               }
               //turn alarm off
               else if (chat == gcnew System::String(rpg_beta6_2_cmd_strs[1].cmd_off))
               {
                  erase_chat = true;
                  if (Halo_Process->ReadMem<bool>((LPVOID)rpg_beta6_2_cmd_data[1].cmd_address))
                     alarm_btn->PerformClick();
               }
               //trigger lockdown
               else if (chat == gcnew System::String(rpg_beta6_2_cmd_strs[2].cmd_activate))
               {
                  erase_chat = true;
                  BLD_activate->PerformClick();
               }
               //fire halo
               else if (chat == gcnew System::String(rpg_beta6_2_cmd_strs[3].cmd_activate))
               {
                  erase_chat = true;
                  halo_activate->PerformClick();
               }
               ///lockdown timer <num> 
               if (chat->Contains("/lockdown timer "))
               {
                  short number = 0;
                  
                  int str_2arg_index = FindCMDArgIndex(chat);
                  if (ParseCMDStringNumbers<short>(chat->Substring(str_2arg_index), &number, 1))
                  {
                     Halo_Process->WriteMem<short>((LPVOID)rpg_beta6_2_cmd_data[4].cmd_address, number * 30);
                     erase_chat = true;
                  }
                  
                  erase_cmd_terminator = !erase_chat;
               }
               ///halo timer <num>
               if (chat->Contains("/halo timer "))
               {
                  short number = 0;
                  
                  int str_2arg_index = FindCMDArgIndex(chat);
                  if (ParseCMDStringNumbers<short>(chat->Substring(str_2arg_index), &number, 1))
                  {
                     Halo_Process->WriteMem<short>((LPVOID)rpg_beta6_2_cmd_data[5].cmd_address, number * 30);
                     erase_chat = true;
                  }
                  
                  erase_cmd_terminator = !erase_chat;
               }
            }
         }
      }
      else
      {
         rpgb6_2_running = false;
         status_lbl4->ForeColor = System::Drawing::Color::Red;
      }
      
      if (erase_chat)
      {
         if (!Halo_Process->ReadMem<bool>((LPVOID)Console_chck_address))
            Halo_Process->WriteMem<wchar_t>((LPVOID)(Chat_address + (chat->Length - 1) * sizeof(wchar_t)), '\0');
         else
            Halo_Process->WriteMem<char>((LPVOID)(Chat_address + (chat->Length - 1) * sizeof(char)), '\0');
            
         PressKey(VK_RETURN, 2);
         Halo_Process->WriteMem<wchar_t>((LPVOID)Chat_address, L'\0');
         erase_chat = false;
      }
      else if (erase_cmd_terminator)
      {
         PressKey(VK_BACK, 1);
         erase_cmd_terminator = false;
      }
   }
   
   if (control_enabled_change)
   {
      btn_dev->Enabled = running_gt == game_types::HCE;
      btn_console->Enabled = running_gt != game_types::not_running;
      showhud_chkBx->Enabled = running_gt != game_types::not_running;
      letterbox_chkBx->Enabled = running_gt != game_types::not_running;
      rcon_lbl->Enabled = running_gt != game_types::not_running;
      ejection_chkBx->Enabled = running_sv_t != server_type::client && running_gt != game_types::not_running;
      Deathless_chkBx->Enabled = running_sv_t != server_type::client && running_gt != game_types::not_running;
      IF_chkBx->Enabled = running_sv_t != server_type::client && running_gt != game_types::not_running;
      
      //rpg_beta6_2 functions
      ToD_cb->Enabled = running_sv_t == server_type::host && rpgb6_2_running;
      alarm_btn->Enabled = running_sv_t == server_type::host && rpgb6_2_running;
      BLD_lbl->Enabled = running_sv_t == server_type::host && rpgb6_2_running;
      BLD_timer_txt->Enabled = running_sv_t == server_type::host && rpgb6_2_running;
      BLD_activate->Enabled = running_sv_t == server_type::host && rpgb6_2_running;
      halo_lbl->Enabled = running_sv_t == server_type::host && rpgb6_2_running;
      halo_timer_txt->Enabled = running_sv_t == server_type::host && rpgb6_2_running;
      halo_activate->Enabled = running_sv_t == server_type::host && rpgb6_2_running;

      //enable set btns if text is a number
      if (BLD_timer_txt->Text != "seconds")
         BLD_set_t->Enabled = running_sv_t != server_type::host && rpgb6_2_running;
      if (halo_timer_txt->Text !="seconds")
         halo_set_t->Enabled = running_sv_t == server_type::host && rpgb6_2_running;
         
      control_enabled_change = false;
   }
}


void MainForm::dev_btn_Click(System::Object^  sender, System::EventArgs^  e)
{  
   bool dev_enabled = Halo_Process->ReadMem<bool>((LPVOID)halo_cmd_data[1].cmd_address);
   
   if (!dev_enabled)
      //enable console
      Halo_Process->WriteMem<bool>((LPVOID)halo_cmd_data[0].cmd_address, true);

   Halo_Process->WriteMem<bool>((LPVOID)halo_cmd_data[1].cmd_address, !dev_enabled);
}

void MainForm::btn_console_Click(System::Object^  sender, System::EventArgs^  e)
{
   Halo_Process->WriteMem<bool>((LPVOID)halo_cmd_data[0].cmd_address, !Halo_Process->ReadMem<bool>((LPVOID)halo_cmd_data[0].cmd_address));
}

void MainForm::Deathless_chkBx_CheckedChanged(System::Object^  sender, System::EventArgs^  e)
{
   Halo_Process->WriteMem<bool>((LPVOID)halo_cmd_data[2].cmd_address, Deathless_chkBx->Checked);
}

void MainForm::IF_chkBx_CheckedChanged(System::Object^  sender, System::EventArgs^  e)
{
   Halo_Process->WriteMem<bool>((LPVOID)halo_cmd_data[3].cmd_address, IF_chkBx->Checked);
}

void MainForm::showhud_chkBx_CheckedChanged(System::Object^  sender, System::EventArgs^  e)
{
   Halo_Process->WriteMem<bool>((LPVOID)halo_cmd_data[5].cmd_address, showhud_chkBx->Checked);
}

void MainForm::letterbox_chkBx_CheckedChanged(System::Object^  sender, System::EventArgs^  e)
{
   Halo_Process->WriteMem<bool>((LPVOID)halo_cmd_data[6].cmd_address, letterbox_chkBx->Checked);
}

void MainForm::OpenConsole()
{
   if (!Halo_Process->ReadMem<bool>((LPVOID)HCE_Lib::Console_Check_address))
   {
      ::keybd_event(VK_RETURN, 0x29, 0, NULL);
      System::Threading::Thread::Sleep(200);
      ::keybd_event(VK_RETURN, 0x29, KEYEVENTF_KEYUP, NULL);
   }
}

void MainForm::ejection_chkBx_CheckedChanged(System::Object^  sender, System::EventArgs^  e)
{
   Halo_Process->WriteMem<bool>((LPVOID)halo_cmd_data[7].cmd_address, ejection_chkBx->Checked);
}

void MainForm::ToD_cb_SelectedIndexChanged(System::Object^  sender, System::EventArgs^  e)
{
   Halo_Process->WriteMem<BYTE>((LPVOID)rpg_beta6_2_cmd_data[0].cmd_address, (BYTE)ToD_cb->SelectedIndex);
}

void MainForm::alarm_btn_Click(System::Object^  sender, System::EventArgs^  e)
{
   Halo_Process->WriteMem<bool>((LPVOID)(Device_Groups_Header->ItemArray_ptr 
      + HCE_Lib::rpg_beta6_2_device_groups::alarm_control_2_offset), true);
               
   //Halo_Process->WriteMem<bool>((LPVOID)HCE_Lib::Alarm_Control_2_address, true);
   //Halo_Process->WriteMem<BYTE>(HCE_Lib::Alarm_Control_3_address, 1);
   //Halo_Process->WriteMem<BYTE>(HCE_Lib::Alarm_Control_4_address, 1);
   //Halo_Process->WriteMem<BYTE>(HCE_Lib::Alarm_Control_1_address, 1);
}

void MainForm::BLD_set_t_Click(System::Object^  sender, System::EventArgs^  e)
{
   short seconds = 0;
   if (short::TryParse(BLD_timer_txt->Text, seconds))
      Halo_Process->WriteMem<short>((LPVOID)rpg_beta6_2_cmd_data[4].cmd_address, seconds * 30);
}

void MainForm::BLD_activate_Click(System::Object^  sender, System::EventArgs^  e)
{
   if (!Halo_Process->ReadMem<bool>((LPVOID)rpg_beta6_2_cmd_data[2].cmd_address))
      Halo_Process->WriteMem<BYTE>((LPVOID)(Device_Groups_Header->ItemArray_ptr
         + HCE_Lib::rpg_beta6_2_device_groups::lock_control_offset), 1);
   else
   {
      //Halo_Process.WriteMemBool(HCE_Lib.Locked, false);
   }
}

void MainForm::halo_set_t_Click(System::Object^  sender, System::EventArgs^  e)
{
   short seconds = 0;
   if (short::TryParse(halo_timer_txt->Text, seconds))
      Halo_Process->WriteMem<short>((LPVOID)rpg_beta6_2_cmd_data[5].cmd_address, seconds * 30);
}

void MainForm::halo_activate_Click(System::Object^  sender, System::EventArgs^  e)
{
   if (!Halo_Process->ReadMem<bool>((LPVOID)HCE_Lib::Nuked_address))
      Halo_Process->WriteMem<BYTE>((LPVOID)(Device_Groups_Header->ItemArray_ptr 
         + HCE_Lib::rpg_beta6_2_device_groups::boom_control_offset), 1);
   else
   {
      
   }
}
   
void MainForm::Help_halo_commands_Click(System::Object^  sender, System::EventArgs^  e)
{
   bool commands_changed = false;
   win_Chat_Commands^ f3 = gcnew win_Chat_Commands(&halo_commands, &commands_changed);
   f3->lbl_2nd_descript->Text = "";
   f3->ShowDialog();
   
   if (commands_changed)
      WriteSettingsToFile();
}

void MainForm::Help_rpgbeta6_2_commands_Click(System::Object^  sender, System::EventArgs^  e)
{
   bool commands_changed = false;
   win_Chat_Commands^ f3 = gcnew win_Chat_Commands(&rpgbeta6_2_commands, &commands_changed);
   f3->lbl_2nd_descript->Text = "";
   f3->ShowDialog();
   
   if (commands_changed)
      WriteSettingsToFile();
}

void MainForm::playerCommandsToolStripMenuItem_Click(System::Object^  sender, System::EventArgs^  e)
{
   bool commands_changed = false;
   win_Chat_Commands^ f3 = gcnew win_Chat_Commands(&player_commands, &commands_changed);
   //f3->lbl_2nd_descript->Text = "p0 to p15  p* for all players"
   f3->lbl_2nd_descript->Text = "[pExpression] based on devicator";
   f3->ShowDialog();
   
   //if (commands_changed)
   //   WriteSettingsToFile();
}

void MainForm::teleportLocationsToolStripMenuItem_Click(System::Object^  sender, System::EventArgs^  e)
{
   Teleport_Locations^ f4 = gcnew Teleport_Locations(&maps_tele_sites);
   f4->ShowDialog();
}

void MainForm::Help_about_Click(System::Object^  sender, System::EventArgs^  e)
{
   win_About^ f2 = gcnew win_About();
   f2->ShowDialog();
}