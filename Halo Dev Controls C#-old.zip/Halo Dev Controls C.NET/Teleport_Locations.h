/********************************************************************************
	 -- Halo Dev Controls
    Copyright � 2011 Jesus7Freak

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*********************************************************************************
	File:    Teleport_Locations.h
	Project: Halo Dev Controls C.NET
	Author:  Jesus7Freak
	Date:    11/22/2011
	Game:    Halo and Halo Custom Edition
	Version: all
*********************************************************************************/
#pragma once
#include "tele_loc_resources.h"

namespace RPG_Beta6_2DevControls 
{
	/// <summary>
	/// Summary for Teleport_Locations
	///
	/// WARNING: If you change the name of this class, you will need to change the
	///          'Resource File Name' property for the managed resource compiler tool
	///          associated with all .resx files this class depends on.  Otherwise,
	///          the designers will not be able to interact properly with localized
	///          resources associated with this form.
	/// </summary>
	public ref class Teleport_Locations : public System::Windows::Forms::Form
	{
	public:
	   bool *locations_changed_ptr, intern_change;
	   std::vector<MAPS>* Locations;
		Teleport_Locations(std::vector<MAPS>* locations, bool *locations_changed);

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Teleport_Locations()
		{
			if (components)
			{
				delete components;
			}
		}
   private: System::Windows::Forms::ListBox^  lstbx_maps;
   private: System::Windows::Forms::Label^  lbl_maps;
   private: System::Windows::Forms::ListBox^  lstbx_locations;
   private: System::Windows::Forms::Label^  lbl_locations;
   private: System::Windows::Forms::TextBox^  txtbx_loc_name;
   private: System::Windows::Forms::Label^  label1;
   private: System::Windows::Forms::Label^  lbl_x_coor;
   private: System::Windows::Forms::Label^  lbl_y_coor;
   private: System::Windows::Forms::Label^  lbl_z_coor;
   private: System::Windows::Forms::Button^  btn_set_location;
   private: System::Windows::Forms::TextBox^  txtbx_x_coor;
   private: System::Windows::Forms::TextBox^  txtbx_y_coor;
   private: System::Windows::Forms::TextBox^  txtbx_z_coor;
   private: System::Windows::Forms::Button^  btn_ok;
   private: System::Windows::Forms::Button^  btn_remove;
   private: System::Windows::Forms::Button^  btn_add;
	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
      this->lstbx_maps = (gcnew System::Windows::Forms::ListBox());
      this->lbl_maps = (gcnew System::Windows::Forms::Label());
      this->lstbx_locations = (gcnew System::Windows::Forms::ListBox());
      this->lbl_locations = (gcnew System::Windows::Forms::Label());
      this->txtbx_loc_name = (gcnew System::Windows::Forms::TextBox());
      this->label1 = (gcnew System::Windows::Forms::Label());
      this->lbl_x_coor = (gcnew System::Windows::Forms::Label());
      this->lbl_y_coor = (gcnew System::Windows::Forms::Label());
      this->lbl_z_coor = (gcnew System::Windows::Forms::Label());
      this->btn_set_location = (gcnew System::Windows::Forms::Button());
      this->txtbx_x_coor = (gcnew System::Windows::Forms::TextBox());
      this->txtbx_y_coor = (gcnew System::Windows::Forms::TextBox());
      this->txtbx_z_coor = (gcnew System::Windows::Forms::TextBox());
      this->btn_ok = (gcnew System::Windows::Forms::Button());
      this->btn_remove = (gcnew System::Windows::Forms::Button());
      this->btn_add = (gcnew System::Windows::Forms::Button());
      this->SuspendLayout();
      // 
      // lstbx_maps
      // 
      this->lstbx_maps->FormattingEnabled = true;
      this->lstbx_maps->Items->AddRange(gcnew cli::array< System::Object^  >(1) {L"12345678901234567890123"});
      this->lstbx_maps->Location = System::Drawing::Point(3, 22);
      this->lstbx_maps->Name = L"lstbx_maps";
      this->lstbx_maps->Size = System::Drawing::Size(103, 108);
      this->lstbx_maps->TabIndex = 0;
      this->lstbx_maps->SelectedIndexChanged += gcnew System::EventHandler(this, &Teleport_Locations::lstbx_maps_SelectedIndexChanged);
      // 
      // lbl_maps
      // 
      this->lbl_maps->AutoSize = true;
      this->lbl_maps->Location = System::Drawing::Point(31, 6);
      this->lbl_maps->Name = L"lbl_maps";
      this->lbl_maps->Size = System::Drawing::Size(33, 13);
      this->lbl_maps->TabIndex = 1;
      this->lbl_maps->Text = L"Maps";
      // 
      // lstbx_locations
      // 
      this->lstbx_locations->FormattingEnabled = true;
      this->lstbx_locations->Items->AddRange(gcnew cli::array< System::Object^  >(1) {L"12345678901"});
      this->lstbx_locations->Location = System::Drawing::Point(112, 23);
      this->lstbx_locations->Name = L"lstbx_locations";
      this->lstbx_locations->Size = System::Drawing::Size(80, 108);
      this->lstbx_locations->TabIndex = 2;
      this->lstbx_locations->SelectedIndexChanged += gcnew System::EventHandler(this, &Teleport_Locations::lstbx_locations_SelectedIndexChanged);
      // 
      // lbl_locations
      // 
      this->lbl_locations->AutoSize = true;
      this->lbl_locations->Location = System::Drawing::Point(128, 6);
      this->lbl_locations->Name = L"lbl_locations";
      this->lbl_locations->Size = System::Drawing::Size(53, 13);
      this->lbl_locations->TabIndex = 3;
      this->lbl_locations->Text = L"Locations";
      // 
      // txtbx_loc_name
      // 
      this->txtbx_loc_name->Location = System::Drawing::Point(323, 36);
      this->txtbx_loc_name->MaxLength = 11;
      this->txtbx_loc_name->Name = L"txtbx_loc_name";
      this->txtbx_loc_name->Size = System::Drawing::Size(89, 20);
      this->txtbx_loc_name->TabIndex = 4;
      this->txtbx_loc_name->KeyDown += gcnew System::Windows::Forms::KeyEventHandler(this, &Teleport_Locations::no_space_mask);
      // 
      // label1
      // 
      this->label1->AutoSize = true;
      this->label1->Location = System::Drawing::Point(329, 21);
      this->label1->Name = L"label1";
      this->label1->Size = System::Drawing::Size(79, 13);
      this->label1->TabIndex = 6;
      this->label1->Text = L"Location Name";
      // 
      // lbl_x_coor
      // 
      this->lbl_x_coor->AutoSize = true;
      this->lbl_x_coor->Location = System::Drawing::Point(222, 59);
      this->lbl_x_coor->Name = L"lbl_x_coor";
      this->lbl_x_coor->Size = System::Drawing::Size(65, 13);
      this->lbl_x_coor->TabIndex = 9;
      this->lbl_x_coor->Text = L"x coordinate";
      // 
      // lbl_y_coor
      // 
      this->lbl_y_coor->AutoSize = true;
      this->lbl_y_coor->Location = System::Drawing::Point(328, 59);
      this->lbl_y_coor->Name = L"lbl_y_coor";
      this->lbl_y_coor->Size = System::Drawing::Size(65, 13);
      this->lbl_y_coor->TabIndex = 10;
      this->lbl_y_coor->Text = L"y coordinate";
      // 
      // lbl_z_coor
      // 
      this->lbl_z_coor->AutoSize = true;
      this->lbl_z_coor->Location = System::Drawing::Point(434, 59);
      this->lbl_z_coor->Name = L"lbl_z_coor";
      this->lbl_z_coor->Size = System::Drawing::Size(65, 13);
      this->lbl_z_coor->TabIndex = 11;
      this->lbl_z_coor->Text = L"z coordinate";
      // 
      // btn_set_location
      // 
      this->btn_set_location->Location = System::Drawing::Point(211, 107);
      this->btn_set_location->Name = L"btn_set_location";
      this->btn_set_location->Size = System::Drawing::Size(232, 23);
      this->btn_set_location->TabIndex = 12;
      this->btn_set_location->Text = L"set";
      this->btn_set_location->UseVisualStyleBackColor = true;
      this->btn_set_location->Click += gcnew System::EventHandler(this, &Teleport_Locations::btn_set_location_Click);
      // 
      // txtbx_x_coor
      // 
      this->txtbx_x_coor->Location = System::Drawing::Point(211, 75);
      this->txtbx_x_coor->MaxLength = 16;
      this->txtbx_x_coor->Name = L"txtbx_x_coor";
      this->txtbx_x_coor->Size = System::Drawing::Size(100, 20);
      this->txtbx_x_coor->TabIndex = 16;
      this->txtbx_x_coor->KeyDown += gcnew System::Windows::Forms::KeyEventHandler(this, &Teleport_Locations::float_mask);
      // 
      // txtbx_y_coor
      // 
      this->txtbx_y_coor->Location = System::Drawing::Point(317, 75);
      this->txtbx_y_coor->MaxLength = 16;
      this->txtbx_y_coor->Name = L"txtbx_y_coor";
      this->txtbx_y_coor->Size = System::Drawing::Size(100, 20);
      this->txtbx_y_coor->TabIndex = 17;
      this->txtbx_y_coor->KeyDown += gcnew System::Windows::Forms::KeyEventHandler(this, &Teleport_Locations::float_mask);
      // 
      // txtbx_z_coor
      // 
      this->txtbx_z_coor->Location = System::Drawing::Point(423, 75);
      this->txtbx_z_coor->MaxLength = 16;
      this->txtbx_z_coor->Name = L"txtbx_z_coor";
      this->txtbx_z_coor->Size = System::Drawing::Size(100, 20);
      this->txtbx_z_coor->TabIndex = 18;
      this->txtbx_z_coor->KeyDown += gcnew System::Windows::Forms::KeyEventHandler(this, &Teleport_Locations::float_mask);
      // 
      // btn_ok
      // 
      this->btn_ok->Anchor = static_cast<System::Windows::Forms::AnchorStyles>((System::Windows::Forms::AnchorStyles::Bottom | System::Windows::Forms::AnchorStyles::Right));
      this->btn_ok->DialogResult = System::Windows::Forms::DialogResult::Cancel;
      this->btn_ok->Location = System::Drawing::Point(471, 107);
      this->btn_ok->Name = L"btn_ok";
      this->btn_ok->Size = System::Drawing::Size(46, 23);
      this->btn_ok->TabIndex = 19;
      this->btn_ok->Text = L"&OK";
      this->btn_ok->UseVisualStyleBackColor = false;
      this->btn_ok->Click += gcnew System::EventHandler(this, &Teleport_Locations::okButton_Click);
      // 
      // btn_remove
      // 
      this->btn_remove->Location = System::Drawing::Point(462, 21);
      this->btn_remove->Name = L"btn_remove";
      this->btn_remove->Size = System::Drawing::Size(61, 23);
      this->btn_remove->TabIndex = 20;
      this->btn_remove->Text = L"Remove";
      this->btn_remove->UseVisualStyleBackColor = true;
      this->btn_remove->Click += gcnew System::EventHandler(this, &Teleport_Locations::btn_remove_Click);
      // 
      // btn_add
      // 
      this->btn_add->Enabled = false;
      this->btn_add->Location = System::Drawing::Point(211, 22);
      this->btn_add->Name = L"btn_add";
      this->btn_add->Size = System::Drawing::Size(61, 23);
      this->btn_add->TabIndex = 21;
      this->btn_add->Text = L"Add";
      this->btn_add->UseVisualStyleBackColor = true;
      this->btn_add->Click += gcnew System::EventHandler(this, &Teleport_Locations::btn_add_Click);
      // 
      // Teleport_Locations
      // 
      this->AcceptButton = this->btn_ok;
      this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
      this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
      this->ClientSize = System::Drawing::Size(528, 135);
      this->Controls->Add(this->btn_add);
      this->Controls->Add(this->btn_remove);
      this->Controls->Add(this->btn_ok);
      this->Controls->Add(this->txtbx_z_coor);
      this->Controls->Add(this->txtbx_y_coor);
      this->Controls->Add(this->txtbx_x_coor);
      this->Controls->Add(this->btn_set_location);
      this->Controls->Add(this->lbl_z_coor);
      this->Controls->Add(this->lbl_y_coor);
      this->Controls->Add(this->lbl_x_coor);
      this->Controls->Add(this->label1);
      this->Controls->Add(this->txtbx_loc_name);
      this->Controls->Add(this->lbl_locations);
      this->Controls->Add(this->lstbx_locations);
      this->Controls->Add(this->lbl_maps);
      this->Controls->Add(this->lstbx_maps);
      this->FormBorderStyle = System::Windows::Forms::FormBorderStyle::FixedToolWindow;
      this->MaximizeBox = false;
      this->MinimizeBox = false;
      this->Name = L"Teleport_Locations";
      this->ShowIcon = false;
      this->ShowInTaskbar = false;
      this->Text = L"Teleport Locations";
      this->ResumeLayout(false);
      this->PerformLayout();

         }
#pragma endregion
   private: void okButton_Click(System::Object^  sender, System::EventArgs^  e);
   private: void no_space_mask(System::Object^  sender, System::Windows::Forms::KeyEventArgs^  e);
   private: void float_mask(System::Object^  sender, System::Windows::Forms::KeyEventArgs^  e);
   private: void lstbx_maps_SelectedIndexChanged(System::Object^  sender, System::EventArgs^  e);
   private: void lstbx_locations_SelectedIndexChanged(System::Object^  sender, System::EventArgs^  e);
   private: void btn_add_Click(System::Object^  sender, System::EventArgs^  e);
   private: void btn_remove_Click(System::Object^  sender, System::EventArgs^  e);
   private: void btn_set_location_Click(System::Object^  sender, System::EventArgs^  e);
};
}
